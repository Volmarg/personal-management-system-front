var s="/assets/korvue.cf2903b2.svg";export{s as default};
