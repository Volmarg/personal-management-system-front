import{_ as r,o as a,e}from"./index.31c62b28.js";var t=r({data:()=>({})},[["render",function(r,t,d,n,o,i){return a(),e("div")}]]);export{t as default};
