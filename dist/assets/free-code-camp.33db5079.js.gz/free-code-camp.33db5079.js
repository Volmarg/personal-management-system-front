var e="/assets/free-code-camp.022bd5ea.svg";export{e as default};
