var e="/assets/node.e148bdbe.svg";export{e as default};
