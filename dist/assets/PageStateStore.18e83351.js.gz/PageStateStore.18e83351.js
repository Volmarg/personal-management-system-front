import{aF as t}from"./index.5c1c3a9f.js";const a=t("pageState",{state:()=>({pageTitlePostfix:""})});export{a as p};
