var s="/assets/rockrms.3a172de4.svg";export{s as default};
