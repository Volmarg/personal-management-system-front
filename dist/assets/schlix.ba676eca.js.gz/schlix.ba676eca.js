var s="/assets/schlix.5eeb4503.svg";export{s as default};
