var a="/assets/gopuram-solid.e13e66af.svg";export{a as default};
