var s="/assets/toolbox-solid.8dcece46.svg";export{s as default};
