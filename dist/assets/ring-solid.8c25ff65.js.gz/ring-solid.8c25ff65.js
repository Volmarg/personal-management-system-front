var s="/assets/ring-solid.7ffda2d7.svg";export{s as default};
