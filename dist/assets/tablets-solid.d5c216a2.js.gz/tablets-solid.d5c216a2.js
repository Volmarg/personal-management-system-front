var s="/assets/tablets-solid.763bbee0.svg";export{s as default};
