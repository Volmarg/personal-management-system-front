var a="/assets/uikit.b8cbe0af.svg";export{a as default};
