var a="/assets/notes-medical-solid.e9a6475a.svg";export{a as default};
