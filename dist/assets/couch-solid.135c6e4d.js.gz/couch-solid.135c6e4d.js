var a="/assets/couch-solid.aa44f6ec.svg";export{a as default};
