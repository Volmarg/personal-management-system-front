var s="/assets/ticket-alt-solid.45c45091.svg";export{s as default};
