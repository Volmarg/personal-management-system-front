var s="/assets/euro-sign-solid.e535a405.svg";export{s as default};
