import{aE as t}from"./index.db8bde11.js";const e=t("pageState",{state:()=>({pageTitlePostfix:""})});export{e as p};
