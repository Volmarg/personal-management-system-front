var a="/assets/crop-solid.adf9ca35.svg";export{a as default};
