var e="/assets/reply-solid.58e2ce5c.svg";export{e as default};
