var a="/assets/capsules-solid.aaab1413.svg";export{a as default};
