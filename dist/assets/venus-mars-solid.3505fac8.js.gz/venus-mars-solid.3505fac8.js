var s="/assets/venus-mars-solid.1d28a65c.svg";export{s as default};
