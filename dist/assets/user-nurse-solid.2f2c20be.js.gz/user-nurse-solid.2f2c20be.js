var s="/assets/user-nurse-solid.eabacf87.svg";export{s as default};
