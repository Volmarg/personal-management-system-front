var d="/assets/cloud-download-alt-solid.bcd52dfc.svg";export{d as default};
