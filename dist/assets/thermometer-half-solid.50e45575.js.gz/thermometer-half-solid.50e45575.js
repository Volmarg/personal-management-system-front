var e="/assets/thermometer-half-solid.b65af04e.svg";export{e as default};
