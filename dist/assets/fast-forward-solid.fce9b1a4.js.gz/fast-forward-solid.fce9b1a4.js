var s="/assets/fast-forward-solid.db041488.svg";export{s as default};
