var s="/assets/pills-solid.25060117.svg";export{s as default};
