var e="/assets/thermometer-three-quarters-solid.3ed9d38e.svg";export{e as default};
