var e="/assets/expeditedssl.143944e2.svg";export{e as default};
