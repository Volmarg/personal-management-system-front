var s="/assets/js-square.bcd9a221.svg";export{s as default};
