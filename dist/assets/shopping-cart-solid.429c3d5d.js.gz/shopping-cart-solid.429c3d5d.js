var s="/assets/shopping-cart-solid.7de2fb96.svg";export{s as default};
