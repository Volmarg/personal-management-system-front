var s="/assets/dice-one-solid.11808450.svg";export{s as default};
