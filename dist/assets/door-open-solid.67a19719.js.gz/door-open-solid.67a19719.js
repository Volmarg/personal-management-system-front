var s="/assets/door-open-solid.35b42658.svg";export{s as default};
