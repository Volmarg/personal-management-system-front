var e="/assets/caret-square-right-solid.7e4e3f10.svg";export{e as default};
