var a="/assets/battery-quarter-solid.396e5aec.svg";export{a as default};
