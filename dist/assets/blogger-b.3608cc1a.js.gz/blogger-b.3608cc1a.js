var s="/assets/blogger-b.1283cdbc.svg";export{s as default};
