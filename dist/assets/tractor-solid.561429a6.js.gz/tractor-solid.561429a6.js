var a="/assets/tractor-solid.de60b9a7.svg";export{a as default};
