var e="/assets/rebel.13400331.svg";export{e as default};
