var s="/assets/hashtag-solid.59e2bd96.svg";export{s as default};
