var a="/assets/image-solid.e64a8d8b.svg";export{a as default};
