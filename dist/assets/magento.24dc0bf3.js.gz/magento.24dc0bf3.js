var a="/assets/magento.0128d500.svg";export{a as default};
