var s="/assets/soundcloud.03376044.svg";export{s as default};
