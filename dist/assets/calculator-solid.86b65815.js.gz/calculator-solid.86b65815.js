var a="/assets/calculator-solid.31b74e4a.svg";export{a as default};
