var s="/assets/film-solid.58113fc5.svg";export{s as default};
