var s="/assets/share-alt-square-solid.1f08dc72.svg";export{s as default};
