var a="/assets/hacker-news.5a07fac3.svg";export{a as default};
