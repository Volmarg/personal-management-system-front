var s="/assets/poo-storm-solid.26a7af20.svg";export{s as default};
