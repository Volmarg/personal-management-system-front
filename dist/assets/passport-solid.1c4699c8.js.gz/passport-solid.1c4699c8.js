var s="/assets/passport-solid.46a890c8.svg";export{s as default};
