var a="/assets/vimeo-square.7e4dba2d.svg";export{a as default};
