var a="/assets/cart-arrow-down-solid.058da07b.svg";export{a as default};
