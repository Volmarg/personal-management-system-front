var e="/assets/ethernet-solid.b0543c7e.svg";export{e as default};
