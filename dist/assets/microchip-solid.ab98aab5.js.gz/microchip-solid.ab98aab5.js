var s="/assets/microchip-solid.cf963185.svg";export{s as default};
