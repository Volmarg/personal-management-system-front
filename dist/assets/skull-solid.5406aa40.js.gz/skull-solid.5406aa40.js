var s="/assets/skull-solid.859718ea.svg";export{s as default};
