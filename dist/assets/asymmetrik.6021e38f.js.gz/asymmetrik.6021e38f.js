var a="/assets/asymmetrik.0799dad6.svg";export{a as default};
