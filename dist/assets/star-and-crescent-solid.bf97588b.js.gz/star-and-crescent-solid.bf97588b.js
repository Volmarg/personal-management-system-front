var s="/assets/star-and-crescent-solid.53142cb2.svg";export{s as default};
