var s="/assets/comment-alt-solid.02648bb0.svg";export{s as default};
