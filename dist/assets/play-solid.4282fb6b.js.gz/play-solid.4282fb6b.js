var s="/assets/play-solid.326b7339.svg";export{s as default};
