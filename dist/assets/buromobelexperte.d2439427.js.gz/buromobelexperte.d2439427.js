var e="/assets/buromobelexperte.3daf7bab.svg";export{e as default};
