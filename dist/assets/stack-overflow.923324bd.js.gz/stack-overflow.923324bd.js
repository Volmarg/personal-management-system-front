var s="/assets/stack-overflow.0521fb1d.svg";export{s as default};
