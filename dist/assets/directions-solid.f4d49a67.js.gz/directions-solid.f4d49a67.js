var s="/assets/directions-solid.b3530c39.svg";export{s as default};
