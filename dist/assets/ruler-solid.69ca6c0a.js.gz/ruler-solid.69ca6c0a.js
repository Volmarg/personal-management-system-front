var s="/assets/ruler-solid.74912175.svg";export{s as default};
