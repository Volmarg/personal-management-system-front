var s="/assets/praying-hands-solid.462e143b.svg";export{s as default};
