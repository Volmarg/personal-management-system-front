var s="/assets/firstdraft.db766de2.svg";export{s as default};
