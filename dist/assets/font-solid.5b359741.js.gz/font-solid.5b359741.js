var s="/assets/font-solid.a7070c13.svg";export{s as default};
