var a="/assets/redhat.7446bb65.svg";export{a as default};
