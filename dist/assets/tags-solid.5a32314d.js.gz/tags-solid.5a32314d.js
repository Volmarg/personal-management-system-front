var s="/assets/tags-solid.a27112ee.svg";export{s as default};
