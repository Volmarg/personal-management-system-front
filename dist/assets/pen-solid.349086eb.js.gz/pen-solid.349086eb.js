var s="/assets/pen-solid.88221730.svg";export{s as default};
