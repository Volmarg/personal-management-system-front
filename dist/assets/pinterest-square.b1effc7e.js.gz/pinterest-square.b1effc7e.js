var s="/assets/pinterest-square.35a4f911.svg";export{s as default};
