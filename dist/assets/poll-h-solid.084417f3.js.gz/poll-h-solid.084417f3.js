var s="/assets/poll-h-solid.43cd479e.svg";export{s as default};
