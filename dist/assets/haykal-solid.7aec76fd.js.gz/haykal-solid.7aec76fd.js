var a="/assets/haykal-solid.56b6cd55.svg";export{a as default};
