var s="/assets/staylinked.b2826fbd.svg";export{s as default};
