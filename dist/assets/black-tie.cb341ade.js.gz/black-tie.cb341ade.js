var a="/assets/black-tie.16e1dd8f.svg";export{a as default};
