var s="/assets/user-graduate-solid.72242486.svg";export{s as default};
