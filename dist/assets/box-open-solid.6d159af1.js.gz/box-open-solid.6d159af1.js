var e="/assets/box-open-solid.c4e3e84e.svg";export{e as default};
