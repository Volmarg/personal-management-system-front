var s="/assets/steam-symbol.9e5db5c7.svg";export{s as default};
