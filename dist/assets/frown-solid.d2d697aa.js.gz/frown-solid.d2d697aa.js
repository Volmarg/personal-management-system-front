var s="/assets/frown-solid.9d02802e.svg";export{s as default};
