var s="/assets/zhihu.bf9c275c.svg";export{s as default};
