var a="/assets/truck-loading-solid.ad4a658b.svg";export{a as default};
