var s="/assets/power-off-solid.e8fcf3a9.svg";export{s as default};
