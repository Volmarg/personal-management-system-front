var a="/assets/thumbtack-solid.a92b1dbc.svg";export{a as default};
