var s="/assets/user-times-solid.5e2e4474.svg";export{s as default};
