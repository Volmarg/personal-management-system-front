var s="/assets/prescription-bottle-solid.d3182643.svg";export{s as default};
