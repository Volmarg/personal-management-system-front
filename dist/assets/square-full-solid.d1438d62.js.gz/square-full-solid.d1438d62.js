var s="/assets/square-full-solid.f958fe3c.svg";export{s as default};
