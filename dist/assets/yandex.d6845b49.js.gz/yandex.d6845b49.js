var a="/assets/yandex.e94f0424.svg";export{a as default};
