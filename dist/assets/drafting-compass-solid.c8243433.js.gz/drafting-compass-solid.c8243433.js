var s="/assets/drafting-compass-solid.b0921876.svg";export{s as default};
