var s="/assets/goodreads-g.bc20e461.svg";export{s as default};
