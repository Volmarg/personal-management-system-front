var s="/assets/chess-knight-solid.3129b01c.svg";export{s as default};
