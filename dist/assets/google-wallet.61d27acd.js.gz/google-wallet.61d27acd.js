var a="/assets/google-wallet.2403c612.svg";export{a as default};
