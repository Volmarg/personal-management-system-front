var a="/assets/angrycreative.942e651c.svg";export{a as default};
