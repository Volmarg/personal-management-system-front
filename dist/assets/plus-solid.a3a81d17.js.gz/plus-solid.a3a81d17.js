var s="/assets/plus-solid.b989371f.svg";export{s as default};
