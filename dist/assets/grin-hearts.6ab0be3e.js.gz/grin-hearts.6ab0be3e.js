var a="/assets/grin-hearts-solid.74acdaa8.svg";export{a as default};
