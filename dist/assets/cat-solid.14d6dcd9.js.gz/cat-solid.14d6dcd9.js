var s="/assets/cat-solid.9b705463.svg";export{s as default};
