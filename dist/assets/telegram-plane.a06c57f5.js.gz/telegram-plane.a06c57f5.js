var a="/assets/telegram.56aef3fb.svg";export{a as default};
