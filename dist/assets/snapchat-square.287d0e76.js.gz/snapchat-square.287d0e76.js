var a="/assets/snapchat-square.3efb2bd4.svg";export{a as default};
