var s="/assets/pen-nib-solid.b551ad4f.svg";export{s as default};
