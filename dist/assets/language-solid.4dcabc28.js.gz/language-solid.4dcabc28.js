var a="/assets/language-solid.0d0a453a.svg";export{a as default};
