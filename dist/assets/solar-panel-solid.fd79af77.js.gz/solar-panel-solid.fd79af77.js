var s="/assets/solar-panel-solid.7d229796.svg";export{s as default};
