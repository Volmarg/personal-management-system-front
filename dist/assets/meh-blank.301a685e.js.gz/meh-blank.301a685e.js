var s="/assets/meh-blank-solid.9fcb29e9.svg";export{s as default};
