var e="/assets/evernote.f78d1f00.svg";export{e as default};
