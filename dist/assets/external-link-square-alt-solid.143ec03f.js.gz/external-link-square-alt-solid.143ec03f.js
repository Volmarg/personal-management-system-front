var e="/assets/external-link-square-alt-solid.5e12e10c.svg";export{e as default};
