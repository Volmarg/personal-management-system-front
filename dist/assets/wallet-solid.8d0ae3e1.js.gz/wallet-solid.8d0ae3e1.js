var e="/assets/wallet-solid.cbe33ecf.svg";export{e as default};
