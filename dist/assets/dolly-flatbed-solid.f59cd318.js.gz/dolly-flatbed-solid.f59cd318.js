var s="/assets/dolly-flatbed-solid.30ccf001.svg";export{s as default};
