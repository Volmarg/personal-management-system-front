var a="/assets/chromecast.d903aee1.svg";export{a as default};
