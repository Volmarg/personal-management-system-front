var s="/assets/water-solid.c65c40c6.svg";export{s as default};
