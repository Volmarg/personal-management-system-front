var a="/assets/graduation-cap-solid.e3bba50a.svg";export{a as default};
