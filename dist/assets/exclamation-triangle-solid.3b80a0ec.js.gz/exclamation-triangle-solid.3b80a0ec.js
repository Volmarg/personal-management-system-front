var a="/assets/exclamation-triangle-solid.e312d75f.svg";export{a as default};
