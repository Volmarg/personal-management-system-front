var s="/assets/window-close-solid.94054ab9.svg";export{s as default};
