var s="/assets/user-tie-solid.d2b4a6b7.svg";export{s as default};
