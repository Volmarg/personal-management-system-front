var s="/assets/futbol-solid.bc84ee68.svg";export{s as default};
