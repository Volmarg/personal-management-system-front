import{S as e}from"./index.93e753e6.js";class s extends e{}s.GOALS_BASE_URL="/module/my-goals",s.GOAL_PAYMENTS_BASE_URL="/module/my-goals-payments";export{s as S};
