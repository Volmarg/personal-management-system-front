var s="/assets/chrome.06bbdd35.svg";export{s as default};
