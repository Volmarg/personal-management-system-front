var a="/assets/parachute-box-solid.0fe7cec8.svg";export{a as default};
