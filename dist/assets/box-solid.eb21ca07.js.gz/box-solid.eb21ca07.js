var s="/assets/box-solid.93913542.svg";export{s as default};
