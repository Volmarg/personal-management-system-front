var e="/assets/blog-solid.e7fb6eec.svg";export{e as default};
