var s="/assets/hand-holding-usd-solid.9a9517f2.svg";export{s as default};
