var s="/assets/copy-solid.ba208fc7.svg";export{s as default};
