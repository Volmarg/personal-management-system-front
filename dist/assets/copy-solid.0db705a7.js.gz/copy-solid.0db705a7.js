var a="/assets/copy.ba208fc7.svg";export{a as default};
