var a="/assets/gitlab.a3dafc80.svg";export{a as default};
