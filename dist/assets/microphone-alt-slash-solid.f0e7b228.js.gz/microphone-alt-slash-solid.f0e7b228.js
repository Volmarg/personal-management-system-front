var s="/assets/microphone-alt-slash-solid.455d613f.svg";export{s as default};
