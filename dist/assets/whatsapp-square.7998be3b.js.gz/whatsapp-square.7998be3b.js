var a="/assets/whatsapp-square.8da52af4.svg";export{a as default};
