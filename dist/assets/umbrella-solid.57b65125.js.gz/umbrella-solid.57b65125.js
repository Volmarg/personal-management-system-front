var a="/assets/umbrella-solid.0cd84c5a.svg";export{a as default};
