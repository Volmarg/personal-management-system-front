var e="/assets/dice-three-solid.4ae04c23.svg";export{e as default};
