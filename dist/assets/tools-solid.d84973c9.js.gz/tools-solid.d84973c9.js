var s="/assets/tools-solid.d4eaf3b1.svg";export{s as default};
