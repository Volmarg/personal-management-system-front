var s="/assets/studiovinari.810bfb9e.svg";export{s as default};
