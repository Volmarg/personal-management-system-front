var s="/assets/chess-board-solid.6686bf9c.svg";export{s as default};
