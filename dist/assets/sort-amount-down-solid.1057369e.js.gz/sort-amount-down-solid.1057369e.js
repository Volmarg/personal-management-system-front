var a="/assets/sort-amount-down-solid.c0efa9ba.svg";export{a as default};
