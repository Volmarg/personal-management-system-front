var a="/assets/skyatlas.adff3a5f.svg";export{a as default};
