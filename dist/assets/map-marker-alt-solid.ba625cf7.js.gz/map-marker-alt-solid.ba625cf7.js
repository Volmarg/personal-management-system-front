var a="/assets/map-marker-alt-solid.2b46f86c.svg";export{a as default};
