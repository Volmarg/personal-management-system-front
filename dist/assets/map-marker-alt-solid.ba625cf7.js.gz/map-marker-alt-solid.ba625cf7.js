var a="/assets/map-marker-solid.2b46f86c.svg";export{a as default};
