var a="/assets/viadeo-square.6b403802.svg";export{a as default};
