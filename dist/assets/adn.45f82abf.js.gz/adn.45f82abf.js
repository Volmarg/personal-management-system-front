var a="/assets/adn.0ed57158.svg";export{a as default};
