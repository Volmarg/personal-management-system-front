var a="/assets/yahoo.667fc601.svg";export{a as default};
