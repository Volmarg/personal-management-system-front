var s="/assets/mix.8f777400.svg";export{s as default};
