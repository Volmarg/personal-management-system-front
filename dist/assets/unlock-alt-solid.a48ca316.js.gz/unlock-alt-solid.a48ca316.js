var s="/assets/unlock-alt-solid.82fe4795.svg";export{s as default};
