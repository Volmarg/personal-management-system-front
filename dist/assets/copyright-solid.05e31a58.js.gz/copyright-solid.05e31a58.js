var s="/assets/copyright-solid.d0ca5c12.svg";export{s as default};
