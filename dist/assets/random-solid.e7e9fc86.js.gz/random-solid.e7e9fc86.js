var a="/assets/random-solid.5ea90f03.svg";export{a as default};
