var a="/assets/font-awesome-flag.7061d2ef.svg";export{a as default};
