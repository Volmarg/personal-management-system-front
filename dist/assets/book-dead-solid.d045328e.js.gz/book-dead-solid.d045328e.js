var a="/assets/book-dead-solid.3c8a2fe3.svg";export{a as default};
