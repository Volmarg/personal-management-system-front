var s="/assets/phone-square-solid.c9a7bc68.svg";export{s as default};
