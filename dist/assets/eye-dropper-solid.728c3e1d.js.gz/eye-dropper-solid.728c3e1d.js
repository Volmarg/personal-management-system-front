var e="/assets/eye-dropper-solid.f97aefd1.svg";export{e as default};
