var a="/assets/mixcloud.05ad0c65.svg";export{a as default};
