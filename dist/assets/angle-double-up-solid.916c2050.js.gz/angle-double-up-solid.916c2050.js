var s="/assets/angle-double-up-solid.35344460.svg";export{s as default};
