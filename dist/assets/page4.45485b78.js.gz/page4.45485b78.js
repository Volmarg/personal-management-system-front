var e="/assets/page4.e8ce6db9.svg";export{e as default};
