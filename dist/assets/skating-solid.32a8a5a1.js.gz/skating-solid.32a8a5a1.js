var s="/assets/skating-solid.949736f0.svg";export{s as default};
