const a={translations:"translations"},s={user:{login:"admin@admin.admin",password:"admin"}};var i={directories:a,demo:s};export{i as default,s as demo,a as directories};
