var e="/assets/procedures-solid.ecdd969e.svg";export{e as default};
