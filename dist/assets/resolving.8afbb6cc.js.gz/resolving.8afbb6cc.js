var e="/assets/resolving.9bebe395.svg";export{e as default};
