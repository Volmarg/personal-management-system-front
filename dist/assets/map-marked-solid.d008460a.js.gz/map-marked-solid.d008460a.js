var a="/assets/map-marked-solid.c0c80326.svg";export{a as default};
