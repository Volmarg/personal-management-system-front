var s="/assets/pizza-slice-solid.b51be5a0.svg";export{s as default};
