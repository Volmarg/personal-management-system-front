var s="/assets/lemon-solid.294c6e2c.svg";export{s as default};
