var s="/assets/wine-glass-solid.57235f74.svg";export{s as default};
