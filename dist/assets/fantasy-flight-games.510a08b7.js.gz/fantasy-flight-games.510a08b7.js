var a="/assets/fantasy-flight-games.89d7ee82.svg";export{a as default};
