var a="/assets/wolf-pack-battalion.12d63ecc.svg";export{a as default};
