var a="/assets/hand-point-left-solid.a45e5553.svg";export{a as default};
