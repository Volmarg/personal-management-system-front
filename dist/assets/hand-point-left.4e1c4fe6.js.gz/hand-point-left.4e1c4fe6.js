var a="/assets/hand-point-left.a45e5553.svg";export{a as default};
