var a="/assets/qrcode-solid.ae1a3d07.svg";export{a as default};
