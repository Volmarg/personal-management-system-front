var s="/assets/dot-circle-solid.4c6f3e84.svg";export{s as default};
