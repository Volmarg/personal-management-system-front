var s="/assets/hand-scissors-solid.e46a555c.svg";export{s as default};
