var s="/assets/podcast-solid.e2cda607.svg";export{s as default};
