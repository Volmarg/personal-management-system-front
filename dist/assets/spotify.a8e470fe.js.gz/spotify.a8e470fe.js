var s="/assets/spotify.2303f46f.svg";export{s as default};
