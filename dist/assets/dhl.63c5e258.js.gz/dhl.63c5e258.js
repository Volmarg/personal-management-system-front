var s="/assets/dhl.c81334bf.svg";export{s as default};
