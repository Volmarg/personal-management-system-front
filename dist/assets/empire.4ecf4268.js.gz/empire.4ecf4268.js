var e="/assets/empire.b94ef7fe.svg";export{e as default};
