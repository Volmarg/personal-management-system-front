var a="/assets/alipay.520bda59.svg";export{a as default};
