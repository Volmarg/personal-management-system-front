var a="/assets/erlang.7f4461d8.svg";export{a as default};
