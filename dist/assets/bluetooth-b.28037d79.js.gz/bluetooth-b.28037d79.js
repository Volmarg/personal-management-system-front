var e="/assets/bluetooth-b.c2102ee8.svg";export{e as default};
