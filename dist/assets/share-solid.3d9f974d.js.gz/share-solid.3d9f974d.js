var s="/assets/share-solid.436248ab.svg";export{s as default};
