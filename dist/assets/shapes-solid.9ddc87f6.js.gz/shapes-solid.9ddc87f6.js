var s="/assets/shapes-solid.677765e6.svg";export{s as default};
