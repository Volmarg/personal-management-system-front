var a="/assets/dribbble-square.556c183a.svg";export{a as default};
