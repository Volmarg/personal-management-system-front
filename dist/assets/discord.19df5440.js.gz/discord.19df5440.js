var s="/assets/discord.5c26f9b2.svg";export{s as default};
