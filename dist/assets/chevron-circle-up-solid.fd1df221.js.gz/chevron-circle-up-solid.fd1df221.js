var c="/assets/chevron-circle-up-solid.ccf4ecc0.svg";export{c as default};
