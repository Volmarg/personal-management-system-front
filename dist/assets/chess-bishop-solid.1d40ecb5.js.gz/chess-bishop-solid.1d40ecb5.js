var s="/assets/chess-bishop-solid.d1e24598.svg";export{s as default};
