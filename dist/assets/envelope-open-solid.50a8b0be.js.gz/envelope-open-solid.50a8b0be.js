var e="/assets/envelope-open-solid.9ebcbfba.svg";export{e as default};
