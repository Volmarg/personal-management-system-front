var s="/assets/pause-solid.2fe7c77e.svg";export{s as default};
