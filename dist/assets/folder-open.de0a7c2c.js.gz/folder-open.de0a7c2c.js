var s="/assets/folder-open-solid.2782653c.svg";export{s as default};
