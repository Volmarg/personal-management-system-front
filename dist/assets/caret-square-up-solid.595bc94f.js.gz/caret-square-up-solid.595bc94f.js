var a="/assets/caret-square-up-solid.e6b029ac.svg";export{a as default};
