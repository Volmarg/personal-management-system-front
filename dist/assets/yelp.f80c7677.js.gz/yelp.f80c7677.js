var e="/assets/yelp.01142ef9.svg";export{e as default};
