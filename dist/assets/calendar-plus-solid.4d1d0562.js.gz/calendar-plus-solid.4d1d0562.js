var a="/assets/calendar-plus.d2790a20.svg";export{a as default};
