var a="/assets/calendar-plus-solid.d2790a20.svg";export{a as default};
