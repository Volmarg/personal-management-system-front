var a="/assets/canadian-maple-leaf.2dd18b96.svg";export{a as default};
