var s="/assets/grin-solid.756c762b.svg";export{s as default};
