var s="/assets/swimming-pool-solid.9d133dcc.svg";export{s as default};
