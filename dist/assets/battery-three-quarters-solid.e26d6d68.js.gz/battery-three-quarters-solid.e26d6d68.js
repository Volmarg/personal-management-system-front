var e="/assets/battery-three-quarters-solid.0294d62d.svg";export{e as default};
