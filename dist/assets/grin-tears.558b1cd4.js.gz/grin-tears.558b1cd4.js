var s="/assets/grin-tears-solid.b2c7c793.svg";export{s as default};
