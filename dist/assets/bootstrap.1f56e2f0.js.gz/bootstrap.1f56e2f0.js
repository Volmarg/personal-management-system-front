var s="/assets/bootstrap.f110b77e.svg";export{s as default};
