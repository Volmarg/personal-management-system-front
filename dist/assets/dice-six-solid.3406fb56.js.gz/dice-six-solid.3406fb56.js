var s="/assets/dice-six-solid.f0f68def.svg";export{s as default};
