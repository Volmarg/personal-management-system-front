var s="/assets/sliders-h-solid.c5e96ee4.svg";export{s as default};
