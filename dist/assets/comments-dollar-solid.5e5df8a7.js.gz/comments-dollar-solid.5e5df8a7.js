var s="/assets/comments-dollar-solid.c8bd73f8.svg";export{s as default};
