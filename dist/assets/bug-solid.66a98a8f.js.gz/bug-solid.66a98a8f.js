var s="/assets/bug-solid.f3a828bf.svg";export{s as default};
