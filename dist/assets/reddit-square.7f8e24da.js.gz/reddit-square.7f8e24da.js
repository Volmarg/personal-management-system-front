var s="/assets/reddit-square.6d4d7294.svg";export{s as default};
