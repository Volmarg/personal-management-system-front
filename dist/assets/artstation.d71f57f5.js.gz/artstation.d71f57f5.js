var a="/assets/artstation.bdce6891.svg";export{a as default};
