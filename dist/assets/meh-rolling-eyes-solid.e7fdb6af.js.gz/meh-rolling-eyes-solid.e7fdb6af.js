var e="/assets/meh-rolling-eyes.02f57424.svg";export{e as default};
