var a="/assets/hat-wizard-solid.ede74d50.svg";export{a as default};
