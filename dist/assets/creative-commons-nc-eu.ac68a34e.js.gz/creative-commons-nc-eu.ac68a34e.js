var e="/assets/creative-commons-nc-eu.23d590ce.svg";export{e as default};
