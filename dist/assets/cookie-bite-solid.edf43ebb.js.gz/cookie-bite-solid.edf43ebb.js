var a="/assets/cookie-bite-solid.ba616f5a.svg";export{a as default};
