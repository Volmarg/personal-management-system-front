var a="/assets/researchgate.c9f6ac4f.svg";export{a as default};
