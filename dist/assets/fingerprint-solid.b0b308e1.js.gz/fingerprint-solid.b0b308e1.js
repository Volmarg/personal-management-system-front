var s="/assets/fingerprint-solid.e9071c36.svg";export{s as default};
