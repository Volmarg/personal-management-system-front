var e="/assets/glide.62d43dbe.svg";export{e as default};
