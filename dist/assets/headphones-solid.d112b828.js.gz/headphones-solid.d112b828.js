var a="/assets/headphones-alt-solid.9ea9e88c.svg";export{a as default};
