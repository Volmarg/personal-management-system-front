var s="/assets/monero.3d23dcd3.svg";export{s as default};
