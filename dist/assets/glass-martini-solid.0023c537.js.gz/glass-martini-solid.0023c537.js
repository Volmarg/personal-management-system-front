var s="/assets/glass-martini-solid.13a14fb8.svg";export{s as default};
