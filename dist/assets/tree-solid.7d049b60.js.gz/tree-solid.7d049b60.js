var e="/assets/tree-solid.9cec6f02.svg";export{e as default};
