var e="/assets/reacteurope.cec9a5c2.svg";export{e as default};
