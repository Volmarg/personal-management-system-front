var a="/assets/basketball-ball-solid.c5b1a405.svg";export{a as default};
