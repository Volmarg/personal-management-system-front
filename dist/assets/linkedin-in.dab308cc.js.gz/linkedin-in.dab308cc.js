var e="/assets/linkedin-in.e1fb4bea.svg";export{e as default};
