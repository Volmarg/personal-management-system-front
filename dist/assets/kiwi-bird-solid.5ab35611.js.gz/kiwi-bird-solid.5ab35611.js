var s="/assets/kiwi-bird-solid.e0893064.svg";export{s as default};
