var s="/assets/user-shield-solid.bcddfa1a.svg";export{s as default};
