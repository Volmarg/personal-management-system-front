var a="/assets/hand-paper-solid.d4b63557.svg";export{a as default};
