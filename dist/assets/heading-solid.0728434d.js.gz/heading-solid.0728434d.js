var a="/assets/heading-solid.1ce8bf7a.svg";export{a as default};
