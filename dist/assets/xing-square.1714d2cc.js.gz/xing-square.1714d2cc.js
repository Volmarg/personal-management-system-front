var s="/assets/xing-square.63cc9fce.svg";export{s as default};
