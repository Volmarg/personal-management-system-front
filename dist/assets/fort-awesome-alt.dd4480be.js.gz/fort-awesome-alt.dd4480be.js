var a="/assets/fort-awesome-alt.ab3fec2a.svg";export{a as default};
