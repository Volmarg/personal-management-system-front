var a="/assets/openid.01a26a07.svg";export{a as default};
