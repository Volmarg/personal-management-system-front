var s="/assets/cc-visa.f05ed562.svg";export{s as default};
