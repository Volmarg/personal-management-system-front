var a="/assets/amazon.6cf8aeac.svg";export{a as default};
