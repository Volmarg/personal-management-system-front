var s="/assets/meh-rolling-eyes-solid.02f57424.svg";export{s as default};
