var a="/assets/caret-left-solid.af6785ff.svg";export{a as default};
