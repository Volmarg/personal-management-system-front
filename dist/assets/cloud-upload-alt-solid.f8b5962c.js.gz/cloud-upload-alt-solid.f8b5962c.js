var a="/assets/cloud-upload-alt-solid.ca714454.svg";export{a as default};
