var s="/assets/search-dollar-solid.802ccc4f.svg";export{s as default};
