var s="/assets/share-square-solid.91850ae7.svg";export{s as default};
