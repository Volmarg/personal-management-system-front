var a="/assets/vk.7cae5395.svg";export{a as default};
