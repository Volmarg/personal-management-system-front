var s="/assets/windows.d2132947.svg";export{s as default};
