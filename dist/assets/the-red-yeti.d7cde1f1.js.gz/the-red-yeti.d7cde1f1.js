var e="/assets/the-red-yeti.e87e457f.svg";export{e as default};
