var s="/assets/align-justify-solid.e91ec62a.svg";export{s as default};
