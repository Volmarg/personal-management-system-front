var s="/assets/odnoklassniki-square.db5f20fb.svg";export{s as default};
