var s="/assets/road-solid.7c2f9643.svg";export{s as default};
