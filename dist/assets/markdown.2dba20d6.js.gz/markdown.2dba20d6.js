var a="/assets/markdown.e6142598.svg";export{a as default};
