var s="/assets/mouse-pointer-solid.2b50f12b.svg";export{s as default};
