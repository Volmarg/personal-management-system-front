var s="/assets/suitcase-solid.b824db75.svg";export{s as default};
