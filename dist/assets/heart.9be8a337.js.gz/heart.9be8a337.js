var a="/assets/heart.d75176de.svg";export{a as default};
