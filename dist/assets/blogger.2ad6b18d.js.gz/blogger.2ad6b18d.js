var s="/assets/blogger.dd80fc27.svg";export{s as default};
