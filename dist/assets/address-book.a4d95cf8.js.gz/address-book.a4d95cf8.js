var s="/assets/address-book-solid.076d4cd0.svg";export{s as default};
