var s="/assets/calendar-times-solid.6c4151c0.svg";export{s as default};
