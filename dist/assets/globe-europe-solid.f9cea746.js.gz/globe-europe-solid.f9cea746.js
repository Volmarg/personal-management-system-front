var e="/assets/globe-europe-solid.ec742d7d.svg";export{e as default};
