var a="/assets/smile-beam-solid.a51ea2a4.svg";export{a as default};
