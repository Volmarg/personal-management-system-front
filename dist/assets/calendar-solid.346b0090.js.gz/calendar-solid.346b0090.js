var a="/assets/calendar-alt.8a56c556.svg";export{a as default};
