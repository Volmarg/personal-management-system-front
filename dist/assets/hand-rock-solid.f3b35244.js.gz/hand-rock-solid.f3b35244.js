var s="/assets/hand-rock-solid.57812f14.svg";export{s as default};
