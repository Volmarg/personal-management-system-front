var a="/assets/hand-rock.57812f14.svg";export{a as default};
