var a="/assets/github-alt.aa01d8a6.svg";export{a as default};
