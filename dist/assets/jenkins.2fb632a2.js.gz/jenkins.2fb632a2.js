var a="/assets/jenkins.01eda9ba.svg";export{a as default};
