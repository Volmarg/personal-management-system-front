var a="/assets/id-card-solid.bd2a1bb9.svg";export{a as default};
