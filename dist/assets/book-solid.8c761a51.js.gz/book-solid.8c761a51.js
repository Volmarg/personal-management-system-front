var s="/assets/book-solid.c5dccd9b.svg";export{s as default};
