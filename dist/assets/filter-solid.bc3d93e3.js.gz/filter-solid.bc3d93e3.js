var s="/assets/filter-solid.c5db8d03.svg";export{s as default};
