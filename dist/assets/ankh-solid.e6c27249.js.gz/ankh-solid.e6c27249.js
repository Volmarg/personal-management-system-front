var a="/assets/ankh-solid.93a7c8b1.svg";export{a as default};
