var a="/assets/creative-commons-zero.ca51cc60.svg";export{a as default};
