var s="/assets/print-solid.9bc9c6f3.svg";export{s as default};
