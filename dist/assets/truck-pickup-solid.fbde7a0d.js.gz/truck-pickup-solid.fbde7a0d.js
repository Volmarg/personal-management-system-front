var s="/assets/truck-pickup-solid.1dedc4cc.svg";export{s as default};
