var a="/assets/money-bill-wave-alt-solid.985eb529.svg";export{a as default};
