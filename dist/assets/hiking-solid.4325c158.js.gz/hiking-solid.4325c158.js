var s="/assets/hiking-solid.4d77202b.svg";export{s as default};
