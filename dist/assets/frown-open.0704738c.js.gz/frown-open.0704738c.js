var a="/assets/frown-open.110b4ad0.svg";export{a as default};
