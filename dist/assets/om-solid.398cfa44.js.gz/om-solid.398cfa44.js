var s="/assets/om-solid.0d5e79e3.svg";export{s as default};
