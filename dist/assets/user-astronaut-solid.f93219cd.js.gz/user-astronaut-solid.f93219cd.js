var s="/assets/user-astronaut-solid.0f848219.svg";export{s as default};
