var s="/assets/kiss-beam-solid.a28edc89.svg";export{s as default};
