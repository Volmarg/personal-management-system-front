var s="/assets/kiss-beam.a28edc89.svg";export{s as default};
