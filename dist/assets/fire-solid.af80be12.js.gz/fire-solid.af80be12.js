var s="/assets/fire-solid.964fba46.svg";export{s as default};
