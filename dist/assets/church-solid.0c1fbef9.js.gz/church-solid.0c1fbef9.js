var s="/assets/church-solid.07d32672.svg";export{s as default};
