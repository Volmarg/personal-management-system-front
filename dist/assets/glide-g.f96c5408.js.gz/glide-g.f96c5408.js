var a="/assets/glide-g.d83ead64.svg";export{a as default};
