var a="/assets/trademark-solid.a3612164.svg";export{a as default};
