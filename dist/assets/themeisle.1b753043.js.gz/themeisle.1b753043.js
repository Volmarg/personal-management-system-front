var e="/assets/themeisle.32837028.svg";export{e as default};
