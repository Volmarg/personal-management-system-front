var a="/assets/themeco.4c1a45d7.svg";export{a as default};
