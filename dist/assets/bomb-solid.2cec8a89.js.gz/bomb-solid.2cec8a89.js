var a="/assets/bomb-solid.aee3a950.svg";export{a as default};
