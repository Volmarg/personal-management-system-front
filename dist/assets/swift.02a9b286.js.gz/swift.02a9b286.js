var s="/assets/swift.3541d502.svg";export{s as default};
