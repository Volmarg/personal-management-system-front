var s="/assets/glass-cheers-solid.d2aab434.svg";export{s as default};
