var s="/assets/yen-sign-solid.df73fcce.svg";export{s as default};
