var a="/assets/ravelry.db3e768c.svg";export{a as default};
