var s="/assets/male-solid.99933207.svg";export{s as default};
