var e="/assets/seedling-solid.e0bc92ed.svg";export{e as default};
