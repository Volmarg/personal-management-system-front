var s="/assets/campground-solid.27cb374e.svg";export{s as default};
