var s="/assets/clone-solid.fbe3df7a.svg";export{s as default};
