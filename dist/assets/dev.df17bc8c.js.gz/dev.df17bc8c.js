var a="/assets/dev.da99a4f7.svg";export{a as default};
