var s="/assets/chess-solid.eac55a66.svg";export{s as default};
