var s="/assets/democrat-solid.128e118f.svg";export{s as default};
