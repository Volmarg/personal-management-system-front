var s="/assets/swimmer-solid.0086fc17.svg";export{s as default};
