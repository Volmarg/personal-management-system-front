var s="/assets/object-ungroup.45b5328c.svg";export{s as default};
