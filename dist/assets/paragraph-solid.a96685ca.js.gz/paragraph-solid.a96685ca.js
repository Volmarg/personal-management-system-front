var a="/assets/paragraph-solid.cb902e7a.svg";export{a as default};
