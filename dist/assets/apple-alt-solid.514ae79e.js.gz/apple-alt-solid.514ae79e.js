var a="/assets/apple-alt-solid.04683707.svg";export{a as default};
