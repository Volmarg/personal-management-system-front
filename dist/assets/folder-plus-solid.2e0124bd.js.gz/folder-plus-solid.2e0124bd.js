var s="/assets/folder-plus-solid.a3b88401.svg";export{s as default};
