var s="/assets/user-alt-slash-solid.343c79aa.svg";export{s as default};
