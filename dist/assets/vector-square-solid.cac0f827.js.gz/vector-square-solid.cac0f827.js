var s="/assets/vector-square-solid.42a71054.svg";export{s as default};
