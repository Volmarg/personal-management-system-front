var s="/assets/dna-solid.8d0774e9.svg";export{s as default};
