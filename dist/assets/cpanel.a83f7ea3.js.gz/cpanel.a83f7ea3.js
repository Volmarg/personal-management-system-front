var a="/assets/cpanel.e5494044.svg";export{a as default};
