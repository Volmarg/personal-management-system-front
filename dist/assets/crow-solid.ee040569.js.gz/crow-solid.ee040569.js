var s="/assets/crow-solid.02f72423.svg";export{s as default};
