var e="/assets/bezier-curve-solid.ab8fdf7c.svg";export{e as default};
