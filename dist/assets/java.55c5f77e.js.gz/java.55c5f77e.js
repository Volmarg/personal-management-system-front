var a="/assets/java.91480021.svg";export{a as default};
