var s="/assets/subscript-solid.26c141df.svg";export{s as default};
