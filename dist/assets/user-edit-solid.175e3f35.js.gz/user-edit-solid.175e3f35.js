var s="/assets/user-edit-solid.9b6101ac.svg";export{s as default};
