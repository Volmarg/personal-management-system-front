var s="/assets/route-solid.772e546d.svg";export{s as default};
