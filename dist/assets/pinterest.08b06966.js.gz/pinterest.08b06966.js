var s="/assets/pinterest.4797df20.svg";export{s as default};
