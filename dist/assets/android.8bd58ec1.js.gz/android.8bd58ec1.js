var a="/assets/android.e15558f3.svg";export{a as default};
