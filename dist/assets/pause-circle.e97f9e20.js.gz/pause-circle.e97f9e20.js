var e="/assets/pause-circle.27ee0317.svg";export{e as default};
