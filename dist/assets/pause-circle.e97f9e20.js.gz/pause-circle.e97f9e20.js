var e="/assets/pause-circle-solid.27ee0317.svg";export{e as default};
