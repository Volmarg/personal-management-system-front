var s="/assets/dolly-solid.0dde5890.svg";export{s as default};
