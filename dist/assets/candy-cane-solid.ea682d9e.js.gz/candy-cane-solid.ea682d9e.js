var a="/assets/candy-cane-solid.19fe76d9.svg";export{a as default};
