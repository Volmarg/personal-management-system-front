var s="/assets/joint-solid.d0b6fb17.svg";export{s as default};
