import{a as o}from"./index.db8bde11.js";const s={data:()=>({isDemo:!1}),mounted(){this.isDemo=o.isDemo()}};export{s as _};
