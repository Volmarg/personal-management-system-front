var a="/assets/amilia.c6e18c06.svg";export{a as default};
