var e="/assets/chevron-circle-left-solid.49ff75a2.svg";export{e as default};
