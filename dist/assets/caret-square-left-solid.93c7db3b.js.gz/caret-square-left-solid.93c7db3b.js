var e="/assets/caret-square-left-solid.118633e1.svg";export{e as default};
