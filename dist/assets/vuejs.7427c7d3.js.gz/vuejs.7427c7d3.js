var s="/assets/vuejs.2390f283.svg";export{s as default};
