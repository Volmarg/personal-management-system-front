var s="/assets/thumbs-down-solid.2f8c314b.svg";export{s as default};
