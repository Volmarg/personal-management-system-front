var a="/assets/cotton-bureau.87fd1704.svg";export{a as default};
