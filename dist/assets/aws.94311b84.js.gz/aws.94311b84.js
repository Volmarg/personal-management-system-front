var a="/assets/aws.4397babc.svg";export{a as default};
