var s="/assets/wix.41830d37.svg";export{s as default};
