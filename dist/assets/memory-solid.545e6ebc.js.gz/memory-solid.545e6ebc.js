var s="/assets/memory-solid.cb451f8e.svg";export{s as default};
