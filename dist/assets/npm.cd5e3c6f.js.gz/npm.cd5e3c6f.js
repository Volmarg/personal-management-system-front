var s="/assets/npm.69db51f8.svg";export{s as default};
