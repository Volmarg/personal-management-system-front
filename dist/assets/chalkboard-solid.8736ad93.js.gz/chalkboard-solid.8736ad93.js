var a="/assets/chalkboard-solid.6e402f94.svg";export{a as default};
