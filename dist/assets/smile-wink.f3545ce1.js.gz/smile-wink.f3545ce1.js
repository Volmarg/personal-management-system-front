var s="/assets/grin-wink-solid.c6ca55b5.svg";export{s as default};
