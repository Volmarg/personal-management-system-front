var a="/assets/car-alt-solid.543f980a.svg";export{a as default};
