var s="/assets/mosque-solid.acc48a12.svg";export{s as default};
