var s="/assets/bitcoin.41f30062.svg";export{s as default};
