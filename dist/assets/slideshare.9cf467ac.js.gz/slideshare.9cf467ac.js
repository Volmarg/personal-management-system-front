var s="/assets/slideshare.cd6da551.svg";export{s as default};
