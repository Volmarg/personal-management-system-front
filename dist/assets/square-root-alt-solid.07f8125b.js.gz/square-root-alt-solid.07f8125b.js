var a="/assets/square-root-alt-solid.1cda2000.svg";export{a as default};
