var s="/assets/music-solid.8731bcdc.svg";export{s as default};
