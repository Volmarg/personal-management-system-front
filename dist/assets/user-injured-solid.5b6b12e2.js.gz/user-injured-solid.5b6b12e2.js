var s="/assets/user-injured-solid.cdfd5651.svg";export{s as default};
