var s="/assets/spa-solid.633047ba.svg";export{s as default};
