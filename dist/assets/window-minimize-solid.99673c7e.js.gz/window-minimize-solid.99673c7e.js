var s="/assets/window-minimize-solid.7841342d.svg";export{s as default};
