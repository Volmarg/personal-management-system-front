var s="/assets/object-group-solid.2be2d9ff.svg";export{s as default};
