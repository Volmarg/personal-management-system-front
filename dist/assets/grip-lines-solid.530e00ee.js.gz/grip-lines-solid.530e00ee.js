var s="/assets/grip-lines-solid.a16b75f8.svg";export{s as default};
