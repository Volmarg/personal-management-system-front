var s="/assets/user-md-solid.0f981673.svg";export{s as default};
