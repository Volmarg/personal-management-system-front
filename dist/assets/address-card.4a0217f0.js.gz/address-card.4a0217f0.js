var a="/assets/address-card.a828dd33.svg";export{a as default};
