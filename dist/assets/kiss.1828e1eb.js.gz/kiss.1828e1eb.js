var s="/assets/kiss-solid.ce3cc3b0.svg";export{s as default};
