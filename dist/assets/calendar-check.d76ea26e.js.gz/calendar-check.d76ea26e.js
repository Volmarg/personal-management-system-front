var a="/assets/calendar-check-solid.7d70ef07.svg";export{a as default};
