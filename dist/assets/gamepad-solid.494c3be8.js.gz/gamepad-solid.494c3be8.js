var a="/assets/gamepad-solid.e7b24195.svg";export{a as default};
