var s="/assets/shopware.f5555723.svg";export{s as default};
