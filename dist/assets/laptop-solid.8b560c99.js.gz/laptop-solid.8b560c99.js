var a="/assets/laptop-solid.aedde768.svg";export{a as default};
