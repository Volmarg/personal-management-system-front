var a="/assets/align-left-solid.9cfa0333.svg";export{a as default};
