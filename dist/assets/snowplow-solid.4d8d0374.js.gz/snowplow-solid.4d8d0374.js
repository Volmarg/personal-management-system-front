var s="/assets/snowplow-solid.10e484c8.svg";export{s as default};
