var e="/assets/home-solid.f6cea9eb.svg";export{e as default};
