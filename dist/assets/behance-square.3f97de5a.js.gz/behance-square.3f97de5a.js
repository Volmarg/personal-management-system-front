var a="/assets/behance-square.569cc525.svg";export{a as default};
