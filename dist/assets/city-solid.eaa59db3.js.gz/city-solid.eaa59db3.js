var s="/assets/city-solid.e8902af1.svg";export{s as default};
