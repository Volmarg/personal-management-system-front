var s="/assets/lastfm.620b3141.svg";export{s as default};
