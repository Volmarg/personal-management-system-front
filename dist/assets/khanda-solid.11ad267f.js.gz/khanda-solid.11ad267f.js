var a="/assets/khanda-solid.bb2fe3f0.svg";export{a as default};
