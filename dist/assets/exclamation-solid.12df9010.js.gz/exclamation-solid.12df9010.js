var a="/assets/exclamation-solid.312df1e6.svg";export{a as default};
