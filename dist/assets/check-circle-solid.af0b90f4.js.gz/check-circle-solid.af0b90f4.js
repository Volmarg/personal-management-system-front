var s="/assets/check-circle-solid.93d3f476.svg";export{s as default};
