var a="/assets/opera.83dbdd05.svg";export{a as default};
