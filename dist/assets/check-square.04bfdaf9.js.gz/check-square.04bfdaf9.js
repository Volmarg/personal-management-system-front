var e="/assets/check-square.30e56b80.svg";export{e as default};
