var s="/assets/door-closed-solid.d1072d45.svg";export{s as default};
