var a="/assets/mail-bulk-solid.d5d454a6.svg";export{a as default};
