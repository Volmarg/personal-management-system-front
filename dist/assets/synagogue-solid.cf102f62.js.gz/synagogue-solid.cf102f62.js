var s="/assets/synagogue-solid.9a13e379.svg";export{s as default};
