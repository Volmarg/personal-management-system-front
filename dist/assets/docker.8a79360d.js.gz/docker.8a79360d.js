var e="/assets/docker.e0a12e45.svg";export{e as default};
