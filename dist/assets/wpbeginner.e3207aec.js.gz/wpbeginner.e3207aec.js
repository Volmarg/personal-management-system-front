var e="/assets/wpbeginner.eebf0ac6.svg";export{e as default};
