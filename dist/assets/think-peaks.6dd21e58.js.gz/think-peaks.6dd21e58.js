var s="/assets/think-peaks.d9650005.svg";export{s as default};
