var a="/assets/rocketchat.f8572404.svg";export{a as default};
