var s="/assets/truck-monster-solid.22667218.svg";export{s as default};
