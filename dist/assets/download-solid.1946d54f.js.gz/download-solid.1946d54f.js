var a="/assets/download-solid.cacc4d91.svg";export{a as default};
