var s="/assets/undo-solid.9d7a3560.svg";export{s as default};
