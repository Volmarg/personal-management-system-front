var s="/assets/viber.f4583930.svg";export{s as default};
