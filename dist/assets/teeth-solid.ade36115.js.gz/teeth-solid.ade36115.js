var s="/assets/teeth-solid.69150753.svg";export{s as default};
