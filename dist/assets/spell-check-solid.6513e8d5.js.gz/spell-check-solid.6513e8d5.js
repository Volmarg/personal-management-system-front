var s="/assets/spell-check-solid.68c55fd3.svg";export{s as default};
