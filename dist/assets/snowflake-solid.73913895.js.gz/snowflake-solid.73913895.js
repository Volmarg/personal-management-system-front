var s="/assets/snowflake-solid.66ffd366.svg";export{s as default};
