var s="/assets/snowflake.66ffd366.svg";export{s as default};
