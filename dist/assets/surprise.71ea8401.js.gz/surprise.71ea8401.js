var s="/assets/frown-open-solid.110b4ad0.svg";export{s as default};
