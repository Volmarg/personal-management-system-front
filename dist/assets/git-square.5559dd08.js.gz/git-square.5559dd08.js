var a="/assets/git-square.1b8551a6.svg";export{a as default};
