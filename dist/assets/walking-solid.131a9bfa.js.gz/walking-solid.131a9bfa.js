var a="/assets/walking-solid.2fade894.svg";export{a as default};
