var a="/assets/id-badge-solid.bda82830.svg";export{a as default};
