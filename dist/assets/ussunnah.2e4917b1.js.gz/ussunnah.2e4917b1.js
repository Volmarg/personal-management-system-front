var s="/assets/ussunnah.b784b9f3.svg";export{s as default};
