var s="/assets/sms-solid.f01aeddd.svg";export{s as default};
