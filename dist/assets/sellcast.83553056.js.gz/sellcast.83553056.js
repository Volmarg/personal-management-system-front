var s="/assets/sellcast.82516cda.svg";export{s as default};
