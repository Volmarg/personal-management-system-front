var s="/assets/osi.1e6eb264.svg";export{s as default};
