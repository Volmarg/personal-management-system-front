var s="/assets/theater-masks-solid.3837ce8a.svg";export{s as default};
