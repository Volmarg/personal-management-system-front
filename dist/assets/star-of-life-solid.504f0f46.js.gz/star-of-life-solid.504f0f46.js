var a="/assets/star-of-life-solid.f67aa13e.svg";export{a as default};
