var s="/assets/arrows-alt-solid.b5ff2cec.svg";export{s as default};
