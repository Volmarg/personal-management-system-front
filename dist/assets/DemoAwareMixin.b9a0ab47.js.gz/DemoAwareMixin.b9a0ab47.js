import{a as o}from"./index.7d9fe974.js";const s={data:()=>({isDemo:!1}),mounted(){this.isDemo=o.isDemo()}};export{s as _};
