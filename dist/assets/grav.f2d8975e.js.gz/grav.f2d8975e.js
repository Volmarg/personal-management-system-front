var a="/assets/grav.73907891.svg";export{a as default};
