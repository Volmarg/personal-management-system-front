var a="/assets/readme.9b033244.svg";export{a as default};
