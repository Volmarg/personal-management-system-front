var a="/assets/airbnb.e53ef02b.svg";export{a as default};
