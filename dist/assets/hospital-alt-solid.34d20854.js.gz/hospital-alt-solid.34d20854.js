var a="/assets/clinic-medical-solid.56da3af2.svg";export{a as default};
