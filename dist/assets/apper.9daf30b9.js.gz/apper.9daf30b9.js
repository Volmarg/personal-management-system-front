var a="/assets/apper.ced22adc.svg";export{a as default};
