var a="/assets/linux.87a2c875.svg";export{a as default};
