var a="/assets/speaker-deck.082513fa.svg";export{a as default};
