var s="/assets/comment-solid.a9fc102f.svg";export{s as default};
