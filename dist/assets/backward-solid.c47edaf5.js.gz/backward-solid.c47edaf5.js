var a="/assets/backward-solid.e4c58473.svg";export{a as default};
