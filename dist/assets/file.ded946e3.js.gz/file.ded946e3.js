var s="/assets/file-solid.876c0e28.svg";export{s as default};
