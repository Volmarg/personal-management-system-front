var a="/assets/searchengin.3ac0e572.svg";export{a as default};
