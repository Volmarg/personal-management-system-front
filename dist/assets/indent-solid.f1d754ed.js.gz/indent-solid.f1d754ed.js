var a="/assets/indent-solid.5b1a82a2.svg";export{a as default};
