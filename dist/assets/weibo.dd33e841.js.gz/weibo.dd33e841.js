var a="/assets/weibo.f3efb5ad.svg";export{a as default};
