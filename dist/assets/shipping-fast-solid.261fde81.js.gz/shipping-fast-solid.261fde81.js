var s="/assets/shipping-fast-solid.7d66a6a1.svg";export{s as default};
