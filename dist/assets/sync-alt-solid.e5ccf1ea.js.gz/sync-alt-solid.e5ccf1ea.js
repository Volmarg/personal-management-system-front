var s="/assets/sync-alt-solid.3fbd45ce.svg";export{s as default};
