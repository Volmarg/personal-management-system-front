var a="/assets/female-solid.05c3aa92.svg";export{a as default};
