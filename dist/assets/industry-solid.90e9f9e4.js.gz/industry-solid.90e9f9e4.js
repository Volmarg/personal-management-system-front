var s="/assets/industry-solid.11ee7046.svg";export{s as default};
