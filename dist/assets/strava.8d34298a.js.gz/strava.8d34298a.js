var a="/assets/strava.9b43a57c.svg";export{a as default};
