var e="/assets/weixin.6e9cccd7.svg";export{e as default};
