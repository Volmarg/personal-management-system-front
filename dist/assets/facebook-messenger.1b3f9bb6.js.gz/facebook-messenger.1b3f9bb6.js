var e="/assets/facebook-messenger.58c06413.svg";export{e as default};
