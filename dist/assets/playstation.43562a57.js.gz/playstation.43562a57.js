var a="/assets/playstation.437cabc2.svg";export{a as default};
