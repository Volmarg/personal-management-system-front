var s="/assets/dollar-sign-solid.acc8d909.svg";export{s as default};
