var a="/assets/stack-exchange.44048847.svg";export{a as default};
