var e="/assets/google-drive.d6ec6f9c.svg";export{e as default};
