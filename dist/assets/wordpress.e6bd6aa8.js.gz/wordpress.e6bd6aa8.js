var s="/assets/wordpress.3c2a9a63.svg";export{s as default};
