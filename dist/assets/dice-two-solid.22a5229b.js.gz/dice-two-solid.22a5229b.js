var s="/assets/dice-two-solid.7f66867f.svg";export{s as default};
