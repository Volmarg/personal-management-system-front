var a="/assets/arrow-circle-down-solid.4b93ab1a.svg";export{a as default};
