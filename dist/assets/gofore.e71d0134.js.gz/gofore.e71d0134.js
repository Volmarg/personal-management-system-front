var s="/assets/gofore.b1f87174.svg";export{s as default};
