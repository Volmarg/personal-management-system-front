var e="/assets/chart-line-solid.8e4e6881.svg";export{e as default};
