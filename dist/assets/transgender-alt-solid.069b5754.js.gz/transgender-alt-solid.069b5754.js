var s="/assets/transgender-alt-solid.6b01011e.svg";export{s as default};
