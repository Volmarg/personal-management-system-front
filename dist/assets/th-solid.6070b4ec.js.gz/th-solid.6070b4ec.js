var s="/assets/th-solid.86b2942c.svg";export{s as default};
