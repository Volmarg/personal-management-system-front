var e="/assets/chevron-circle-right-solid.7658ecf7.svg";export{e as default};
