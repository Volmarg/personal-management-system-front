var s="/assets/less-than-solid.ccab97b4.svg";export{s as default};
