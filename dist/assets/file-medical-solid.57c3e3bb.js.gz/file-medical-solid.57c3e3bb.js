var s="/assets/file-medical-solid.96924687.svg";export{s as default};
