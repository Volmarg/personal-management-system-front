var a="/assets/football-ball-solid.cedb00c4.svg";export{a as default};
