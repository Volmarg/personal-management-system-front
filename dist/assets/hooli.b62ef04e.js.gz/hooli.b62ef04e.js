var s="/assets/hooli.8037514c.svg";export{s as default};
