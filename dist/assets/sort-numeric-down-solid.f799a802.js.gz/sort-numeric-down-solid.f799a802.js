var s="/assets/sort-numeric-down-solid.0a42cfd6.svg";export{s as default};
