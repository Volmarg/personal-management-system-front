var s="/assets/table-solid.e0644763.svg";export{s as default};
