var s="/assets/lira-sign-solid.cc053f7f.svg";export{s as default};
