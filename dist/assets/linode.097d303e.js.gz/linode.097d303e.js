var s="/assets/linode.76cd96fd.svg";export{s as default};
