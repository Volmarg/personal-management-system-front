var s="/assets/angle-right-solid.2c8e9f14.svg";export{s as default};
