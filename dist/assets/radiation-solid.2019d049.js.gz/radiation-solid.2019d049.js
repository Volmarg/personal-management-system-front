var a="/assets/radiation-solid.25446145.svg";export{a as default};
