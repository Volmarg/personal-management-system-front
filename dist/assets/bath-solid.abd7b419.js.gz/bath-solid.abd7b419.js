var s="/assets/bath-solid.868e94f9.svg";export{s as default};
