var a="/assets/hanukiah-solid.690bcfdc.svg";export{a as default};
