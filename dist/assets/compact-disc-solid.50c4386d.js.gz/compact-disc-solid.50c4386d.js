var s="/assets/compact-disc-solid.633deea9.svg";export{s as default};
