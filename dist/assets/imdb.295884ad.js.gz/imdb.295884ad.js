var s="/assets/imdb.809e169f.svg";export{s as default};
