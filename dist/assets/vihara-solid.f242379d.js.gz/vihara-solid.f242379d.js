var a="/assets/vihara-solid.485c8fd5.svg";export{a as default};
