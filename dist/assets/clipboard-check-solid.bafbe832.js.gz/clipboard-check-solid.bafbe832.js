var s="/assets/clipboard-check-solid.77260442.svg";export{s as default};
