var a="/assets/clone.23a481d7.svg";export{a as default};
