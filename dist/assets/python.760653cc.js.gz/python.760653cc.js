var e="/assets/python.dc03ebeb.svg";export{e as default};
