var s="/assets/minus-square.738de406.svg";export{s as default};
