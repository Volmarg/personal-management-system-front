var s="/assets/universal-access-solid.17a320fa.svg";export{s as default};
