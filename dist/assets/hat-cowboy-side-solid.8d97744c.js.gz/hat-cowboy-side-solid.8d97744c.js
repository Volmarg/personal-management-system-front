var s="/assets/hat-cowboy-side-solid.c15652ac.svg";export{s as default};
