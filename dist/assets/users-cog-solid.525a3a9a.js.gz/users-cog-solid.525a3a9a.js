var s="/assets/users-cog-solid.aba8d6bd.svg";export{s as default};
