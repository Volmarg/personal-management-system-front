var s="/assets/cheese-solid.64903c5a.svg";export{s as default};
