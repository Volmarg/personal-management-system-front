var s="/assets/sketch.945da377.svg";export{s as default};
