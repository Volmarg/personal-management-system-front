var s="/assets/ioxhost.032d2d75.svg";export{s as default};
