var a="/assets/adobe.0a292d43.svg";export{a as default};
