var s="/assets/snowboarding-solid.ba5f02cf.svg";export{s as default};
