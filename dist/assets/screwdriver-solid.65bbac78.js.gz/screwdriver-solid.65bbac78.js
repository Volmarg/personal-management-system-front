var s="/assets/screwdriver-solid.69cb7219.svg";export{s as default};
