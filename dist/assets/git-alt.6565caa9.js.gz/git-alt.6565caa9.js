var a="/assets/git-alt.742b3283.svg";export{a as default};
