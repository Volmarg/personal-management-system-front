var e="/assets/beer-solid.53351e86.svg";export{e as default};
