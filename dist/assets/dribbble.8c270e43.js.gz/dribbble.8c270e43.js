var a="/assets/dribbble.ae993f01.svg";export{a as default};
