var a="/assets/uber.4270afad.svg";export{a as default};
