var s="/assets/poll-solid.461ebcd3.svg";export{s as default};
