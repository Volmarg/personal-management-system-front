var a="/assets/phoenix-squadron.9c27ea57.svg";export{a as default};
