var s="/assets/swatchbook-solid.18cba8f0.svg";export{s as default};
