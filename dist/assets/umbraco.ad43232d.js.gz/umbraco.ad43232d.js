var a="/assets/umbraco.5e2c7e09.svg";export{a as default};
