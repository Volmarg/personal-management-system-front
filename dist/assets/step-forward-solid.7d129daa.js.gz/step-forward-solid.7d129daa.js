var s="/assets/step-forward-solid.c0187ba4.svg";export{s as default};
