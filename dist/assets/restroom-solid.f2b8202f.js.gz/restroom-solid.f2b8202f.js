var s="/assets/restroom-solid.ac14913b.svg";export{s as default};
