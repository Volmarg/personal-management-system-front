var s="/assets/file-image-solid.3d83126b.svg";export{s as default};
