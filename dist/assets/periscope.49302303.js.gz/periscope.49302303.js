var s="/assets/periscope.d07c7b21.svg";export{s as default};
