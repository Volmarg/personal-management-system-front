var s="/assets/microscope-solid.09ffb88e.svg";export{s as default};
