var s="/assets/audio-description-solid.13c5e16e.svg";export{s as default};
