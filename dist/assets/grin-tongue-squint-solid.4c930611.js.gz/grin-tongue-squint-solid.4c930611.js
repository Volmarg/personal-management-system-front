var s="/assets/grin-tongue-squint-solid.77180912.svg";export{s as default};
