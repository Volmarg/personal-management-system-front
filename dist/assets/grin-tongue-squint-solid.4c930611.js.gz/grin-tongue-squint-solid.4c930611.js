var s="/assets/grin-tongue-squint.77180912.svg";export{s as default};
