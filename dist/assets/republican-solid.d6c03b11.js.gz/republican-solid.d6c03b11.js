var a="/assets/republican-solid.85e98a36.svg";export{a as default};
