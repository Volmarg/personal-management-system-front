var s="/assets/highlighter-solid.d6c224da.svg";export{s as default};
