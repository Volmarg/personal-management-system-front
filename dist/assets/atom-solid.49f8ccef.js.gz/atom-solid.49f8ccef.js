var s="/assets/atom-solid.28898362.svg";export{s as default};
