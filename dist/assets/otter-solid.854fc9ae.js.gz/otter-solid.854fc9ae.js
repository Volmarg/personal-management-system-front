var s="/assets/otter-solid.94095b2e.svg";export{s as default};
