var a="/assets/biohazard-solid.27f88150.svg";export{a as default};
