var a="/assets/digital-ocean.d5c1c661.svg";export{a as default};
