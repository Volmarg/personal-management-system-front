var s="/assets/bread-slice-solid.5a9dc264.svg";export{s as default};
