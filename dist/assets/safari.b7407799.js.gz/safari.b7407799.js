var a="/assets/safari.1ab3f14f.svg";export{a as default};
