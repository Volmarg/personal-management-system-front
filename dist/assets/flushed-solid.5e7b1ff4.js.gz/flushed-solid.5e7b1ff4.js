var s="/assets/flushed.310fddc6.svg";export{s as default};
