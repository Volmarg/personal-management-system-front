var s="/assets/flushed-solid.310fddc6.svg";export{s as default};
