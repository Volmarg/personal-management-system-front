var s="/assets/file-pdf-solid.a4bfd65d.svg";export{s as default};
