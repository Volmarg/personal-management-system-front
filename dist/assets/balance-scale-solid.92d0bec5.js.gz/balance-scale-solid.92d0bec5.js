var a="/assets/balance-scale-solid.a99ea19c.svg";export{a as default};
