var a="/assets/freebsd.dfa5bada.svg";export{a as default};
