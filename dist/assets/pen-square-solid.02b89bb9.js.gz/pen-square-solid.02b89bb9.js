var s="/assets/pen-square-solid.ea8c9297.svg";export{s as default};
