var a="/assets/quran-solid.2def9ab4.svg";export{a as default};
