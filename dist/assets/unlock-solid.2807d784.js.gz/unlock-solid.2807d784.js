var s="/assets/lock-open-solid.24d635db.svg";export{s as default};
