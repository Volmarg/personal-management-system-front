var s="/assets/truck-moving-solid.31cf6ba1.svg";export{s as default};
