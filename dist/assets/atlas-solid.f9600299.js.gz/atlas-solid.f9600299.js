var a="/assets/atlas-solid.2a728ac0.svg";export{a as default};
