var s="/assets/sticky-note-solid.51ad6154.svg";export{s as default};
