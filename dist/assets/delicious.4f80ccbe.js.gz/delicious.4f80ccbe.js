var s="/assets/delicious.d425fb55.svg";export{s as default};
