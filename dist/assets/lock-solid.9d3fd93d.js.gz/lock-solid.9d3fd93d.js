var s="/assets/lock-solid.13d31de2.svg";export{s as default};
