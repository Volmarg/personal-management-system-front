var s="/assets/bullseye-solid.c4948956.svg";export{s as default};
