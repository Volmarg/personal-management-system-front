var a="/assets/star-half-solid.3adebc30.svg";export{a as default};
