var s="/assets/ad-solid.c2c86232.svg";export{s as default};
