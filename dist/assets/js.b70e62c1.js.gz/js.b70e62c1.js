var s="/assets/js.1226514c.svg";export{s as default};
