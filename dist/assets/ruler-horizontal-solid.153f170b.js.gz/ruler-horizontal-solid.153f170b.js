var s="/assets/ruler-horizontal-solid.675720e0.svg";export{s as default};
