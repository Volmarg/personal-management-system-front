var a="/assets/bell.c7308aaf.svg";export{a as default};
