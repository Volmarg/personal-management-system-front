var a="/assets/bell-solid.c7308aaf.svg";export{a as default};
