var s="/assets/peace-solid.6078f4f5.svg";export{s as default};
