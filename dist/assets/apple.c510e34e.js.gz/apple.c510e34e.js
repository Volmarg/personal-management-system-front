var a="/assets/apple.017ac2c1.svg";export{a as default};
