var s="/assets/place-of-worship-solid.60219808.svg";export{s as default};
