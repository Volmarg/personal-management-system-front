var s="/assets/typo3.91db119f.svg";export{s as default};
