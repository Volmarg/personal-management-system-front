var s="/assets/desktop-solid.8be46fc3.svg";export{s as default};
