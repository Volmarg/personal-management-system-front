var s="/assets/user-clock-solid.e33d15e7.svg";export{s as default};
