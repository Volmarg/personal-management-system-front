var a="/assets/gratipay.62879900.svg";export{a as default};
