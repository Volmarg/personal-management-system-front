var s="/assets/css3-alt.d59e9ce5.svg";export{s as default};
