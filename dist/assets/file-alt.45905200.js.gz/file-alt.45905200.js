var a="/assets/file-alt.b198c8a4.svg";export{a as default};
