var a="/assets/file-alt-solid.b198c8a4.svg";export{a as default};
