var s="/assets/arrow-left-solid.7cf4248f.svg";export{s as default};
