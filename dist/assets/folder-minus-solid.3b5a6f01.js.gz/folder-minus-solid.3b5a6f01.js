var s="/assets/folder-minus-solid.76878d47.svg";export{s as default};
