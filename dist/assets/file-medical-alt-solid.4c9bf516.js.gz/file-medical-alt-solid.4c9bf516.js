var a="/assets/file-medical-alt-solid.02eda428.svg";export{a as default};
