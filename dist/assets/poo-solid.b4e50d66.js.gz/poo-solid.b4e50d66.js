var s="/assets/poo-solid.624d637e.svg";export{s as default};
