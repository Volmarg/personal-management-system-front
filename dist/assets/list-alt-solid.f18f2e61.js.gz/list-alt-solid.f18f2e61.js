var a="/assets/list-alt.1c0a873b.svg";export{a as default};
