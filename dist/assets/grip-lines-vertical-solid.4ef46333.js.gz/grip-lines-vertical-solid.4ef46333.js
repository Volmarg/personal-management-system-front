var s="/assets/grip-lines-vertical-solid.75679167.svg";export{s as default};
