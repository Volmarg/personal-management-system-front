var s="/assets/funnel-dollar-solid.857e0f79.svg";export{s as default};
