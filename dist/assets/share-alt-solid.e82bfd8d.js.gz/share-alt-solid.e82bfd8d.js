var a="/assets/share-alt-solid.75f6d97a.svg";export{a as default};
