var a="/assets/arrow-alt-circle-right-solid.b9bceb06.svg";export{a as default};
