var a="/assets/arrow-alt-circle-right.b9bceb06.svg";export{a as default};
