var s="/assets/creative-commons-sampling-plus.95c89b92.svg";export{s as default};
