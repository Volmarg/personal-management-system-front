import{a as o}from"./index.fd0df9df.js";const s={data:()=>({isDemo:!1}),mounted(){this.isDemo=o.isDemo()}};export{s as _};
