var a="/assets/joomla.61b4a9d3.svg";export{a as default};
