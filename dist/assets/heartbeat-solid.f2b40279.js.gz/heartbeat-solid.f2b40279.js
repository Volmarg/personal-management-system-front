var a="/assets/heartbeat-solid.5dbc85de.svg";export{a as default};
