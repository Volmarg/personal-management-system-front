var a="/assets/lyft.eb2c444a.svg";export{a as default};
