var s="/assets/list-ol-solid.05c6b3a8.svg";export{s as default};
