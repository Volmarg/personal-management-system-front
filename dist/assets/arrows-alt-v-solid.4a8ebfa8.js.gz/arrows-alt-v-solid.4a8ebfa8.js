var s="/assets/arrows-alt-v-solid.7b625c0f.svg";export{s as default};
