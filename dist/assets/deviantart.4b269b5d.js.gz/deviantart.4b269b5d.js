var a="/assets/deviantart.9404961f.svg";export{a as default};
