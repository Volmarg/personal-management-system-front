var s="/assets/pushed.a990f9d8.svg";export{s as default};
