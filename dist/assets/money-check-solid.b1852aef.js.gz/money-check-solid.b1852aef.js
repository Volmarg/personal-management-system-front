var s="/assets/money-check-solid.29b92570.svg";export{s as default};
