var a="/assets/megaport.498e1a38.svg";export{a as default};
