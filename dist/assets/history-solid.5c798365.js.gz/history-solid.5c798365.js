var s="/assets/history-solid.8c1104cf.svg";export{s as default};
