var s="/assets/goodreads.91f1e427.svg";export{s as default};
