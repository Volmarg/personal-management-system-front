import{_ as a,o as r,e}from"./index.5c1c3a9f.js";var t=a({data:()=>({})},[["render",function(a,t,d,n,o,f){return r(),e("div")}]]);export{t as default};
