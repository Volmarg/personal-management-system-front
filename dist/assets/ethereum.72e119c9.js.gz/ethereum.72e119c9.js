var e="/assets/ethereum.e5792e5a.svg";export{e as default};
