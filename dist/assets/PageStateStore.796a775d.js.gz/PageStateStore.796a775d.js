import{aE as t}from"./index.96856189.js";const a=t("pageState",{state:()=>({pageTitlePostfix:""})});export{a as p};
