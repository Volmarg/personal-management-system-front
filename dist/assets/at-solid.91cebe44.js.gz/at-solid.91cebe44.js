var a="/assets/at-solid.da7a8a07.svg";export{a as default};
