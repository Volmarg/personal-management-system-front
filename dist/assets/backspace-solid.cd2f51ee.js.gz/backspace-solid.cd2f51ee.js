var s="/assets/backspace-solid.bb09fed3.svg";export{s as default};
