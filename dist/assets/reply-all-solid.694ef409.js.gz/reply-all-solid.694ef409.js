var a="/assets/reply-all-solid.2a3e0671.svg";export{a as default};
