var s="/assets/search-plus-solid.41cf06c7.svg";export{s as default};
