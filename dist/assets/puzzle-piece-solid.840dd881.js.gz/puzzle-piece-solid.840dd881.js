var e="/assets/puzzle-piece-solid.8345d214.svg";export{e as default};
