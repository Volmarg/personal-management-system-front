var s="/assets/ups.0655ef8e.svg";export{s as default};
