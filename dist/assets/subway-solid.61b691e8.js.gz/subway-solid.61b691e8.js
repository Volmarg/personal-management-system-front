var s="/assets/subway-solid.ed37c3eb.svg";export{s as default};
