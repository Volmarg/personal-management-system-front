var a="/assets/piggy-bank-solid.81ef3a8f.svg";export{a as default};
