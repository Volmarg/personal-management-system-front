var s="/assets/life-ring.49f92216.svg";export{s as default};
