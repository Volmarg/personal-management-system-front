var s="/assets/life-ring-solid.49f92216.svg";export{s as default};
