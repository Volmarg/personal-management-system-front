var s="/assets/magic-solid.0f3f82b0.svg";export{s as default};
