var a="/assets/rev.56baf5a9.svg";export{a as default};
