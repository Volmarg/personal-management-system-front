var s="/assets/chess-rook-solid.8ef19f87.svg";export{s as default};
