var a="/assets/edge.ad8fdabb.svg";export{a as default};
