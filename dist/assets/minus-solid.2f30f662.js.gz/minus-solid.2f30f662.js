var s="/assets/minus-solid.51e17523.svg";export{s as default};
