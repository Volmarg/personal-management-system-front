var s="/assets/train-solid.9d8e0b33.svg";export{s as default};
