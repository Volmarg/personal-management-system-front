var a="/assets/drupal.e67d3187.svg";export{a as default};
