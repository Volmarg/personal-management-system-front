var e="/assets/toilet-paper-solid.e7f6b1e4.svg";export{e as default};
