var a="/assets/chart-pie-solid.d14a6bc6.svg";export{a as default};
