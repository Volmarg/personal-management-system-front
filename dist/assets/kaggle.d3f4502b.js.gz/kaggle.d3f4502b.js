var a="/assets/kaggle.9ba44509.svg";export{a as default};
