var s="/assets/adjust-solid.2f193931.svg";export{s as default};
