var a="/assets/heart-solid.42a7c822.svg";export{a as default};
