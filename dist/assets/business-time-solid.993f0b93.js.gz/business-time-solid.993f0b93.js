var s="/assets/business-time-solid.df87252a.svg";export{s as default};
