var s="/assets/play-circle-solid.503b4cc1.svg";export{s as default};
