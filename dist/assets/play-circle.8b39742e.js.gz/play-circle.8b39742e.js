var a="/assets/play-circle.503b4cc1.svg";export{a as default};
