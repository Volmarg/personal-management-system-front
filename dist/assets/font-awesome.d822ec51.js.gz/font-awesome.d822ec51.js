var a="/assets/font-awesome-alt.431807c4.svg";export{a as default};
