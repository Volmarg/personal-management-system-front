var a="/assets/fort-awesome.2af8720b.svg";export{a as default};
