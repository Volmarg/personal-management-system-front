var s="/assets/ellipsis-v-solid.8da25a4b.svg";export{s as default};
