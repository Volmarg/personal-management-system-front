var a="/assets/fedora.ef101358.svg";export{a as default};
