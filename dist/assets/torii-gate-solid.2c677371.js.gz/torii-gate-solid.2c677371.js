var a="/assets/torii-gate-solid.bacd9fa3.svg";export{a as default};
