import{aF as a}from"./index.daf34ba3.js";const t=a("pageState",{state:()=>({pageTitlePostfix:""})});export{t as p};
