var s="/assets/satellite-solid.50efc8ff.svg";export{s as default};
