var a="/assets/umbrella-beach-solid.ae28a770.svg";export{a as default};
