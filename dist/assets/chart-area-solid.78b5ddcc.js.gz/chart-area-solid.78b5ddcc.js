var a="/assets/chart-area-solid.0b03d144.svg";export{a as default};
