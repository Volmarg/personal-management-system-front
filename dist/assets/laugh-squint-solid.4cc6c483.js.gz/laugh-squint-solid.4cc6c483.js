var s="/assets/grin-squint-solid.d2608220.svg";export{s as default};
