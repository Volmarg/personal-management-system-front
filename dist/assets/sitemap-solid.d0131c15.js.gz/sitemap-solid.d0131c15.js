var s="/assets/sitemap-solid.7b5e4496.svg";export{s as default};
