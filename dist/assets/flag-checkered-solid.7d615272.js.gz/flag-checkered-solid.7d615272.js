var e="/assets/flag-checkered-solid.e0322415.svg";export{e as default};
