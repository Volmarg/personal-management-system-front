var s="/assets/pen-alt-solid.9dd788ce.svg";export{s as default};
