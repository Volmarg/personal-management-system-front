var a="/assets/deploydog.e88a6372.svg";export{a as default};
