var s="/assets/grin-tongue-wink-solid.b4855fca.svg";export{s as default};
