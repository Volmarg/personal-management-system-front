var a="/assets/grin-tongue-wink.b4855fca.svg";export{a as default};
