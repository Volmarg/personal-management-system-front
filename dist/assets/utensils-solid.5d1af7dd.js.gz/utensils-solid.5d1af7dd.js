var s="/assets/utensils-solid.fbe11b92.svg";export{s as default};
