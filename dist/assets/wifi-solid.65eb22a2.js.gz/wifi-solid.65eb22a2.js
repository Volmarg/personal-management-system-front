var s="/assets/wifi-solid.25b82a95.svg";export{s as default};
