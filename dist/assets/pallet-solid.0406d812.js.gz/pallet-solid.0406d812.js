var s="/assets/pallet-solid.1320f1bf.svg";export{s as default};
