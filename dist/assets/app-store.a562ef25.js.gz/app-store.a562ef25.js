var s="/assets/app-store.62e179cd.svg";export{s as default};
