var e="/assets/code-solid.eeb112d4.svg";export{e as default};
