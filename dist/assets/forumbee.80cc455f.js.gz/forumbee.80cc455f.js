var e="/assets/forumbee.32050d9d.svg";export{e as default};
