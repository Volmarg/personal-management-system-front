var s="/assets/air-freshener-solid.cd08c777.svg";export{s as default};
