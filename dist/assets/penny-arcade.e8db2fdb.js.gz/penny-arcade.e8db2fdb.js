var a="/assets/penny-arcade.5646bcdd.svg";export{a as default};
