var s="/assets/toggle-off-solid.72fa718d.svg";export{s as default};
