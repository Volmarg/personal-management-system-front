var a="/assets/wpexplorer.538f65ad.svg";export{a as default};
