var e="/assets/briefcase-medical-solid.e54c449e.svg";export{e as default};
