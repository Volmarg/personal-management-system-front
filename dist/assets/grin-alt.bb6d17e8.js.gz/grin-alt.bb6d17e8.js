var a="/assets/grin-alt-solid.a057f6a1.svg";export{a as default};
