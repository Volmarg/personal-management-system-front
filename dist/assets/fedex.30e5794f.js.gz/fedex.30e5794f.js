var e="/assets/fedex.d9001d0b.svg";export{e as default};
