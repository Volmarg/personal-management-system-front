var s="/assets/baby-solid.d229983b.svg";export{s as default};
