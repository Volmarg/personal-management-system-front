var a="/assets/salesforce.a8c2ab0f.svg";export{a as default};
