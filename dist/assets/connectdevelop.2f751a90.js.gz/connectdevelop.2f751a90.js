var e="/assets/connectdevelop.1d41f90b.svg";export{e as default};
