var s="/assets/scribd.c4155e5e.svg";export{s as default};
