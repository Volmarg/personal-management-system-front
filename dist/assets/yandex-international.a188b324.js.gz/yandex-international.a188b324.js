var a="/assets/yandex-international.4af253c7.svg";export{a as default};
