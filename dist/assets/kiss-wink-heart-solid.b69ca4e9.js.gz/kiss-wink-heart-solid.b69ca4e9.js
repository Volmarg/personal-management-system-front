var s="/assets/kiss-wink-heart-solid.01145f2b.svg";export{s as default};
