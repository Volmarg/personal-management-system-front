var a="/assets/contao.eaf782ed.svg";export{a as default};
