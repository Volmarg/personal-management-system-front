var s="/assets/globe-solid.dec56958.svg";export{s as default};
