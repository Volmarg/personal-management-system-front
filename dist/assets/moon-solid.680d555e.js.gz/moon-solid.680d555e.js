var s="/assets/moon-solid.dd880f43.svg";export{s as default};
