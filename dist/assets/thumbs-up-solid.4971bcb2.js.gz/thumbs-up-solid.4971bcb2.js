var s="/assets/thumbs-up.05392446.svg";export{s as default};
