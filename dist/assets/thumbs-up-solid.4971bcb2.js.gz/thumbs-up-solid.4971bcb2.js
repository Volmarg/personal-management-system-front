var s="/assets/thumbs-up-solid.05392446.svg";export{s as default};
