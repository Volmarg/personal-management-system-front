var a="/assets/grin-beam-solid.ad8322f1.svg";export{a as default};
