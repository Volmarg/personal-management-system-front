var e="/assets/yammer.90ee1f8c.svg";export{e as default};
