var s="/assets/sim-card-solid.87d7b2ac.svg";export{s as default};
