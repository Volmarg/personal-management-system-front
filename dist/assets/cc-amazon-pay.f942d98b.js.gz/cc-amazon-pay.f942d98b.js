var a="/assets/cc-amazon-pay.4b408817.svg";export{a as default};
