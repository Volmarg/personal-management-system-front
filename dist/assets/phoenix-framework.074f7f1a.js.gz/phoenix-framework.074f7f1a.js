var e="/assets/phoenix-framework.94e15c96.svg";export{e as default};
