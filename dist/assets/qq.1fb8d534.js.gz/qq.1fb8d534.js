var a="/assets/qq.6ac0a03c.svg";export{a as default};
