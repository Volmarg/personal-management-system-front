var a="/assets/id-card-alt-solid.7d6a8271.svg";export{a as default};
