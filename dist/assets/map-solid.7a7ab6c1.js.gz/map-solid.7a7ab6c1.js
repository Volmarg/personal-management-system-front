var s="/assets/map-solid.93160e47.svg";export{s as default};
