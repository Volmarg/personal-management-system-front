var s="/assets/bolt-solid.a1760d04.svg";export{s as default};
