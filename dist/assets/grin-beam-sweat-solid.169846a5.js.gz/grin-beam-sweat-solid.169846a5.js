var a="/assets/grin-beam-sweat-solid.1bf29b9a.svg";export{a as default};
