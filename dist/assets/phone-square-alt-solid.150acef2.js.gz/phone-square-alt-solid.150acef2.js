var a="/assets/phone-square-alt-solid.2a0fa615.svg";export{a as default};
