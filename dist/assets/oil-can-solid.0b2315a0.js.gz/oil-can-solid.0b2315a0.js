var s="/assets/oil-can-solid.3ec2e159.svg";export{s as default};
