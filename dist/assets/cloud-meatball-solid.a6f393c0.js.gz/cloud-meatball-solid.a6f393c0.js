var a="/assets/cloud-meatball-solid.00fdabee.svg";export{a as default};
