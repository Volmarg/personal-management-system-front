var a="/assets/paper-plane-solid.a0adfbc4.svg";export{a as default};
