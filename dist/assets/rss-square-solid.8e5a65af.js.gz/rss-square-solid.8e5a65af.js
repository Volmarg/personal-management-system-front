var s="/assets/rss-square-solid.0667202e.svg";export{s as default};
