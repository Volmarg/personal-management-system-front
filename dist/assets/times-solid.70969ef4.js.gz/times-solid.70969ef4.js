var s="/assets/times-solid.87508e3f.svg";export{s as default};
