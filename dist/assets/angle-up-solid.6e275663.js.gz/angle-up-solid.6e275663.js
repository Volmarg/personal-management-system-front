var s="/assets/angle-up-solid.567d42f8.svg";export{s as default};
