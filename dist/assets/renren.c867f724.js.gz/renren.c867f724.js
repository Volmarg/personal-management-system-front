var e="/assets/renren.23bb9980.svg";export{e as default};
