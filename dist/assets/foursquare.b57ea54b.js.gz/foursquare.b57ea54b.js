var a="/assets/foursquare.acf736c8.svg";export{a as default};
