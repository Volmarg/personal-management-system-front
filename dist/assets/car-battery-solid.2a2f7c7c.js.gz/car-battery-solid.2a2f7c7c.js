var a="/assets/car-battery-solid.5809169f.svg";export{a as default};
