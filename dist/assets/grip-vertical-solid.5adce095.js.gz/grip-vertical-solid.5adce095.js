var a="/assets/grip-vertical-solid.b063a865.svg";export{a as default};
