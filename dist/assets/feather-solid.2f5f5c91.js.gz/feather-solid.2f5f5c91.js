var a="/assets/feather-solid.d27e6af7.svg";export{a as default};
