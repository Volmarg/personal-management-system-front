var s="/assets/minus-square-solid.738de406.svg";export{s as default};
