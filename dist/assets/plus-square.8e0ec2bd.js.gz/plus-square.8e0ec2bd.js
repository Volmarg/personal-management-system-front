var s="/assets/plus-square-solid.59c5bd95.svg";export{s as default};
