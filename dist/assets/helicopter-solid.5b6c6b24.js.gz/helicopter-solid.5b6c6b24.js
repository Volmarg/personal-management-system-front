var e="/assets/helicopter-solid.09cef564.svg";export{e as default};
