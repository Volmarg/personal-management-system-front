var s="/assets/fish-solid.fe99c45d.svg";export{s as default};
