var s="/assets/syringe-solid.0bc1acb8.svg";export{s as default};
