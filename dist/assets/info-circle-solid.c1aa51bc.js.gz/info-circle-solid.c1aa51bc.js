var e="/assets/info-circle-solid.031fee98.svg";export{e as default};
