var s="/assets/horse-solid.fd2b9b27.svg";export{s as default};
