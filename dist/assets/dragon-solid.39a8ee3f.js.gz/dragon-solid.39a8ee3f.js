var s="/assets/dragon-solid.627410bd.svg";export{s as default};
