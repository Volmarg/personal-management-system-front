var a="/assets/telegram-plane.56aef3fb.svg";export{a as default};
