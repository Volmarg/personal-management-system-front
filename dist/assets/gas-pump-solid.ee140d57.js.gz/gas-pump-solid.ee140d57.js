var s="/assets/gas-pump-solid.357c890a.svg";export{s as default};
