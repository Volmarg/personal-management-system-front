var s="/assets/tripadvisor.3bc1139e.svg";export{s as default};
