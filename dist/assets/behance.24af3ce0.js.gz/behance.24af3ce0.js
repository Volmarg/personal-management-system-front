var e="/assets/behance.e2d848fe.svg";export{e as default};
