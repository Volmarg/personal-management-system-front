var s="/assets/won-sign-solid.87a3716f.svg";export{s as default};
