var s="/assets/invision.67cf64a3.svg";export{s as default};
