var s="/assets/question-solid.97af21c3.svg";export{s as default};
