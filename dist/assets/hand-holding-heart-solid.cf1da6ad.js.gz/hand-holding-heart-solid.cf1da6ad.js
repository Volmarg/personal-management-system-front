var a="/assets/hand-holding-heart-solid.7a59a114.svg";export{a as default};
