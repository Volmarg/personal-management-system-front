var e="/assets/creative-commons-remix.b1bcfed7.svg";export{e as default};
