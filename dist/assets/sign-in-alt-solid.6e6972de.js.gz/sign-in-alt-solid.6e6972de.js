var a="/assets/sign-in-alt-solid.e3aeac6e.svg";export{a as default};
