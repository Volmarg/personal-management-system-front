var e="/assets/mendeley.3db4b2ed.svg";export{e as default};
