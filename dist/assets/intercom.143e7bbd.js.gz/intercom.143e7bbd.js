var a="/assets/intercom.2505800a.svg";export{a as default};
