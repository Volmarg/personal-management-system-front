var a="/assets/feather-alt-solid.850d85cc.svg";export{a as default};
