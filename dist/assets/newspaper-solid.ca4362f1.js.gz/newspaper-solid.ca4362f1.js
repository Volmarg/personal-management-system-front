var s="/assets/newspaper-solid.37d70204.svg";export{s as default};
