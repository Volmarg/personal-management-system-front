var s="/assets/hockey-puck-solid.e5398802.svg";export{s as default};
