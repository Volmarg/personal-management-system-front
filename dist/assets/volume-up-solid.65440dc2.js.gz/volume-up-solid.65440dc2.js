var s="/assets/volume-up-solid.3242206f.svg";export{s as default};
