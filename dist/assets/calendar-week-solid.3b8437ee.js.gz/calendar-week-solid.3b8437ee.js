var a="/assets/calendar-week-solid.d299bcc6.svg";export{a as default};
