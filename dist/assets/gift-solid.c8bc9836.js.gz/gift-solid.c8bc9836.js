var s="/assets/gift-solid.f453d181.svg";export{s as default};
