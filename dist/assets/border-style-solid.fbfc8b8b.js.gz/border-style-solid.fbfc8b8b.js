var s="/assets/border-style-solid.2681c7ea.svg";export{s as default};
