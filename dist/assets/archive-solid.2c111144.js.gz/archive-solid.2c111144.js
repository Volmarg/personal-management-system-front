var a="/assets/archive-solid.04a59850.svg";export{a as default};
