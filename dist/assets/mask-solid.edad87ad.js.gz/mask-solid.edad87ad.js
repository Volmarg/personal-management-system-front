var s="/assets/mask-solid.622ebcd1.svg";export{s as default};
