var s="/assets/hospital-solid.1b74172c.svg";export{s as default};
