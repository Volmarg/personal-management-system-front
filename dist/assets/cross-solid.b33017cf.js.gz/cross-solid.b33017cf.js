var s="/assets/cross-solid.f63dc91f.svg";export{s as default};
