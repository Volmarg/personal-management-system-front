var s="/assets/street-view-solid.8f6ad50d.svg";export{s as default};
