var a="/assets/house-damage-solid.ac86fde3.svg";export{a as default};
