var e="/assets/envelope-solid.0c5d52bc.svg";export{e as default};
