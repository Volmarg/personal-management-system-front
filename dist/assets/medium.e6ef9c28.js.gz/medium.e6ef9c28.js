var a="/assets/medium-m.2bb36ad8.svg";export{a as default};
