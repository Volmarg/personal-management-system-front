var s="/assets/allergies-solid.c7b81932.svg";export{s as default};
