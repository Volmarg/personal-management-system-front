var s="/assets/paperclip-solid.80635345.svg";export{s as default};
