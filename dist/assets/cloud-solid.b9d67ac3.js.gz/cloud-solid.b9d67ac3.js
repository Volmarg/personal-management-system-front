var s="/assets/cloud-solid.451d06a5.svg";export{s as default};
