var a="/assets/window-maximize-solid.90a8dd0f.svg";export{a as default};
