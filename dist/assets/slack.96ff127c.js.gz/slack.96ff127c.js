var a="/assets/slack-hash.548cea68.svg";export{a as default};
