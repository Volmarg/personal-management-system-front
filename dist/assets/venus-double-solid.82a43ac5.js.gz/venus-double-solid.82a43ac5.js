var s="/assets/venus-double-solid.ec7f2c96.svg";export{s as default};
