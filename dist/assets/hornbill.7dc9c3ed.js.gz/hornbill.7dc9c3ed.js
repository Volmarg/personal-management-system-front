var s="/assets/hornbill.e653cf30.svg";export{s as default};
