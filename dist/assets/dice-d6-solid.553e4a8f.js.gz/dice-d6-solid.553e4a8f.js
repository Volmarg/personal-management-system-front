var s="/assets/dice-d6-solid.4d3b3f61.svg";export{s as default};
