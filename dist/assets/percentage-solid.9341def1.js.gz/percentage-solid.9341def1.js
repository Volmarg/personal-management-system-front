var e="/assets/percentage-solid.272f9344.svg";export{e as default};
