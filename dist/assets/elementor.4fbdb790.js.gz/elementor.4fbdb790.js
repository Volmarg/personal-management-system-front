var e="/assets/elementor.d1e0305a.svg";export{e as default};
