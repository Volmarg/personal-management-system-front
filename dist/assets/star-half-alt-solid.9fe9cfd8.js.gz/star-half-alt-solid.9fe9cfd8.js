var a="/assets/star-half-alt-solid.a4a1ebee.svg";export{a as default};
