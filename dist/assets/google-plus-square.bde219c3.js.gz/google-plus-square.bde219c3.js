var s="/assets/google-plus-square.f3168c40.svg";export{s as default};
