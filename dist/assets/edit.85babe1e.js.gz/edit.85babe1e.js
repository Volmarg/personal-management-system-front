var s="/assets/edit.f4d57281.svg";export{s as default};
