var s="/assets/glasses-solid.e8aaf1e1.svg";export{s as default};
