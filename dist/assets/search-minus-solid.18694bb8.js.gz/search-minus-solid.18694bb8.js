var s="/assets/search-minus-solid.6a804639.svg";export{s as default};
