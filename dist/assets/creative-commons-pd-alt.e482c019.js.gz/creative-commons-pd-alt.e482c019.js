var a="/assets/creative-commons-pd-alt.f68b6057.svg";export{a as default};
