var a="/assets/hand-lizard.abd90505.svg";export{a as default};
