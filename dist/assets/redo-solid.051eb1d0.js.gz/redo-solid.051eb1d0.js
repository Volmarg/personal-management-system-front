var s="/assets/redo-solid.6b7dfbe7.svg";export{s as default};
