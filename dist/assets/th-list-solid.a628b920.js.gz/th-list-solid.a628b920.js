var s="/assets/th-list-solid.550a64ae.svg";export{s as default};
