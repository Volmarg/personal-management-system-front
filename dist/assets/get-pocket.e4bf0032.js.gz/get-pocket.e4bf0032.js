var e="/assets/get-pocket.780459dc.svg";export{e as default};
