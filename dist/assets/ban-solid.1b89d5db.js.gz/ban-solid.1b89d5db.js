var s="/assets/ban-solid.8f96803e.svg";export{s as default};
