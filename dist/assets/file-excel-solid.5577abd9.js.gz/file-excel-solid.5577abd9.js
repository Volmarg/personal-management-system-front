var e="/assets/file-excel-solid.1b752d6c.svg";export{e as default};
