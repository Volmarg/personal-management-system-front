var e="/assets/file-excel.1b752d6c.svg";export{e as default};
