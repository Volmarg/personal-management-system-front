var s="/assets/shield-alt-solid.23a2c277.svg";export{s as default};
