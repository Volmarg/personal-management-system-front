var a="/assets/dyalog.ec3b6aa8.svg";export{a as default};
