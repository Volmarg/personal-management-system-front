var a="/assets/galactic-senate.609ce2ad.svg";export{a as default};
