var s="/assets/hat-cowboy-solid.f547b89d.svg";export{s as default};
