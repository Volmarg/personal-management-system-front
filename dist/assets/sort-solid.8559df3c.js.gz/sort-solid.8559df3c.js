var s="/assets/sort-solid.49de63e7.svg";export{s as default};
