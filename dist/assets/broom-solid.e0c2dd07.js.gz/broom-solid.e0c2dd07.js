var s="/assets/broom-solid.381b74c1.svg";export{s as default};
