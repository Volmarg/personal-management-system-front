var a="/assets/clipboard-solid.56d4da2a.svg";export{a as default};
