var a="/assets/shopping-bag-solid.caea03c6.svg";export{a as default};
