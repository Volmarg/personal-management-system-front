var s="/assets/ruler-combined-solid.762bbc97.svg";export{s as default};
