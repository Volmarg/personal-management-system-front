var a="/assets/hackerrank.f6c7b727.svg";export{a as default};
