var a="/assets/ambulance-solid.ba8c4891.svg";export{a as default};
