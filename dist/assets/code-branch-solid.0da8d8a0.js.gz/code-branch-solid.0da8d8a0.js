var s="/assets/code-branch-solid.43621f26.svg";export{s as default};
