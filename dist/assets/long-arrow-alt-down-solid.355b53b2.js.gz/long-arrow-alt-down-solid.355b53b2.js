var a="/assets/long-arrow-alt-down-solid.209a79fc.svg";export{a as default};
