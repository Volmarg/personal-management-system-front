var s="/assets/bus-alt-solid.98f2c0e4.svg";export{s as default};
