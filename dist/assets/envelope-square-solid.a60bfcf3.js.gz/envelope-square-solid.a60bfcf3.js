var e="/assets/envelope-square-solid.3406bace.svg";export{e as default};
