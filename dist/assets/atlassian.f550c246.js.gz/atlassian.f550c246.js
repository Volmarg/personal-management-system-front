var a="/assets/atlassian.fcbe66c6.svg";export{a as default};
