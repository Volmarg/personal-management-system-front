var s="/assets/symfony.a3669942.svg";export{s as default};
