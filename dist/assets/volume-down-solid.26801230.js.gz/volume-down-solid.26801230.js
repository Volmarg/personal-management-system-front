var s="/assets/volume-down-solid.58c5c6bf.svg";export{s as default};
