var s="/assets/icicles-solid.04934f68.svg";export{s as default};
