var a="/assets/speakap.65a38e7c.svg";export{a as default};
