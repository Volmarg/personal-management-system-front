var a="/assets/wizards-of-the-coast.d2457da0.svg";export{a as default};
