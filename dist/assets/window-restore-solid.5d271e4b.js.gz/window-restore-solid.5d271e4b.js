var s="/assets/window-restore-solid.1d16134a.svg";export{s as default};
