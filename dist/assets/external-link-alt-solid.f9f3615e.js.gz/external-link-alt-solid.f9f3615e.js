var a="/assets/external-link-alt-solid.0b8e7668.svg";export{a as default};
