var s="/assets/comment-dots-solid.9fd0f06c.svg";export{s as default};
