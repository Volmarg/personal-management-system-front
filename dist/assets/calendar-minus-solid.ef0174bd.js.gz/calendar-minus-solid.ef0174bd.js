var s="/assets/calendar-minus-solid.f7e4730e.svg";export{s as default};
