var s="/assets/file-word-solid.3252bbf4.svg";export{s as default};
