var s="/assets/stamp-solid.b4663314.svg";export{s as default};
