var a="/assets/fax-solid.b1245af9.svg";export{a as default};
