var s="/assets/rss-solid.39d9bb41.svg";export{s as default};
