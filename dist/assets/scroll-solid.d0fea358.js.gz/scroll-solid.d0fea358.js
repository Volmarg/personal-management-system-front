var s="/assets/scroll-solid.eead8ca3.svg";export{s as default};
