var s="/assets/first-order.c14e6891.svg";export{s as default};
