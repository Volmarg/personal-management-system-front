var s="/assets/undo-alt-solid.7c638743.svg";export{s as default};
