var s="/assets/paint-roller-solid.69321666.svg";export{s as default};
