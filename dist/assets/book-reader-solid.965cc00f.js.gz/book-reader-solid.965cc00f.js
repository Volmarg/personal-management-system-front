var e="/assets/book-reader-solid.e3bef58e.svg";export{e as default};
