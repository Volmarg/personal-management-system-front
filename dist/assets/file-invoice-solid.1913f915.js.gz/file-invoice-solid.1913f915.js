var s="/assets/file-invoice-solid.4b2486d7.svg";export{s as default};
