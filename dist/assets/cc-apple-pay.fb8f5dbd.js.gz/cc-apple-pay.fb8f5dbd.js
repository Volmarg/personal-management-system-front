var a="/assets/cc-apple-pay.52e43434.svg";export{a as default};
