var s="/assets/skull-crossbones-solid.2bff13ff.svg";export{s as default};
