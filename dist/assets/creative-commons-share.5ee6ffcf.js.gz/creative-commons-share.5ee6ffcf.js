var a="/assets/creative-commons-share.44ad0f95.svg";export{a as default};
