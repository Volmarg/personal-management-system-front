var e="/assets/file-archive-solid.f788efdf.svg";export{e as default};
