var s="/assets/columns-solid.27fb47e3.svg";export{s as default};
