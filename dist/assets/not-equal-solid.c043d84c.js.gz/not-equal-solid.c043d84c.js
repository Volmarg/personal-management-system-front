var s="/assets/not-equal-solid.d12692c0.svg";export{s as default};
