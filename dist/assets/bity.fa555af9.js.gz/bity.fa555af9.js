var s="/assets/bity.747d7217.svg";export{s as default};
