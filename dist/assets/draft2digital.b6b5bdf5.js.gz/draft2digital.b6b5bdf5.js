var a="/assets/draft2digital.85b03bfa.svg";export{a as default};
