var a="/assets/gavel-solid.a8774b37.svg";export{a as default};
