var s="/assets/trash-restore-alt-solid.36d09d3e.svg";export{s as default};
