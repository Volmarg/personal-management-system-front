var s="/assets/tint-slash-solid.977e4215.svg";export{s as default};
