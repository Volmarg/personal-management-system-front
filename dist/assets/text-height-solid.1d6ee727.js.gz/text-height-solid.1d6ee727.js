var a="/assets/text-height-solid.dade09ad.svg";export{a as default};
