var s="/assets/less.106a862d.svg";export{s as default};
