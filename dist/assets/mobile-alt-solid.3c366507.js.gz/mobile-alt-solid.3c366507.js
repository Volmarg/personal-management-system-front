var s="/assets/mobile-alt-solid.e15613b5.svg";export{s as default};
