var a="/assets/caret-up-solid.876ad1e4.svg";export{a as default};
