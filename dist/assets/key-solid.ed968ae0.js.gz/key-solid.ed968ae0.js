var s="/assets/key-solid.58956f93.svg";export{s as default};
