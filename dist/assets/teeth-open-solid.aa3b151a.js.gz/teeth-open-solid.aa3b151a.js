var e="/assets/teeth-open-solid.0582a34d.svg";export{e as default};
