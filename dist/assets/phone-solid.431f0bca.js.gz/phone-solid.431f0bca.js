var s="/assets/phone-solid.0d8bf558.svg";export{s as default};
