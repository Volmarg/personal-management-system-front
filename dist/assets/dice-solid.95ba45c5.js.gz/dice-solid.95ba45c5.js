var s="/assets/dice-solid.c42c7245.svg";export{s as default};
