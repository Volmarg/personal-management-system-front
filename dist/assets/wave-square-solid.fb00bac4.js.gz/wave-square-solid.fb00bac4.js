var e="/assets/wave-square-solid.7eec0364.svg";export{e as default};
