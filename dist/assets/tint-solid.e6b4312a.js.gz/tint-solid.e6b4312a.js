var s="/assets/tint-solid.1d42f396.svg";export{s as default};
