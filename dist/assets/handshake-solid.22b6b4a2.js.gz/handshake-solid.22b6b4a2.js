var a="/assets/handshake-solid.cc3a7812.svg";export{a as default};
