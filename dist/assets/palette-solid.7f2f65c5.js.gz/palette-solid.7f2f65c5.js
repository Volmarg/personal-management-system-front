var s="/assets/palette-solid.f6671453.svg";export{s as default};
