var a="/assets/credit-card-solid.9ca77ec6.svg";export{a as default};
