var s="/assets/parking-solid.09fc9816.svg";export{s as default};
