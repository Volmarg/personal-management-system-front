var s="/assets/buysellads.add6315c.svg";export{s as default};
