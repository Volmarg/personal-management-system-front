var s="/assets/user-friends-solid.e0918572.svg";export{s as default};
