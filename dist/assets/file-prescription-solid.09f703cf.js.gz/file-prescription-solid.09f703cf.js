var s="/assets/file-prescription-solid.7a0cf620.svg";export{s as default};
