var a="/assets/waze.0f5ad007.svg";export{a as default};
