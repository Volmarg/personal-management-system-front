var s="/assets/suse.2aa40011.svg";export{s as default};
