var a="/assets/id-badge.bda82830.svg";export{a as default};
