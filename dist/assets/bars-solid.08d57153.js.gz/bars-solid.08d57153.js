var s="/assets/bars-solid.4b098180.svg";export{s as default};
