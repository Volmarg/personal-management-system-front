var s="/assets/file-powerpoint-solid.98962f1a.svg";export{s as default};
