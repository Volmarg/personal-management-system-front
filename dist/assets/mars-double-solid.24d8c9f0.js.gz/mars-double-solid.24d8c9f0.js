var s="/assets/mars-double-solid.0e5309e1.svg";export{s as default};
