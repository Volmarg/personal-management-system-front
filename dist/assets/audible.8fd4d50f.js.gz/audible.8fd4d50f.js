var a="/assets/audible.43581deb.svg";export{a as default};
