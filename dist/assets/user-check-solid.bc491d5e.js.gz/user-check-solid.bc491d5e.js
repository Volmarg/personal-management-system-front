var s="/assets/user-check-solid.820254a1.svg";export{s as default};
