var a="/assets/cloudsmith.95faba07.svg";export{a as default};
