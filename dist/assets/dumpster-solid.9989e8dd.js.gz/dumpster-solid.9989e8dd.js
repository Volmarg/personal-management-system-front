var s="/assets/dumpster-solid.34cd1a49.svg";export{s as default};
