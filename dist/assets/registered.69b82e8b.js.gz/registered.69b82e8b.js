var s="/assets/registered-solid.406cc804.svg";export{s as default};
