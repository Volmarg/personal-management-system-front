var s="/assets/globe-asia-solid.046c84f2.svg";export{s as default};
