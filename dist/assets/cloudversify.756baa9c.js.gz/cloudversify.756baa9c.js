var s="/assets/cloudversify.f80f4206.svg";export{s as default};
