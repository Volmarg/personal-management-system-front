var a="/assets/vnv.cad2159e.svg";export{a as default};
