var s="/assets/tape-solid.470e3d83.svg";export{s as default};
