var s="/assets/running-solid.c21f502f.svg";export{s as default};
