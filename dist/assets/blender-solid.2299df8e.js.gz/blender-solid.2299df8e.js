var e="/assets/blender-solid.8ec685d7.svg";export{e as default};
