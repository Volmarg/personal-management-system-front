var s="/assets/sass.48c48377.svg";export{s as default};
