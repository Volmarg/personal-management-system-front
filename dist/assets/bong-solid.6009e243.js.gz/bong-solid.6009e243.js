var s="/assets/bong-solid.cffe26a4.svg";export{s as default};
