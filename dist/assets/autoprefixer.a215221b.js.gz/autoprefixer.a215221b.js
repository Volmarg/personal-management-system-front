var a="/assets/autoprefixer.d97f8d4d.svg";export{a as default};
