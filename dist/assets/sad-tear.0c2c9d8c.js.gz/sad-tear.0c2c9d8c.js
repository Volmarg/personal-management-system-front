var a="/assets/sad-tear.51e470d1.svg";export{a as default};
