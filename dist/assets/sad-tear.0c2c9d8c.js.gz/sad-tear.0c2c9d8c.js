var s="/assets/sad-tear-solid.51e470d1.svg";export{s as default};
