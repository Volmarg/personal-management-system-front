var e="/assets/internet-explorer.2ed81713.svg";export{e as default};
