var s="/assets/menorah-solid.60083d54.svg";export{s as default};
