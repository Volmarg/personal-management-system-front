var s="/assets/user-slash-solid.6a0466d4.svg";export{s as default};
