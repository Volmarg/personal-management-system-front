var a="/assets/ebay.a4aba8ef.svg";export{a as default};
