var a="/assets/crop-alt-solid.30b5a04b.svg";export{a as default};
