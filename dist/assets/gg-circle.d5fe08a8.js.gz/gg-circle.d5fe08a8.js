var e="/assets/gg-circle.b87603e5.svg";export{e as default};
