var s="/assets/poop-solid.37cd3255.svg";export{s as default};
