var e="/assets/monument-solid.f69e6d6e.svg";export{e as default};
