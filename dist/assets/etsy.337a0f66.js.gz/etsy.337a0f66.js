var s="/assets/etsy.1ca04bf4.svg";export{s as default};
