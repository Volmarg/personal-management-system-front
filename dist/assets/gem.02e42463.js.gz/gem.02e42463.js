var s="/assets/gem-solid.de1d158a.svg";export{s as default};
