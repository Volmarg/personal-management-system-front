var s="/assets/smoking-solid.4059e624.svg";export{s as default};
