var s="/assets/drumstick-bite-solid.10c97442.svg";export{s as default};
