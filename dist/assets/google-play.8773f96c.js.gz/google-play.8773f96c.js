var a="/assets/google-play.c6d3b1c7.svg";export{a as default};
