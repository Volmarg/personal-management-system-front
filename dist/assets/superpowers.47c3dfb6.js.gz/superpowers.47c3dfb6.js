var s="/assets/superpowers.7474dcf3.svg";export{s as default};
