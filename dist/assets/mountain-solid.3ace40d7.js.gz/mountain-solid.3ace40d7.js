var s="/assets/mountain-solid.3c130466.svg";export{s as default};
