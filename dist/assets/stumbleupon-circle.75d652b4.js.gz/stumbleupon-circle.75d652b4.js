var s="/assets/stumbleupon-circle.a107d9cf.svg";export{s as default};
