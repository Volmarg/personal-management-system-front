var s="/assets/hryvnia-solid.6d66ce32.svg";export{s as default};
