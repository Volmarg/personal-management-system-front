var t="/assets/twitter.bd76cc69.svg";export{t as default};
