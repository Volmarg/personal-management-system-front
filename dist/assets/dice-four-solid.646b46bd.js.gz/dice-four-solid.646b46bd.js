var s="/assets/dice-four-solid.f3003d13.svg";export{s as default};
