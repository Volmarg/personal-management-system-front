var s="/assets/dove-solid.8fbd09e0.svg";export{s as default};
