var e="/assets/file-code-solid.f8f281fe.svg";export{e as default};
