var s="/assets/hand-point-down-solid.099fd988.svg";export{s as default};
