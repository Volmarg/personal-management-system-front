var e="/assets/record-vinyl-solid.ef64efde.svg";export{e as default};
