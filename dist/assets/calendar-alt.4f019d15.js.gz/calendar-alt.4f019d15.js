var a="/assets/calendar-alt-solid.8a56c556.svg";export{a as default};
