var s="/assets/icons-solid.ec3b0be1.svg";export{s as default};
