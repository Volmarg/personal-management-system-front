var s="/assets/hand-middle-finger-solid.4132b1b5.svg";export{s as default};
