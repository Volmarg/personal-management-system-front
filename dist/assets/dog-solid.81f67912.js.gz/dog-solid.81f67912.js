var s="/assets/dog-solid.0dabbb81.svg";export{s as default};
