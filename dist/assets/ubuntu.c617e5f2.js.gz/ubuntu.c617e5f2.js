var s="/assets/ubuntu.06238f42.svg";export{s as default};
