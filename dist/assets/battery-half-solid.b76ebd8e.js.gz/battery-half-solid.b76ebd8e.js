var a="/assets/battery-half-solid.2c01d081.svg";export{a as default};
