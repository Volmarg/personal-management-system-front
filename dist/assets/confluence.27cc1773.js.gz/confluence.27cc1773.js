var e="/assets/confluence.60491910.svg";export{e as default};
