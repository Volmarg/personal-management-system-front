var a="/assets/keycdn.2a76d4a6.svg";export{a as default};
