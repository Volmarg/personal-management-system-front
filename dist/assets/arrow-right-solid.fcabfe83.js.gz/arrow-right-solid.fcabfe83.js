var s="/assets/arrow-right-solid.e28b9770.svg";export{s as default};
