var e="/assets/envelope.0c5d52bc.svg";export{e as default};
