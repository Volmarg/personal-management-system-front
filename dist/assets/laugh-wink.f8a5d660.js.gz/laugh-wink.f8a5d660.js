var a="/assets/laugh-wink-solid.0f56fad7.svg";export{a as default};
