var e="/assets/codepen.ef656c29.svg";export{e as default};
