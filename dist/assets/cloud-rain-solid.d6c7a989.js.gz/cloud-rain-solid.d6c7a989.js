var s="/assets/cloud-rain-solid.eb9ed9d1.svg";export{s as default};
