var s="/assets/divide-solid.f1b99f51.svg";export{s as default};
