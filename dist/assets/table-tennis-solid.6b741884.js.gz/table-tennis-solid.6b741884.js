var s="/assets/table-tennis-solid.a0d47493.svg";export{s as default};
