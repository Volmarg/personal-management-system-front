var s="/assets/pound-sign-solid.1e189fd9.svg";export{s as default};
