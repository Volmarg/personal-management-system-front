var a="/assets/creative-commons-nd.c0a9a898.svg";export{a as default};
