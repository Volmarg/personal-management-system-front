var s="/assets/tumblr.c63ef47f.svg";export{s as default};
