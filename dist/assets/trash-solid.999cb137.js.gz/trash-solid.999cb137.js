var s="/assets/trash-solid.74e85846.svg";export{s as default};
