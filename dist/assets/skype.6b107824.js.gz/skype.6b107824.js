var s="/assets/skype.05cbab53.svg";export{s as default};
