var s="/assets/arrow-circle-up-solid.9f68b129.svg";export{s as default};
