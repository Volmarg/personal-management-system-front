var s="/assets/simplybuilt.4f469445.svg";export{s as default};
