var d="/assets/digg.d3d3d498.svg";export{d as default};
