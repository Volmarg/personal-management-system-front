var a="/assets/fan-solid.64a8d81c.svg";export{a as default};
