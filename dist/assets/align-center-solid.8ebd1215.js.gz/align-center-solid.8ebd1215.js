var e="/assets/align-center-solid.49d265be.svg";export{e as default};
