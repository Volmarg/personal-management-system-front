var s="/assets/wordpress-simple.975b57ed.svg";export{s as default};
