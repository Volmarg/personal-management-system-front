var s="/assets/plane-solid.612dcf12.svg";export{s as default};
