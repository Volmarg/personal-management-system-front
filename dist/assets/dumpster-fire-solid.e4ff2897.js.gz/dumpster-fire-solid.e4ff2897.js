var s="/assets/dumpster-fire-solid.e6df0025.svg";export{s as default};
