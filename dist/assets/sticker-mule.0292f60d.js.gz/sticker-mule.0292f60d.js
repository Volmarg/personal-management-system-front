var e="/assets/sticker-mule.4bbe424e.svg";export{e as default};
