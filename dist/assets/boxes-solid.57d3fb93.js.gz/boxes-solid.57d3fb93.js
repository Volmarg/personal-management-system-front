var s="/assets/boxes-solid.ea8d0410.svg";export{s as default};
