var a="/assets/battery-full-solid.1d53afb5.svg";export{a as default};
