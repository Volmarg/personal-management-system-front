import{$ as t}from"./index.fd0df9df.js";const e=t("pageState",{state:()=>({pageTitlePostfix:""})});export{e as p};
