var a="/assets/vr-cardboard-solid.5308e9a7.svg";export{a as default};
