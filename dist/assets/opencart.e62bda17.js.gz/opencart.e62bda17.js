var a="/assets/opencart.bdf56b3f.svg";export{a as default};
