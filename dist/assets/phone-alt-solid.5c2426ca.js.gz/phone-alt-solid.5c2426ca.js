var s="/assets/phone-alt-solid.78de79cc.svg";export{s as default};
