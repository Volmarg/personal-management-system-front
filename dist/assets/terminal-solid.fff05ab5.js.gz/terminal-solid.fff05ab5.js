var s="/assets/terminal-solid.677f8be9.svg";export{s as default};
