import{a as o}from"./index.31c62b28.js";const s={data:()=>({isDemo:!1}),mounted(){this.isDemo=o.isDemo()}};export{s as _};
