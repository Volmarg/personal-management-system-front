var s="/assets/chevron-down-solid.d9546c0e.svg";export{s as default};
