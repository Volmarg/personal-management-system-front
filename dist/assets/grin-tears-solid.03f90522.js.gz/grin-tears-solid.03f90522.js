var s="/assets/grin-tears.b2c7c793.svg";export{s as default};
