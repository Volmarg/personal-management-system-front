var s="/assets/grimace-solid.7811d3c3.svg";export{s as default};
