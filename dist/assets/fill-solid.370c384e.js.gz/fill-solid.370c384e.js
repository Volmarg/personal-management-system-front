var s="/assets/fill-solid.2a149c4b.svg";export{s as default};
