var s="/assets/user-lock-solid.0484f772.svg";export{s as default};
