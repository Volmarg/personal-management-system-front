var s="/assets/outdent-solid.49d29681.svg";export{s as default};
