var s="/assets/spray-can-solid.0f6f84f0.svg";export{s as default};
