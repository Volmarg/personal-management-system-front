var e="/assets/bullhorn-solid.e3bbe3be.svg";export{e as default};
