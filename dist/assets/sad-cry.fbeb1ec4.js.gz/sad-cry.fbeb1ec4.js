var a="/assets/sad-cry-solid.88baa84e.svg";export{a as default};
