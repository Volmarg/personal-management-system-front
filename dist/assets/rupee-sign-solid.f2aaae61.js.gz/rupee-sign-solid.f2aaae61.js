var s="/assets/rupee-sign-solid.422bbdc5.svg";export{s as default};
