var a="/assets/baseball-ball-solid.5be634d4.svg";export{a as default};
