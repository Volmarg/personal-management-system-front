var a="/assets/pen-fancy-solid.c526fc9a.svg";export{a as default};
