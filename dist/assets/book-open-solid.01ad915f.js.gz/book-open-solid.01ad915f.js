var a="/assets/book-open-solid.7a7a106c.svg";export{a as default};
