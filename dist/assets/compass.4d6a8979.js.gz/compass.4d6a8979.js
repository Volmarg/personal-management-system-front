var s="/assets/compass-solid.61239133.svg";export{s as default};
