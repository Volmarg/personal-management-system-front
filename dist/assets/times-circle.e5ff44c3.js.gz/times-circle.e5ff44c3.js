var s="/assets/times-circle-solid.22a778f4.svg";export{s as default};
