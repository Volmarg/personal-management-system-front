var s="/assets/photo-video-solid.c8fad705.svg";export{s as default};
