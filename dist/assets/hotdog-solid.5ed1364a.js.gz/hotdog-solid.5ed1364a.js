var s="/assets/hotdog-solid.e3e612c7.svg";export{s as default};
