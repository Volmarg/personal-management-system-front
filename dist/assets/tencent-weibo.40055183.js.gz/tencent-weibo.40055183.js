var e="/assets/tencent-weibo.01a521b7.svg";export{e as default};
