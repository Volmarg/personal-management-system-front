var s="/assets/caret-down-solid.717e2371.svg";export{s as default};
