var s="/assets/address-card-solid.a828dd33.svg";export{s as default};
