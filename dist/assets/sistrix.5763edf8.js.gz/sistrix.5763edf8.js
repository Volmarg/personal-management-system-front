var s="/assets/sistrix.8dcedc01.svg";export{s as default};
