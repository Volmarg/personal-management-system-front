var s="/assets/info-solid.a805932d.svg";export{s as default};
