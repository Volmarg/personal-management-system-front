var a="/assets/xbox.25b244fa.svg";export{a as default};
