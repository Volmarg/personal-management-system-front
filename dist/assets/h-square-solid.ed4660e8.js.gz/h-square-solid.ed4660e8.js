var s="/assets/h-square-solid.23c8ba6b.svg";export{s as default};
