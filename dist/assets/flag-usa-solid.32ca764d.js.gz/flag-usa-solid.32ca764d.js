var s="/assets/flag-usa-solid.38523fd8.svg";export{s as default};
