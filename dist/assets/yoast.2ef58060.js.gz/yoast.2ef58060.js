var a="/assets/yoast.1fca2171.svg";export{a as default};
