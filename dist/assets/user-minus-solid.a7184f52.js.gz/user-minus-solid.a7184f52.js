var s="/assets/user-minus-solid.1735c568.svg";export{s as default};
