var a="/assets/avianex.1bd89cc7.svg";export{a as default};
