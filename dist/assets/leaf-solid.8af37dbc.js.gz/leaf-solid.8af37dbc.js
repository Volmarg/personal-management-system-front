var a="/assets/leaf-solid.6097d0a5.svg";export{a as default};
