var s="/assets/chevron-right-solid.efb64df4.svg";export{s as default};
