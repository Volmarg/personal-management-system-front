var s="/assets/odnoklassniki.c826ac25.svg";export{s as default};
