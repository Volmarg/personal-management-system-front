var s="/assets/phone-slash-solid.d808b857.svg";export{s as default};
