var a="/assets/sort-alpha-up-alt-solid.95297f9e.svg";export{a as default};
