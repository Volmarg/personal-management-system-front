var a="/assets/phabricator.185a2fa9.svg";export{a as default};
