var e="/assets/thermometer-quarter-solid.927bd82e.svg";export{e as default};
