var s="/assets/bowling-ball-solid.486dd3c8.svg";export{s as default};
