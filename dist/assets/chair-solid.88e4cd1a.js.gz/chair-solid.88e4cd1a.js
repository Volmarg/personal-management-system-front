var a="/assets/chair-solid.567a8e2d.svg";export{a as default};
