var s="/assets/html5.54531f5e.svg";export{s as default};
