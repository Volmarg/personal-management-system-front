var e="/assets/jedi-order.e244c222.svg";export{e as default};
