var s="/assets/school-solid.81b45552.svg";export{s as default};
