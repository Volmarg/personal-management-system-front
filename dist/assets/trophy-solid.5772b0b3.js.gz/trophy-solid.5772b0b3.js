var s="/assets/trophy-solid.b57454db.svg";export{s as default};
