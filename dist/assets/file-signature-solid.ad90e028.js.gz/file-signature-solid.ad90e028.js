var s="/assets/file-signature-solid.15538049.svg";export{s as default};
