var a="/assets/vote-yea-solid.ea400294.svg";export{a as default};
