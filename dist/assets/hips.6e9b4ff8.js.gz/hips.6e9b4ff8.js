var e="/assets/hips.2e8ee04c.svg";export{e as default};
