var s="/assets/stream-solid.063681af.svg";export{s as default};
