var s="/assets/mercury-solid.cec94117.svg";export{s as default};
