var s="/assets/accusoft.7de5778e.svg";export{s as default};
