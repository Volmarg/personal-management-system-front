var s="/assets/fonticons-fi.e5451444.svg";export{s as default};
