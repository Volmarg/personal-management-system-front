var s="/assets/chess-queen-solid.e66d5f4a.svg";export{s as default};
