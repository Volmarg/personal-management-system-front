var s="/assets/upload-solid.f5497fe2.svg";export{s as default};
