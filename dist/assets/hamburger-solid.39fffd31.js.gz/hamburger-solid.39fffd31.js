var s="/assets/hamburger-solid.5f8c3cde.svg";export{s as default};
