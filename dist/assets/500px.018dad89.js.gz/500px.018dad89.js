var a="/assets/500px.0d487a5b.svg";export{a as default};
