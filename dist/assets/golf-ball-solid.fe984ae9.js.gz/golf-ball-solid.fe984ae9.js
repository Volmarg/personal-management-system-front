var s="/assets/golf-ball-solid.f99b6d06.svg";export{s as default};
