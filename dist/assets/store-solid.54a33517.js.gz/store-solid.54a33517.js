var s="/assets/store-solid.5dfa484f.svg";export{s as default};
