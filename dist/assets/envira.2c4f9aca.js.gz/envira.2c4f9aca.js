var a="/assets/envira.6f978cdc.svg";export{a as default};
