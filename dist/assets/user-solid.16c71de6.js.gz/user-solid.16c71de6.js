var s="/assets/user-solid.fa1b1009.svg";export{s as default};
