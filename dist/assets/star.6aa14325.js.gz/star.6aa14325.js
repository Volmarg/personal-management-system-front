var s="/assets/star.d7993e68.svg";export{s as default};
