var s="/assets/stopwatch-solid.7b2037e8.svg";export{s as default};
