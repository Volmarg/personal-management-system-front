var s="/assets/quinscape.b2dd5419.svg";export{s as default};
