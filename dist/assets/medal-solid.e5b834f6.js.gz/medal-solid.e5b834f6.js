var a="/assets/medal-solid.a2fe63c1.svg";export{a as default};
