var s="/assets/crown-solid.f1cd64ee.svg";export{s as default};
