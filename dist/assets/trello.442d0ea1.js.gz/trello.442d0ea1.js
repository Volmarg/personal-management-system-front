var a="/assets/trello.65a24322.svg";export{a as default};
