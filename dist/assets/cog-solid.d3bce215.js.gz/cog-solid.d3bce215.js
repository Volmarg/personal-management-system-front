var s="/assets/cog-solid.f02a6725.svg";export{s as default};
