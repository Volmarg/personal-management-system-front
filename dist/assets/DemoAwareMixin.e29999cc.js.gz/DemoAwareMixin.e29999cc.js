import{a as e}from"./index.93e753e6.js";const o={data:()=>({isDemo:!1}),mounted(){this.isDemo=e.isDemo()}};export{o as _};
