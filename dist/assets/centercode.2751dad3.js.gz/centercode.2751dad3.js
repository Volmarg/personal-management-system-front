var e="/assets/centercode.885c3293.svg";export{e as default};
