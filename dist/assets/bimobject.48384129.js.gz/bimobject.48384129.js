var b="/assets/bimobject.1176bb4b.svg";export{b as default};
