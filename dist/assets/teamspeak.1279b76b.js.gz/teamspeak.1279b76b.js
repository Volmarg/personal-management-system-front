var a="/assets/teamspeak.c44fc65c.svg";export{a as default};
