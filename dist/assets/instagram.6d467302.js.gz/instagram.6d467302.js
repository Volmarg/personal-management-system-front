var a="/assets/instagram.9b3aae4a.svg";export{a as default};
