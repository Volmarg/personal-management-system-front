var s="/assets/grin-stars-solid.95d8081a.svg";export{s as default};
