var s="/assets/pepper-hot-solid.fa658885.svg";export{s as default};
