var e="/assets/centos.83a3eec4.svg";export{e as default};
