var a="/assets/line.fdda9fe4.svg";export{a as default};
