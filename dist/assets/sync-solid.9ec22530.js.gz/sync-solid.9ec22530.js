var s="/assets/sync-solid.3fbd45ce.svg";export{s as default};
