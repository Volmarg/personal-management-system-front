var a="/assets/plane-arrival-solid.aa81311b.svg";export{a as default};
