var s="/assets/money-bill-wave-solid.23c16501.svg";export{s as default};
