var a="/assets/balance-scale-right-solid.7b0a6845.svg";export{a as default};
