var a="/assets/yarn.12d83c6a.svg";export{a as default};
