var e="/assets/percent-solid.c993e1f1.svg";export{e as default};
