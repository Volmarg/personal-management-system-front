var s="/assets/crutch-solid.b2028933.svg";export{s as default};
