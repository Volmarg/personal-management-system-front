var a="/assets/plane-departure-solid.51e1a16d.svg";export{a as default};
