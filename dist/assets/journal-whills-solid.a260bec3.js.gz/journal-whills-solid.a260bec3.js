var s="/assets/journal-whills-solid.2c072b4d.svg";export{s as default};
