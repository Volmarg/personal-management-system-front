var s="/assets/chess-pawn-solid.cd4f5b0b.svg";export{s as default};
