var s="/assets/images-solid.bf4dc3a6.svg";export{s as default};
