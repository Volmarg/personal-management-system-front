var s="/assets/eraser-solid.d35e5892.svg";export{s as default};
