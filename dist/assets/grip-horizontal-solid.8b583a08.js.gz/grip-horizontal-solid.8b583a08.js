var s="/assets/grip-horizontal-solid.be143435.svg";export{s as default};
