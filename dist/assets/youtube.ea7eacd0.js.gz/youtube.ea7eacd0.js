var a="/assets/youtube.83aa5c1f.svg";export{a as default};
