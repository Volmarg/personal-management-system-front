var s="/assets/assistive-listening-systems-solid.4273a0aa.svg";export{s as default};
