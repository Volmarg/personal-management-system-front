var a="/assets/landmark-solid.c6d3f39a.svg";export{a as default};
