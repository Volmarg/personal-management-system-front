var a="/assets/grin-beam-sweat.1bf29b9a.svg";export{a as default};
