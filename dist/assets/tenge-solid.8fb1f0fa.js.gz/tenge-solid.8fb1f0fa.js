var e="/assets/tenge-solid.4ae9b867.svg";export{e as default};
