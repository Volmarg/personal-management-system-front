var e="/assets/weebly.fc0d8d40.svg";export{e as default};
