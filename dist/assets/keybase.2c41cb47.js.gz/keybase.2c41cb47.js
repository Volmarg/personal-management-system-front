var e="/assets/keybase.94f6eea9.svg";export{e as default};
