var s="/assets/node-js.366de4bb.svg";export{s as default};
