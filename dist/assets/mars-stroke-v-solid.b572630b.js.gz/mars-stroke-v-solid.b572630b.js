var s="/assets/mars-stroke-v-solid.835b123d.svg";export{s as default};
