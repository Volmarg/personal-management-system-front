var s="/assets/modx.033dc713.svg";export{s as default};
