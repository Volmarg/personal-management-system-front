var e="/assets/google.4fcb1b4e.svg";export{e as default};
