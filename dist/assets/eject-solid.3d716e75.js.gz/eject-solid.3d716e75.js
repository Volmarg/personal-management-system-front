var a="/assets/eject-solid.37ebaacf.svg";export{a as default};
