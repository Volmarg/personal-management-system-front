var s="/assets/usps.92b2bebb.svg";export{s as default};
