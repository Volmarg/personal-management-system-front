var a="/assets/microphone-alt-solid.fa733f8d.svg";export{a as default};
