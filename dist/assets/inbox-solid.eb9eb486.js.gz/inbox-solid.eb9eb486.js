var s="/assets/inbox-solid.a917795b.svg";export{s as default};
