var s="/assets/file-contract-solid.425b3d88.svg";export{s as default};
