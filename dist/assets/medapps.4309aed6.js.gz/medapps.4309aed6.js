var s="/assets/medapps.126ecc1f.svg";export{s as default};
