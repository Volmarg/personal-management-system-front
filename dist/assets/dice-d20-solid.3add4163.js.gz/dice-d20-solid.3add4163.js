var s="/assets/dice-d20-solid.8094d551.svg";export{s as default};
