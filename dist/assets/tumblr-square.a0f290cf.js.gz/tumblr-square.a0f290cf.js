var s="/assets/tumblr-square.2efb2495.svg";export{s as default};
