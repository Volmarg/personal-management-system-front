var a="/assets/file-pdf.a4bfd65d.svg";export{a as default};
