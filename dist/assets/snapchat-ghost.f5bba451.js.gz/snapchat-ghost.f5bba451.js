var s="/assets/snapchat-ghost.3eb0f3f8.svg";export{s as default};
