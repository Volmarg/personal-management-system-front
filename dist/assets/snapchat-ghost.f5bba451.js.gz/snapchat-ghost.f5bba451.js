var a="/assets/snapchat.3eb0f3f8.svg";export{a as default};
