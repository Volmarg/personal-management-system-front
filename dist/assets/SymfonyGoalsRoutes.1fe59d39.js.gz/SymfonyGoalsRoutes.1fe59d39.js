import{S as s}from"./index.5c1c3a9f.js";class a extends s{}a.GOALS_BASE_URL="/module/my-goals",a.GOAL_PAYMENTS_BASE_URL="/module/my-goals-payments";export{a as S};
