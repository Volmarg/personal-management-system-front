import{_ as a,o as r,e as d}from"./index.daf34ba3.js";var e=a({data:()=>({})},[["render",function(a,e,t,n,o,f){return r(),d("div")}]]);export{e as default};
