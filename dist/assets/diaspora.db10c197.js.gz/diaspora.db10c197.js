var a="/assets/diaspora.134831c5.svg";export{a as default};
