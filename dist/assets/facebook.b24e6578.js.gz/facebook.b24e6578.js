var a="/assets/facebook.503176da.svg";export{a as default};
