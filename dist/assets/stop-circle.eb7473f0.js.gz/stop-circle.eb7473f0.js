var s="/assets/stop-circle-solid.b762a723.svg";export{s as default};
