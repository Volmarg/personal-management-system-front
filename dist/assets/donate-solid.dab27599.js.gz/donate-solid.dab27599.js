var a="/assets/donate-solid.73a9c587.svg";export{a as default};
