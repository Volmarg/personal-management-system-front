var s="/assets/smoking-ban-solid.3020d89f.svg";export{s as default};
