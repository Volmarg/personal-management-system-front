var s="/assets/car-solid.e0d53cd6.svg";export{s as default};
