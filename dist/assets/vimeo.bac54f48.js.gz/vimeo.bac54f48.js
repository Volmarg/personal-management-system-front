var a="/assets/vimeo-v.9a65b110.svg";export{a as default};
