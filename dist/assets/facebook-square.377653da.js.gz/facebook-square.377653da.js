var a="/assets/facebook-square.70d0a228.svg";export{a as default};
