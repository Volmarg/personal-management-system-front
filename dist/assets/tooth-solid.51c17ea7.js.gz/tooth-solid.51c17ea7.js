var s="/assets/tooth-solid.d09e3bea.svg";export{s as default};
