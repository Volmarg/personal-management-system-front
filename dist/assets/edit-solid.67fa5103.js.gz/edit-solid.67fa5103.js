var s="/assets/edit-solid.f4d57281.svg";export{s as default};
