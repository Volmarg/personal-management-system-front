var s="/assets/check-square-solid.80add30b.svg";export{s as default};
