var s="/assets/sort-numeric-down-alt-solid.4955e023.svg";export{s as default};
