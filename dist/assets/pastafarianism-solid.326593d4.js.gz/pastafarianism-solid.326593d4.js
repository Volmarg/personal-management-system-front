var a="/assets/pastafarianism-solid.b84cea46.svg";export{a as default};
