var a="/assets/cc-amex.0579988c.svg";export{a as default};
