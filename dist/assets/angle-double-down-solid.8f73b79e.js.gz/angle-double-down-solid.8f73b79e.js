var a="/assets/angle-double-down-solid.e1bb6a16.svg";export{a as default};
