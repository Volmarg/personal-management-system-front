var s="/assets/hand-point-up-solid.4c7bb3ce.svg";export{s as default};
