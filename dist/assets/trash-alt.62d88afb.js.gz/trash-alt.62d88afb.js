var s="/assets/trash-alt-solid.11c8f785.svg";export{s as default};
