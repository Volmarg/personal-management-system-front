var s="/assets/dizzy.3499638c.svg";export{s as default};
