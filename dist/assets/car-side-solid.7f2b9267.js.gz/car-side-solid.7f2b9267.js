var a="/assets/car-side-solid.f8746afa.svg";export{a as default};
