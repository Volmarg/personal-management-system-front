var a="/assets/tachometer-alt-solid.71262bf2.svg";export{a as default};
