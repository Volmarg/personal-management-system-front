var s="/assets/quote-left-solid.0badcc0f.svg";export{s as default};
