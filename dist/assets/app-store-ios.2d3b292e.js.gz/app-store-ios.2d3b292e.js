var s="/assets/app-store-ios.f17517f6.svg";export{s as default};
