var a="/assets/taxi-solid.e0468a0b.svg";export{a as default};
