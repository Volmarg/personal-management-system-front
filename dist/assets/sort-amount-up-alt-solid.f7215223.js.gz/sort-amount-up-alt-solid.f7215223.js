var a="/assets/sort-amount-up-alt-solid.b9b4a2ca.svg";export{a as default};
