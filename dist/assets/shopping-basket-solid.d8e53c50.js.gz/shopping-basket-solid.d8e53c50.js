var s="/assets/shopping-basket-solid.e237463e.svg";export{s as default};
