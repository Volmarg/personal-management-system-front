var s="/assets/quidditch-solid.30690ba7.svg";export{s as default};
