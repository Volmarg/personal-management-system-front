var s="/assets/voicemail-solid.87236f30.svg";export{s as default};
