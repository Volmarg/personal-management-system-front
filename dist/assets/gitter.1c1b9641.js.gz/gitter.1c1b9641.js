var e="/assets/gitter.f69cbe81.svg";export{e as default};
