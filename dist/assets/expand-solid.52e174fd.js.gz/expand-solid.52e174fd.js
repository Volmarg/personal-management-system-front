var s="/assets/expand-solid.54ef8f19.svg";export{s as default};
