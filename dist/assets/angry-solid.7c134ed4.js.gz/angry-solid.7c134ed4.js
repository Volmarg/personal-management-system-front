var s="/assets/angry-solid.286417b6.svg";export{s as default};
