var e="/assets/temperature-high-solid.825ebd58.svg";export{e as default};
