var s="/assets/bookmark-solid.2b803e8b.svg";export{s as default};
