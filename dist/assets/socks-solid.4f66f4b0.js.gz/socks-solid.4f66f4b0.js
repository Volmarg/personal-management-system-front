var s="/assets/socks-solid.16a739a3.svg";export{s as default};
