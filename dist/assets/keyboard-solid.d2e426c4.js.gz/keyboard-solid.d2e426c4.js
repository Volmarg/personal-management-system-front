var a="/assets/keyboard-solid.54b2ad62.svg";export{a as default};
