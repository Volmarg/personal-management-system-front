var s="/assets/hotel-solid.2cf139dd.svg";export{s as default};
