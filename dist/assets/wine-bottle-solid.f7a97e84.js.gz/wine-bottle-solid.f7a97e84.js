var e="/assets/wine-bottle-solid.aefce4f5.svg";export{e as default};
