var a="/assets/volume-mute-solid.f2810aa3.svg";export{a as default};
