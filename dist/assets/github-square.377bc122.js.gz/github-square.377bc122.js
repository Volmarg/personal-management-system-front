var s="/assets/github-square.18122d16.svg";export{s as default};
