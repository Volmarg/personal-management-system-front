var s="/assets/kickstarter-k.863f502c.svg";export{s as default};
