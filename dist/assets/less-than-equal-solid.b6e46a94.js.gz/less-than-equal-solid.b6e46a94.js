var s="/assets/less-than-equal-solid.0c36c2e6.svg";export{s as default};
