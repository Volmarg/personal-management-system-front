var s="/assets/question-circle-solid.697284a0.svg";export{s as default};
