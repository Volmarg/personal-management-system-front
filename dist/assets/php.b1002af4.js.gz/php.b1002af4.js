var e="/assets/php.e174288e.svg";export{e as default};
