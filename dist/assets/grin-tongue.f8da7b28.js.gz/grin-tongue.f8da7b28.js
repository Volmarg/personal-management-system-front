var s="/assets/grin-tongue-solid.a834f959.svg";export{s as default};
