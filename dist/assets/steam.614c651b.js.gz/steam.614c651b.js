var a="/assets/steam.fa596013.svg";export{a as default};
