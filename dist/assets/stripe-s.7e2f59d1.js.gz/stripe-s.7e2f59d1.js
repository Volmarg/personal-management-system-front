var s="/assets/stripe-s.d832a32c.svg";export{s as default};
