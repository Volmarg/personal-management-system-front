var a="/assets/ice-cream-solid.22b1c3aa.svg";export{a as default};
