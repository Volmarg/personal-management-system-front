var a="/assets/book-medical-solid.e4c5b65a.svg";export{a as default};
