var s="/assets/cc-diners-club.fdab4764.svg";export{s as default};
