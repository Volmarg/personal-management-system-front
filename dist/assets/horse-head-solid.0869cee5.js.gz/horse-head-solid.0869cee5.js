var a="/assets/horse-head-solid.e80a57a8.svg";export{a as default};
