var a="/assets/file-powerpoint.98962f1a.svg";export{a as default};
