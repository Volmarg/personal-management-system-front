var s="/assets/chevron-left-solid.5686fd09.svg";export{s as default};
