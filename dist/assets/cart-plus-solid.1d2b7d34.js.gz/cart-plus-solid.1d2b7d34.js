var s="/assets/cart-plus-solid.ae31437c.svg";export{s as default};
