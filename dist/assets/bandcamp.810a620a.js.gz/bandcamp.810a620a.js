var a="/assets/bandcamp.6aeba1d5.svg";export{a as default};
