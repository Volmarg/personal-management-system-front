var s="/assets/splotch-solid.76b5b76c.svg";export{s as default};
