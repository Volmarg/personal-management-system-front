var s="/assets/microphone-slash-solid.5aece6e2.svg";export{s as default};
