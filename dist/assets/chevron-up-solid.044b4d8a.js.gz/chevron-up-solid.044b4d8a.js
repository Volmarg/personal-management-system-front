var s="/assets/chevron-up-solid.7acc991d.svg";export{s as default};
