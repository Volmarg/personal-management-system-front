var s="/assets/wine-glass-alt-solid.acb1cfd0.svg";export{s as default};
