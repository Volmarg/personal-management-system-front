var s="/assets/i-cursor-solid.46fbac86.svg";export{s as default};
