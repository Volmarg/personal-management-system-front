var a="/assets/gulp.aa8cb772.svg";export{a as default};
