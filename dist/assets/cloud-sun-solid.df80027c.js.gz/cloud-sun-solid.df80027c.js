var s="/assets/cloud-sun-solid.cfda966b.svg";export{s as default};
