var s="/assets/tty-solid.267be25e.svg";export{s as default};
