var a="/assets/yin-yang-solid.9adf01aa.svg";export{a as default};
