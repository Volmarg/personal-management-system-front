var a="/assets/viacoin.201b736b.svg";export{a as default};
