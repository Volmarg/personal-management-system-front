var a="/assets/smog-solid.0f744aaa.svg";export{a as default};
