import{aE as t}from"./index.31c62b28.js";const a=t("pageState",{state:()=>({pageTitlePostfix:""})});export{a as p};
