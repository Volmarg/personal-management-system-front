var e="/assets/network-wired-solid.81e0334a.svg";export{e as default};
