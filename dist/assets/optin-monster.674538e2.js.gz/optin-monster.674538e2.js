var s="/assets/optin-monster.09924f7d.svg";export{s as default};
