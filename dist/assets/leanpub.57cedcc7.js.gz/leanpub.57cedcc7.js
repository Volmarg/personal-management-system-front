var a="/assets/leanpub.036e7fab.svg";export{a as default};
