var s="/assets/creative-commons-pd.40481670.svg";export{s as default};
