var s="/assets/drum-solid.16cf3d04.svg";export{s as default};
