var s="/assets/burn-solid.08676273.svg";export{s as default};
