var a="/assets/redo-alt-solid.06820a74.svg";export{a as default};
