var a="/assets/ruler-vertical-solid.b3ae939a.svg";export{a as default};
