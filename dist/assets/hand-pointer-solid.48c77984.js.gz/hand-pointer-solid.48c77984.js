var s="/assets/hand-pointer-solid.83d28021.svg";export{s as default};
