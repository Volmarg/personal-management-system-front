var e="/assets/people-carry-solid.82ce5bf9.svg";export{e as default};
