var a="/assets/angle-left-solid.a1d488c4.svg";export{a as default};
