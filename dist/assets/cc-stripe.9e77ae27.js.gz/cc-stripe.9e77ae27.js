var s="/assets/cc-stripe.25619a94.svg";export{s as default};
