var a="/assets/jira.a3a5aa8a.svg";export{a as default};
