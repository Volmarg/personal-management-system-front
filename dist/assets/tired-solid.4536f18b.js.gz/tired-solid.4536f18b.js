var s="/assets/tired-solid.b7f97bcf.svg";export{s as default};
