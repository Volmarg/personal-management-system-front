var s="/assets/hammer-solid.c4946405.svg";export{s as default};
