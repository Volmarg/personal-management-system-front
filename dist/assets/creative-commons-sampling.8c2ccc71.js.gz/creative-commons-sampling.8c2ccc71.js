var s="/assets/creative-commons-sampling.480c2990.svg";export{s as default};
