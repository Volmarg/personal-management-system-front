var s="/assets/sort-numeric-up-solid.7a49c50b.svg";export{s as default};
