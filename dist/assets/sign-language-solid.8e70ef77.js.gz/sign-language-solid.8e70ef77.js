var a="/assets/sign-language-solid.cbc22a7b.svg";export{a as default};
