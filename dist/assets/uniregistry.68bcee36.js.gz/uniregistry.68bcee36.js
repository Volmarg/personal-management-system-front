var e="/assets/uniregistry.ef01a7ec.svg";export{e as default};
