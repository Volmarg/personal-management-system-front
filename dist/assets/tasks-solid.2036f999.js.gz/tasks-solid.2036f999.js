var s="/assets/tasks-solid.20f29c84.svg";export{s as default};
