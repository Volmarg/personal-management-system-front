var s="/assets/dumbbell-solid.033518ff.svg";export{s as default};
