var d="/assets/d-and-d-beyond.0763d9f6.svg";export{d as default};
