var s="/assets/smile-solid.a0ae6185.svg";export{s as default};
