var s="/assets/cocktail-solid.99d4c598.svg";export{s as default};
