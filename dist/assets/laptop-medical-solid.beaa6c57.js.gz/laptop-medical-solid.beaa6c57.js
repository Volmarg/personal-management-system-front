var a="/assets/laptop-medical-solid.ad85cc61.svg";export{a as default};
