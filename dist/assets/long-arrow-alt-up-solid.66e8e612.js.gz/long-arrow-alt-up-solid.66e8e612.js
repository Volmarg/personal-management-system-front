var a="/assets/long-arrow-alt-up-solid.29692827.svg";export{a as default};
