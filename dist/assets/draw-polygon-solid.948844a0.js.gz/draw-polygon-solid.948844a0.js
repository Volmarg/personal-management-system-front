var a="/assets/draw-polygon-solid.66eeafad.svg";export{a as default};
