var s="/assets/skiing-solid.80132ee7.svg";export{s as default};
