var s="/assets/deskpro.c48b8d12.svg";export{s as default};
