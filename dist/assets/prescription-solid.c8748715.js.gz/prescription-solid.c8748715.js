var s="/assets/prescription-solid.ab4339ec.svg";export{s as default};
