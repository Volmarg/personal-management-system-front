var s="/assets/sort-alpha-up-solid.436476e8.svg";export{s as default};
