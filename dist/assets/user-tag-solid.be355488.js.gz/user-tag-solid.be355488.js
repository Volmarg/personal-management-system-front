var s="/assets/user-tag-solid.489e8d3c.svg";export{s as default};
