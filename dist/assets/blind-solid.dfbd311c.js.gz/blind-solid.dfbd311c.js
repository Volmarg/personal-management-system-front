var s="/assets/blind-solid.7fe487e6.svg";export{s as default};
