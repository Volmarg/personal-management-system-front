var s="/assets/slash-solid.fea45f8a.svg";export{s as default};
