var s="/assets/search-solid.1239991e.svg";export{s as default};
