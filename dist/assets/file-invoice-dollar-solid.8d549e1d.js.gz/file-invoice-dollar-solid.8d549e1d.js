var a="/assets/file-invoice-dollar-solid.1672e0a3.svg";export{a as default};
