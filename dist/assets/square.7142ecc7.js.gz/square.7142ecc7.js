var s="/assets/square.b20f1fc3.svg";export{s as default};
