var a="/assets/file-audio.414cfd12.svg";export{a as default};
