var s="/assets/file-audio-solid.414cfd12.svg";export{s as default};
