var e="/assets/sourcetree.4132ad59.svg";export{e as default};
