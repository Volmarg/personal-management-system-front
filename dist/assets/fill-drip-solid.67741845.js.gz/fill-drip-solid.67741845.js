var s="/assets/fill-drip-solid.63c1adb0.svg";export{s as default};
