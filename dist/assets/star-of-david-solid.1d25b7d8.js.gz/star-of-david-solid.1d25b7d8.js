var s="/assets/star-of-david-solid.0066368d.svg";export{s as default};
