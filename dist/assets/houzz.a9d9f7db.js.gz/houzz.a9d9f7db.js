var s="/assets/houzz.e559f216.svg";export{s as default};
