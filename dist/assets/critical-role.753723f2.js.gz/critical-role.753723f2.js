var a="/assets/critical-role.39f4e20d.svg";export{a as default};
