var s="/assets/video-slash-solid.b2dc354e.svg";export{s as default};
