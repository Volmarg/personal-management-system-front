var s="/assets/toilet-solid.1178a6f6.svg";export{s as default};
