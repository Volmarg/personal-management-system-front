var s="/assets/hands-solid.0b1e248e.svg";export{s as default};
