var a="/assets/d-and-d.a763d083.svg";export{a as default};
