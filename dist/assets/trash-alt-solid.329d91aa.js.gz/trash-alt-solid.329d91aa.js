var a="/assets/trash-alt.11c8f785.svg";export{a as default};
