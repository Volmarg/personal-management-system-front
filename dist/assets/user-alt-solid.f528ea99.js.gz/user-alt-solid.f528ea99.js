var s="/assets/user-alt-solid.68707c4e.svg";export{s as default};
