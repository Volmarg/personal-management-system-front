var s="/assets/cogs-solid.151e4877.svg";export{s as default};
