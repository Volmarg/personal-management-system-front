var a="/assets/calendar-minus.f7e4730e.svg";export{a as default};
