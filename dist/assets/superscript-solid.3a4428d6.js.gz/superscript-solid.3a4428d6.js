var s="/assets/superscript-solid.48d4add9.svg";export{s as default};
