var e="/assets/folder.c25fef42.svg";export{e as default};
