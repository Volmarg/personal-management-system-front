var s="/assets/ribbon-solid.83e6a12f.svg";export{s as default};
