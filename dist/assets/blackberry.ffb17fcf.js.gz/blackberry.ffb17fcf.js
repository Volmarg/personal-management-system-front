var a="/assets/blackberry.7cdae0e8.svg";export{a as default};
