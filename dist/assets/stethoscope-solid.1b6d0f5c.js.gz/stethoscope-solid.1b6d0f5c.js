var s="/assets/stethoscope-solid.081a8ffa.svg";export{s as default};
