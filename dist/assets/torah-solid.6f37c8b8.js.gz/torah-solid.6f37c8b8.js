var s="/assets/torah-solid.f27336e8.svg";export{s as default};
