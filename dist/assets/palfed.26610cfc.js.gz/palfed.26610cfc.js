var a="/assets/palfed.e8db7f12.svg";export{a as default};
