var a="/assets/ns8.1aa21971.svg";export{a as default};
