var s="/assets/car-crash-solid.cd7c6828.svg";export{s as default};
