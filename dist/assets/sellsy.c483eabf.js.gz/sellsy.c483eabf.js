var s="/assets/sellsy.b2cecdef.svg";export{s as default};
