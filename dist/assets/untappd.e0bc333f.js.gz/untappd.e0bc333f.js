var a="/assets/untappd.3dcc2082.svg";export{a as default};
