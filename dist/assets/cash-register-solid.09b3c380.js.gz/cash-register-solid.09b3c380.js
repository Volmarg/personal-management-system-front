var s="/assets/cash-register-solid.24cf019c.svg";export{s as default};
