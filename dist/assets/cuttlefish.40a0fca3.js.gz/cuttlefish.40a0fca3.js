var a="/assets/cuttlefish.ea65cd4a.svg";export{a as default};
