var s="/assets/file-download-solid.83ccec78.svg";export{s as default};
