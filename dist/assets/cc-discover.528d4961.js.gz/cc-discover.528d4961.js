var s="/assets/cc-discover.f1711e59.svg";export{s as default};
