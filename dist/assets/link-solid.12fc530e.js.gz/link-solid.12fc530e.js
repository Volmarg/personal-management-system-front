var s="/assets/link-solid.1dd34cab.svg";export{s as default};
