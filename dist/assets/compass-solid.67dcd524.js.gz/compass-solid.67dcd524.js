var s="/assets/compass.61239133.svg";export{s as default};
