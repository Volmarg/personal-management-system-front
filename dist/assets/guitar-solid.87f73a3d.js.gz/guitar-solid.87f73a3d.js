var s="/assets/guitar-solid.763393ed.svg";export{s as default};
