var s="/assets/hamsa-solid.3963b8ce.svg";export{s as default};
