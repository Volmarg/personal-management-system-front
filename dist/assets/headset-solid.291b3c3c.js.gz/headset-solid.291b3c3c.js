var s="/assets/headset-solid.753b62ea.svg";export{s as default};
