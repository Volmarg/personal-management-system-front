var s="/assets/kickstarter.bcd4753c.svg";export{s as default};
