var s="/assets/hand-spock-solid.1879038f.svg";export{s as default};
