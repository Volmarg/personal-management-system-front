var s="/assets/hand-spock.1879038f.svg";export{s as default};
