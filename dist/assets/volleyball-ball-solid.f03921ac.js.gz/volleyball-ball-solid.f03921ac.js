var l="/assets/volleyball-ball-solid.e2f3586c.svg";export{l as default};
