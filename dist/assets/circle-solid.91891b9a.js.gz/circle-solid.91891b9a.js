var s="/assets/circle-solid.d8c9f31e.svg";export{s as default};
