var e="/assets/hire-a-helper.5aeb48df.svg";export{e as default};
