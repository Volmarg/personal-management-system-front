var a="/assets/radiation-alt-solid.7de692ec.svg";export{a as default};
