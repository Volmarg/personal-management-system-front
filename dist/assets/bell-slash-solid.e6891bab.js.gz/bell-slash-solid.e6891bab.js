var s="/assets/bell-slash-solid.c63ab151.svg";export{s as default};
