var s="/assets/usb.43e7667e.svg";export{s as default};
