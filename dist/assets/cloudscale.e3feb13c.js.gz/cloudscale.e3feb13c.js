var s="/assets/cloudscale.724fb59f.svg";export{s as default};
