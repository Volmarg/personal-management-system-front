var s="/assets/accessible-icon.197cb82b.svg";export{s as default};
