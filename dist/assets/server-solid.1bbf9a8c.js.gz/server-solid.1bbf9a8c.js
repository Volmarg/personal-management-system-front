var s="/assets/server-solid.95bb9e5d.svg";export{s as default};
