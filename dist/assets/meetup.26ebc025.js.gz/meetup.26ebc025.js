var e="/assets/meetup.ccf652b2.svg";export{e as default};
