var s="/assets/wpressr.c5eef165.svg";export{s as default};
