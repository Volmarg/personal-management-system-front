var a="/assets/replyd.ca541aa5.svg";export{a as default};
