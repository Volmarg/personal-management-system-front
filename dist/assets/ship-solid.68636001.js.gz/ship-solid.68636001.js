var s="/assets/ship-solid.60174bd8.svg";export{s as default};
