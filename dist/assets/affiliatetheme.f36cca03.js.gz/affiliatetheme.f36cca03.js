var a="/assets/affiliatetheme.08715721.svg";export{a as default};
