var s="/assets/prescription-bottle-alt-solid.74267a24.svg";export{s as default};
