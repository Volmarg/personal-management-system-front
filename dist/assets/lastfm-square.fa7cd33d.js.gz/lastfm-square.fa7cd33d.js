var a="/assets/lastfm-square.c9da4bda.svg";export{a as default};
