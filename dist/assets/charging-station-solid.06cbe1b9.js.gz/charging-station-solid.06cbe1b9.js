var a="/assets/charging-station-solid.d751aab5.svg";export{a as default};
