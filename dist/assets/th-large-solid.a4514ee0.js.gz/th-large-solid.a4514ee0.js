var s="/assets/th-large-solid.50829996.svg";export{s as default};
