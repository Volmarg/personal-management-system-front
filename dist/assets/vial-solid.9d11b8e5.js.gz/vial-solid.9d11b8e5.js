var s="/assets/vial-solid.25329f38.svg";export{s as default};
