var s="/assets/list-solid.30929852.svg";export{s as default};
