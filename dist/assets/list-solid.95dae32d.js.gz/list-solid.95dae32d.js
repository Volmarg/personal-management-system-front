var s="/assets/list-ul-solid.30929852.svg";export{s as default};
