var a="/assets/stackpath.a0e4e56a.svg";export{a as default};
