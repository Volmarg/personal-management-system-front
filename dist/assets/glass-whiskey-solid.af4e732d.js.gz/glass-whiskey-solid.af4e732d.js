var s="/assets/glass-whiskey-solid.112fc15d.svg";export{s as default};
