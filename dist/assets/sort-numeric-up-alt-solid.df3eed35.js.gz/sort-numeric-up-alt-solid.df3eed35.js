var s="/assets/sort-numeric-up-alt-solid.5cedeac0.svg";export{s as default};
