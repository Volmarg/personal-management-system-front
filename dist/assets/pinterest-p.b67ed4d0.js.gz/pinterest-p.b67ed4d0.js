var s="/assets/pinterest-p.74c0fcd7.svg";export{s as default};
