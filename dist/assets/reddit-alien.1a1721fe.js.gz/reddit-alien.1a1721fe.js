var a="/assets/reddit-alien.24cc5f51.svg";export{a as default};
