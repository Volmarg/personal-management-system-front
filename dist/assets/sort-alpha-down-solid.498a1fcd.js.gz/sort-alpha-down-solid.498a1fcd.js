var a="/assets/sort-alpha-down-solid.299ffa54.svg";export{a as default};
