var a="/assets/rainbow-solid.d887596a.svg";export{a as default};
