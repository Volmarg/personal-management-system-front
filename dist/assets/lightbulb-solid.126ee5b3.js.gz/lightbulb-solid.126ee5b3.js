var s="/assets/lightbulb.53568b2e.svg";export{s as default};
