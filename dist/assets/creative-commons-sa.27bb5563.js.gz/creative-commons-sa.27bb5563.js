var s="/assets/creative-commons-sa.3f22d1dc.svg";export{s as default};
