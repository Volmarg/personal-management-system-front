var e="/assets/retweet-solid.b5d1b414.svg";export{e as default};
