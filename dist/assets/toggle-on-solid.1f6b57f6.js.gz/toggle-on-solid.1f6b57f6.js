var s="/assets/toggle-on-solid.ac28b57c.svg";export{s as default};
