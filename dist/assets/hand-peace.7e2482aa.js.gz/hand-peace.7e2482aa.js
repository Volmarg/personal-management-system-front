var a="/assets/hand-peace-solid.5732a9a2.svg";export{a as default};
