var s="/assets/briefcase-solid.66ea7413.svg";export{s as default};
