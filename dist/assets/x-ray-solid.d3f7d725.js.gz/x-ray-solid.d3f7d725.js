var s="/assets/x-ray-solid.d9d55948.svg";export{s as default};
