var e="/assets/circle.b4684ed0.svg";export{e as default};
