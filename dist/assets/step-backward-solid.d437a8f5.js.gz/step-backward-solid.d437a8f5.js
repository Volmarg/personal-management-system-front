var a="/assets/step-backward-solid.ac12d820.svg";export{a as default};
