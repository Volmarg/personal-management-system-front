var a="/assets/clipboard.548de990.svg";export{a as default};
