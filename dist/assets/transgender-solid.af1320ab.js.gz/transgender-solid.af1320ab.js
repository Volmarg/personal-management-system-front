var e="/assets/transgender-solid.9e528ef2.svg";export{e as default};
