var s="/assets/comments-solid.5e92c88c.svg";export{s as default};
