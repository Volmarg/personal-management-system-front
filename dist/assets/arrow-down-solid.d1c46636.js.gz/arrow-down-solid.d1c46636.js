var a="/assets/arrow-down-solid.af3a11f5.svg";export{a as default};
