var e="/assets/ember.5cbd3ce6.svg";export{e as default};
