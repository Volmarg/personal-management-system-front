var a="/assets/angle-down-solid.26f32d4a.svg";export{a as default};
