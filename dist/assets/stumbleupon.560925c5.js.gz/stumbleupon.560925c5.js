var s="/assets/stumbleupon.d2c42f59.svg";export{s as default};
