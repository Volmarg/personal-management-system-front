var s="/assets/star-solid.e7a14193.svg";export{s as default};
