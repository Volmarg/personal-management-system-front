var s="/assets/plug-solid.5673c64f.svg";export{s as default};
