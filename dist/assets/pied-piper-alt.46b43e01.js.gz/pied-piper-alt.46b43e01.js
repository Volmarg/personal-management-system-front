var a="/assets/pied-piper-alt.28cefba0.svg";export{a as default};
