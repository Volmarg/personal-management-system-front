var a="/assets/globe-africa-solid.62345fcc.svg";export{a as default};
