var a="/assets/mdb.acdfb4d8.svg";export{a as default};
