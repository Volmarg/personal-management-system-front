var s="/assets/cloud-showers-heavy-solid.acd33680.svg";export{s as default};
