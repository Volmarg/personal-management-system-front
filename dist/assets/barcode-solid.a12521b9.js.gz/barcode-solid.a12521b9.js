var s="/assets/barcode-solid.409078e0.svg";export{s as default};
