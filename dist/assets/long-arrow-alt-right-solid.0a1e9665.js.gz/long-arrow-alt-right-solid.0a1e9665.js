var a="/assets/long-arrow-alt-right-solid.b46ad650.svg";export{a as default};
