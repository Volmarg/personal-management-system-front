var e="/assets/dungeon-solid.fe7a556e.svg";export{e as default};
