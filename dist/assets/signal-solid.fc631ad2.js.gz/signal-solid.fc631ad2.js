var a="/assets/signal-solid.a8307a41.svg";export{a as default};
