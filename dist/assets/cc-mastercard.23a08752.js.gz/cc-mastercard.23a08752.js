var a="/assets/cc-mastercard.5feedb4b.svg";export{a as default};
