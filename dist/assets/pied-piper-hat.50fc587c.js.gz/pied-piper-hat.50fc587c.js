var e="/assets/pied-piper-hat.1be7c063.svg";export{e as default};
