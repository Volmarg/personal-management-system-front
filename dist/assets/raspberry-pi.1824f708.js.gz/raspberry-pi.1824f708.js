var a="/assets/raspberry-pi.267fda5a.svg";export{a as default};
