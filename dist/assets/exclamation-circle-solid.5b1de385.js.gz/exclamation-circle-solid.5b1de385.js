var a="/assets/exclamation-circle-solid.7b9c2a9e.svg";export{a as default};
