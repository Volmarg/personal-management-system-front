var s="/assets/hippo-solid.b7f2a189.svg";export{s as default};
