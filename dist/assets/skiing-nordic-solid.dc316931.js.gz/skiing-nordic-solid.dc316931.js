var s="/assets/skiing-nordic-solid.0d9507c6.svg";export{s as default};
