var a="/assets/fire-alt-solid.13a46707.svg";export{a as default};
