var s="/assets/shirtsinbulk.aa0579e3.svg";export{s as default};
