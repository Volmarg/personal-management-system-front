var s="/assets/mars-stroke-solid.39413cff.svg";export{s as default};
