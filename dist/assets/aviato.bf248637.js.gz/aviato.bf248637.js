var a="/assets/aviato.9456d24f.svg";export{a as default};
