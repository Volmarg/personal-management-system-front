var s="/assets/robot-solid.4bc14e0b.svg";export{s as default};
