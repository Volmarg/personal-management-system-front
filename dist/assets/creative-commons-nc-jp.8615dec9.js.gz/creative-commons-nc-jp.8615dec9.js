var a="/assets/creative-commons-nc-jp.78db887a.svg";export{a as default};
