var a="/assets/mailchimp.c5f744fe.svg";export{a as default};
