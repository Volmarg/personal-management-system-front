import{S as s}from"./index.fd0df9df.js";class d extends s{}d.GOALS_BASE_URL="/module/my-goals",d.GOAL_PAYMENTS_BASE_URL="/module/my-goals-payments";export{d as S};
