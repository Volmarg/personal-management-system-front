var a="/assets/birthday-cake-solid.967e27e7.svg";export{a as default};
