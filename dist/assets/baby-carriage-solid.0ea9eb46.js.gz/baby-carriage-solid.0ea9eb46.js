var a="/assets/baby-carriage-solid.3e2b3760.svg";export{a as default};
