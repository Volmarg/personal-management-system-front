var s="/assets/hand-holding-solid.6fcdc845.svg";export{s as default};
