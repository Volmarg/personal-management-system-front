var a="/assets/expand-arrows-alt-solid.585e6771.svg";export{a as default};
