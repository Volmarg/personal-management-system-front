var a="/assets/bitbucket.3a3d76b7.svg";export{a as default};
