var a="/assets/italic-solid.5402bfca.svg";export{a as default};
