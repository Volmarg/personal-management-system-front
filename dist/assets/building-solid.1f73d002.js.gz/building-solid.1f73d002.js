var a="/assets/building.ff812a5e.svg";export{a as default};
