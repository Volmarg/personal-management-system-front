var s="/assets/building-solid.ff812a5e.svg";export{s as default};
