var s="/assets/shekel-sign-solid.116a565f.svg";export{s as default};
