var s="/assets/hand-point-right-solid.44dd80cf.svg";export{s as default};
