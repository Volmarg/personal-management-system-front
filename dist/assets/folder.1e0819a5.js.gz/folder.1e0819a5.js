var s="/assets/folder-solid.c25fef42.svg";export{s as default};
