var s="/assets/comment-medical-solid.04876f33.svg";export{s as default};
