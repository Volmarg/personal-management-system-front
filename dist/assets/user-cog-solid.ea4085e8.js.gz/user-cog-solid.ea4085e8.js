var s="/assets/user-cog-solid.3622b753.svg";export{s as default};
