var a="/assets/algolia.18a7d168.svg";export{a as default};
