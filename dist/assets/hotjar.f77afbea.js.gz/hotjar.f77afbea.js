var a="/assets/hotjar.905ef728.svg";export{a as default};
