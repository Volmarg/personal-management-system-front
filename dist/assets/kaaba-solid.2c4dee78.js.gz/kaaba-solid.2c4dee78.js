var a="/assets/kaaba-solid.c4d588db.svg";export{a as default};
