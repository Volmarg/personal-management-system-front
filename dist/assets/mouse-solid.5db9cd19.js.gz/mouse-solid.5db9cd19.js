var s="/assets/mouse-solid.b667b207.svg";export{s as default};
