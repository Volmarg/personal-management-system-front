var s="/assets/drum-steelpan-solid.211c6d4e.svg";export{s as default};
