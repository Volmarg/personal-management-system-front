var s="/assets/quote-right-solid.fa8f98eb.svg";export{s as default};
