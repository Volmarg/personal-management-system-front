var a="/assets/arrow-alt-circle-up.b371e29c.svg";export{a as default};
