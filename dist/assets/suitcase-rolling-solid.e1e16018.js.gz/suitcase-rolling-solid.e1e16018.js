var s="/assets/suitcase-rolling-solid.bccdd558.svg";export{s as default};
