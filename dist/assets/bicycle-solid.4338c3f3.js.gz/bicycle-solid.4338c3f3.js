var s="/assets/bicycle-solid.1e9b0fa0.svg";export{s as default};
