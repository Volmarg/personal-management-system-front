var s="/assets/wind-solid.38f4a3c3.svg";export{s as default};
