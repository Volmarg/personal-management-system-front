var e="/assets/concierge-bell-solid.7f3549e4.svg";export{e as default};
