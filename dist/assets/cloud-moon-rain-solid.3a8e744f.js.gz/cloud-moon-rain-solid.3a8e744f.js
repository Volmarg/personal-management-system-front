var a="/assets/cloud-moon-rain-solid.04b771ae.svg";export{a as default};
