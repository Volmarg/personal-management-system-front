var a="/assets/napster.cad4cf9f.svg";export{a as default};
