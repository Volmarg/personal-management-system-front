var s="/assets/gifts-solid.0689f7bb.svg";export{s as default};
