var s="/assets/circle-notch-solid.f7cbe221.svg";export{s as default};
