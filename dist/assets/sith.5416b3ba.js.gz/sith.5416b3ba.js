var a="/assets/sith.a21a8a66.svg";export{a as default};
