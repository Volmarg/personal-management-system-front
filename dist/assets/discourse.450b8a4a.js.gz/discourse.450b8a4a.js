var s="/assets/discourse.1b542cbf.svg";export{s as default};
