var e="/assets/dice-five-solid.64ec0329.svg";export{e as default};
