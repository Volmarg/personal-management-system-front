var a="/assets/whatsapp.403e2e0e.svg";export{a as default};
