var e="/assets/angle-double-left-solid.b554eb59.svg";export{e as default};
