var s="/assets/mortar-pestle-solid.f0d5570e.svg";export{s as default};
