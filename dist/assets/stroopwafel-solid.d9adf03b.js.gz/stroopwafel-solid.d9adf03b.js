var s="/assets/stroopwafel-solid.8aed1486.svg";export{s as default};
