var s="/assets/tshirt-solid.7fa21c62.svg";export{s as default};
