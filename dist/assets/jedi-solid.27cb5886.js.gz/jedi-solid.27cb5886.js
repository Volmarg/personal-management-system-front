var s="/assets/jedi-solid.7ae469b6.svg";export{s as default};
