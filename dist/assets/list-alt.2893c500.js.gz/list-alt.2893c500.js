var s="/assets/list-alt-solid.1c0a873b.svg";export{s as default};
