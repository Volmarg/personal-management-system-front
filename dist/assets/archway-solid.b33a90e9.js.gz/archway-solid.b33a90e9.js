var a="/assets/archway-solid.ce5b5a2b.svg";export{a as default};
