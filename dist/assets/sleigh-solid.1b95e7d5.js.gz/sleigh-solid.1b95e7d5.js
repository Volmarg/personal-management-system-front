var s="/assets/sleigh-solid.df0745ba.svg";export{s as default};
