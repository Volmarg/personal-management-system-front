var s="/assets/coffee-solid.244a7596.svg";export{s as default};
