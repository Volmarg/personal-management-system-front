var s="/assets/whmcs.30e6c1af.svg";export{s as default};
