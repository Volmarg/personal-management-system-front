var s="/assets/plus-square.59c5bd95.svg";export{s as default};
