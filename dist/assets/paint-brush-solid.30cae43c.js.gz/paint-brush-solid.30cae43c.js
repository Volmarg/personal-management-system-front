var s="/assets/paint-brush-solid.ecaf6508.svg";export{s as default};
