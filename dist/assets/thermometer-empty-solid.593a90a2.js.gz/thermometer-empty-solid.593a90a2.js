var e="/assets/thermometer-empty-solid.825284be.svg";export{e as default};
