var e="/assets/border-none-solid.f1e2f315.svg";export{e as default};
