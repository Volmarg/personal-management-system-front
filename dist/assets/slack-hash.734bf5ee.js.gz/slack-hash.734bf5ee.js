var a="/assets/slack.548cea68.svg";export{a as default};
