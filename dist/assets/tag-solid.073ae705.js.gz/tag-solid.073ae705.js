var a="/assets/tag-solid.8c0a9bb4.svg";export{a as default};
