var a="/assets/greater-than-solid.263383e4.svg";export{a as default};
