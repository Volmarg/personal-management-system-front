var a="/assets/balance-scale-left-solid.9b608d28.svg";export{a as default};
