var s="/assets/servicestack.1f797506.svg";export{s as default};
