var s="/assets/bus-solid.4b119dd4.svg";export{s as default};
