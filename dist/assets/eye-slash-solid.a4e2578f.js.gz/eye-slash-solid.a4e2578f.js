var s="/assets/eye-slash-solid.0f4c7e27.svg";export{s as default};
