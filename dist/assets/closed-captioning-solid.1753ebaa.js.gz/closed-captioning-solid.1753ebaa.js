var e="/assets/closed-captioning.e5e88b18.svg";export{e as default};
