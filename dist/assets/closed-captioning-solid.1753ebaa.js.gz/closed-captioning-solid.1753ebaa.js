var s="/assets/closed-captioning-solid.e5e88b18.svg";export{s as default};
