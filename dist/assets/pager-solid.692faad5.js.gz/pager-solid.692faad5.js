var s="/assets/pager-solid.80949b37.svg";export{s as default};
