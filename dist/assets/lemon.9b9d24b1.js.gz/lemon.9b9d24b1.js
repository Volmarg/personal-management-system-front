var e="/assets/lemon.294c6e2c.svg";export{e as default};
