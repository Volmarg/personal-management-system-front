var s="/assets/cookie-solid.1493d9b7.svg";export{s as default};
