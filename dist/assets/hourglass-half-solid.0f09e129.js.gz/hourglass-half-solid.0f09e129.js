var s="/assets/hourglass-half-solid.3a572273.svg";export{s as default};
