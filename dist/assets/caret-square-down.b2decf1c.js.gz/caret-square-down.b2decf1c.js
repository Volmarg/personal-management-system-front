var a="/assets/caret-square-down-solid.da890c04.svg";export{a as default};
