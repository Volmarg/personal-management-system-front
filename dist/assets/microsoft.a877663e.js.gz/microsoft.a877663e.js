var a="/assets/border-all-solid.4a5ebefd.svg";export{a as default};
