var a="/assets/award-solid.45c47bd1.svg";export{a as default};
