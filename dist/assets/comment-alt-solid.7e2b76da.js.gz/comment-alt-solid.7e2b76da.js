var a="/assets/comment-alt.02648bb0.svg";export{a as default};
