var s="/assets/cloud-sun-rain-solid.734149d9.svg";export{s as default};
