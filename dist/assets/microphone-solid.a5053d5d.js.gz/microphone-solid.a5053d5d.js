var s="/assets/microphone-solid.05b0cdec.svg";export{s as default};
