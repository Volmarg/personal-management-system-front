var s="/assets/coins-solid.5a69bff8.svg";export{s as default};
