var a="/assets/user-ninja-solid.c12baa32.svg";export{a as default};
