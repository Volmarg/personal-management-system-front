var s="/assets/binoculars-solid.3b6ab295.svg";export{s as default};
