var a="/assets/digital-tachograph-solid.912b13cb.svg";export{a as default};
