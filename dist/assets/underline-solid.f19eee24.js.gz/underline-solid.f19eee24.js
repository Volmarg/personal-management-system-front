var s="/assets/underline-solid.b970c3c2.svg";export{s as default};
