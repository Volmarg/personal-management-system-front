var s="/assets/acquisitions-incorporated.9594bff3.svg";export{s as default};
