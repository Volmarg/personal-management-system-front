var e="/assets/temperature-low-solid.eb632c3a.svg";export{e as default};
