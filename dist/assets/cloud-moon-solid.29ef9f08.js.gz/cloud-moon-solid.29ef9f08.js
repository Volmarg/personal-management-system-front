var s="/assets/cloud-moon-solid.be33c426.svg";export{s as default};
