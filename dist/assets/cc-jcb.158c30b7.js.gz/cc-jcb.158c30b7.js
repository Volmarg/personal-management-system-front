var s="/assets/cc-jcb.2277c282.svg";export{s as default};
