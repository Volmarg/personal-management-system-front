var s="/assets/weight-solid.065915d2.svg";export{s as default};
