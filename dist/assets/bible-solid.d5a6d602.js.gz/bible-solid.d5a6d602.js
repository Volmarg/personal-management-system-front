var s="/assets/bible-solid.60c74769.svg";export{s as default};
