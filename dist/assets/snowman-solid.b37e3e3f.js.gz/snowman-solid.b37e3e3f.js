var s="/assets/snowman-solid.d39e99c0.svg";export{s as default};
