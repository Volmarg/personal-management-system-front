var s="/assets/css3.42408ec0.svg";export{s as default};
