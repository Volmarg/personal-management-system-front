var s="/assets/arrow-circle-left-solid.284d3b66.svg";export{s as default};
