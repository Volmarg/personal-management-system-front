var s="/assets/caret-right-solid.98313852.svg";export{s as default};
