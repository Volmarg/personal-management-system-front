var s="/assets/spider-solid.e8a86c47.svg";export{s as default};
