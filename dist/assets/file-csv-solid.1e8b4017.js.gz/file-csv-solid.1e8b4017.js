var s="/assets/file-csv-solid.804e6573.svg";export{s as default};
