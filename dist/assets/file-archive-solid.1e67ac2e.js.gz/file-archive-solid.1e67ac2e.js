var e="/assets/file-archive.f788efdf.svg";export{e as default};
