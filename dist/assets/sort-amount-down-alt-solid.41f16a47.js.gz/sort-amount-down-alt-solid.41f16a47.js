var s="/assets/sort-amount-down-alt-solid.efffb7b1.svg";export{s as default};
