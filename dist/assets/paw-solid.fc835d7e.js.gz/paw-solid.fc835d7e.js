var a="/assets/paw-solid.f8d553af.svg";export{a as default};
