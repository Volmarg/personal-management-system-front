var s="/assets/hdd-solid.fab5c9d4.svg";export{s as default};
