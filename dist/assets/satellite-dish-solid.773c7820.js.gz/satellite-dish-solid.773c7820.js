var s="/assets/satellite-dish-solid.3b3be6d7.svg";export{s as default};
