var s="/assets/hot-tub-solid.3e040185.svg";export{s as default};
