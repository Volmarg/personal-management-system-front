var s="/assets/spinner-solid.c47c3dc0.svg";export{s as default};
