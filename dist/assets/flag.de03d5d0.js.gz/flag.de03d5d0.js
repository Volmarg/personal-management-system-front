var s="/assets/flag-solid.04176b4c.svg";export{s as default};
