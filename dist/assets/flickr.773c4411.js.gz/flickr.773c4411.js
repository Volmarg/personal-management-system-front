var s="/assets/flickr.2fe9865d.svg";export{s as default};
