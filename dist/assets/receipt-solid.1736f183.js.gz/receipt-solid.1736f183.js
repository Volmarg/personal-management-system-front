var s="/assets/receipt-solid.8018d91d.svg";export{s as default};
