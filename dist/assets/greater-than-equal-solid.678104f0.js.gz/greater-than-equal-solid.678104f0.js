var a="/assets/greater-than-equal-solid.fa25177e.svg";export{a as default};
