var s="/assets/lightbulb-solid.53568b2e.svg";export{s as default};
