var s="/assets/ruble-sign-solid.faa871be.svg";export{s as default};
