var a="/assets/wikipedia-w.ead14137.svg";export{a as default};
