var s="/assets/file-import-solid.645555f5.svg";export{s as default};
