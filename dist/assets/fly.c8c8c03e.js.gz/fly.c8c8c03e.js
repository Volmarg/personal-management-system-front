var a="/assets/fly.1d4b3abc.svg";export{a as default};
