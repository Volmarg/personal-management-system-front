var a="/assets/mandalorian.f469d337.svg";export{a as default};
