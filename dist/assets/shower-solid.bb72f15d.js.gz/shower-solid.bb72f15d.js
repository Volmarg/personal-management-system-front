var s="/assets/shower-solid.d604cf91.svg";export{s as default};
