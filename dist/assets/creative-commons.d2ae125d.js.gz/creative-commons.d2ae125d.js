var e="/assets/creative-commons.7e69120d.svg";export{e as default};
