var s="/assets/medrt.91f8bd22.svg";export{s as default};
