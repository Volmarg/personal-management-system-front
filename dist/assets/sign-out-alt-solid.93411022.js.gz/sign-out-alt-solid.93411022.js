var s="/assets/sign-out-alt-solid.b56a313b.svg";export{s as default};
