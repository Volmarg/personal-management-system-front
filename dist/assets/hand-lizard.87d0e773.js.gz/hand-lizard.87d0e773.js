var a="/assets/hand-lizard-solid.abd90505.svg";export{a as default};
