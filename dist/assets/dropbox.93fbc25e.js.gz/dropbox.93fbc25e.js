var a="/assets/dropbox.48e762a7.svg";export{a as default};
