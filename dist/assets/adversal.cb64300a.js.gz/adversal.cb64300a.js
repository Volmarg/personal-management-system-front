var a="/assets/adversal.6cdb79ba.svg";export{a as default};
