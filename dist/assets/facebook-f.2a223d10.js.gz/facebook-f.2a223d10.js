var e="/assets/facebook-f.bec35feb.svg";export{e as default};
