var a="/assets/sort-alpha-down-alt-solid.abf68880.svg";export{a as default};
