import{_ as a,o as e,e as r}from"./index.db8bde11.js";var d=a({data:()=>({})},[["render",function(a,d,t,n,o,s){return e(),r("div")}]]);export{d as default};
