var a="/assets/braille-solid.fa6a5b14.svg";export{a as default};
