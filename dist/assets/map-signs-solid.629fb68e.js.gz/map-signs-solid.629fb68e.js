var s="/assets/map-signs-solid.d314996c.svg";export{s as default};
