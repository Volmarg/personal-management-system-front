var s="/assets/itunes-note.c1fb99f2.svg";export{s as default};
