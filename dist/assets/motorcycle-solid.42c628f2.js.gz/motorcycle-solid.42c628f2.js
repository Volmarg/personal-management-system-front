var a="/assets/motorcycle-solid.aa24551a.svg";export{a as default};
