var s="/assets/pray-solid.13f2df08.svg";export{s as default};
