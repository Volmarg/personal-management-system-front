var s="/assets/hacker-news-square.ccb88d61.svg";export{s as default};
