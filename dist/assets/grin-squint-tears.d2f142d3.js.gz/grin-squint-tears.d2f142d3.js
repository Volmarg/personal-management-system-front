var s="/assets/grin-squint-tears.445958d5.svg";export{s as default};
