var s="/assets/grin-squint-tears-solid.445958d5.svg";export{s as default};
