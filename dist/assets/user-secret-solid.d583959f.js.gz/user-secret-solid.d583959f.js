var s="/assets/user-secret-solid.01334d20.svg";export{s as default};
