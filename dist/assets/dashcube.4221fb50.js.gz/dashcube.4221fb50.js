var s="/assets/dashcube.308fed52.svg";export{s as default};
