var s="/assets/shoe-prints-solid.b9b34537.svg";export{s as default};
