var s="/assets/deaf-solid.11271959.svg";export{s as default};
