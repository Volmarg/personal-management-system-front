var s="/assets/fist-raised-solid.608f32da.svg";export{s as default};
