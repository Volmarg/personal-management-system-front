var r="/assets/arrow-circle-right-solid.482258f9.svg";export{r as default};
