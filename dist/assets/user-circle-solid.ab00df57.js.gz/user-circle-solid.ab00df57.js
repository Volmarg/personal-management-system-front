var s="/assets/user-circle-solid.57b8465a.svg";export{s as default};
