var s="/assets/rocket-solid.0cda9672.svg";export{s as default};
