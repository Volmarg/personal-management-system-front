var s="/assets/arrows-alt-h-solid.00e07b32.svg";export{s as default};
