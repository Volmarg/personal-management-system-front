var s="/assets/ellipsis-h-solid.89aeb6bd.svg";export{s as default};
