var s="/assets/infinity-solid.f5e61895.svg";export{s as default};
