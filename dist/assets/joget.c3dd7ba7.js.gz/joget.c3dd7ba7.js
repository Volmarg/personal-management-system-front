var a="/assets/joget.68090da7.svg";export{a as default};
