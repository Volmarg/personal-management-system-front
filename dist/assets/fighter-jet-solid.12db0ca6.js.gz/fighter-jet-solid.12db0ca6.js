var e="/assets/fighter-jet-solid.0cc37eab.svg";export{e as default};
