var a="/assets/steam-square.d0b3bfa9.svg";export{a as default};
