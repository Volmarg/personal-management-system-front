var e="/assets/envelope-open-text-solid.89c8bf1d.svg";export{e as default};
