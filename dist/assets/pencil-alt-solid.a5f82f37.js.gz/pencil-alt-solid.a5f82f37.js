var s="/assets/pencil-alt-solid.b1864653.svg";export{s as default};
