var a="/assets/calendar-day-solid.12132976.svg";export{a as default};
