var a="/assets/file-upload-solid.baacfd33.svg";export{a as default};
