var s="/assets/cannabis-solid.c7356282.svg";export{s as default};
