import{a as o}from"./index.5c1c3a9f.js";const s={data:()=>({isDemo:!1}),mounted(){this.isDemo=o.isDemo()}};export{s as _};
