var a="/assets/cc-paypal.7caa8303.svg";export{a as default};
