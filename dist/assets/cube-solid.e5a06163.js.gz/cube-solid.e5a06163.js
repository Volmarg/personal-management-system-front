var s="/assets/cube-solid.9a281756.svg";export{s as default};
