var s="/assets/space-shuttle-solid.cd6710f4.svg";export{s as default};
