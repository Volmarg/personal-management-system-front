var s="/assets/store-alt-solid.84847f87.svg";export{s as default};
