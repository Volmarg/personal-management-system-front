var s="/assets/battery-empty-solid.0d896514.svg";export{s as default};
