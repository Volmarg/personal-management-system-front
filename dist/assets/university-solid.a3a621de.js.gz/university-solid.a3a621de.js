var s="/assets/university-solid.e3db57d4.svg";export{s as default};
