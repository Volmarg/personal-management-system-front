var a="/assets/band-aid-solid.0f0018c6.svg";export{a as default};
