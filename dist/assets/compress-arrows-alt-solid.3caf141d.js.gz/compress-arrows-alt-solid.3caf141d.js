var s="/assets/compress-arrows-alt-solid.c7f0ddef.svg";export{s as default};
