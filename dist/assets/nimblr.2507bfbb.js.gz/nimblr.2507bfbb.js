var s="/assets/nimblr.79393513.svg";export{s as default};
