import{aE as t}from"./index.7d9fe974.js";const e=t("pageState",{state:()=>({pageTitlePostfix:""})});export{e as p};
