var a="/assets/dharmachakra-solid.3046df02.svg";export{a as default};
