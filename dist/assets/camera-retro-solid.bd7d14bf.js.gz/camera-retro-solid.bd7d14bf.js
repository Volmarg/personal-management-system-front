var a="/assets/camera-retro-solid.51841b62.svg";export{a as default};
