var e="/assets/file-export-solid.e5ac55fc.svg";export{e as default};
