var a="/assets/apple-pay.672d0142.svg";export{a as default};
