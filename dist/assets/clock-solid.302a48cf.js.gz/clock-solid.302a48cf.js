var s="/assets/clock-solid.cd7444c0.svg";export{s as default};
