var s="/assets/hand-scissors.e46a555c.svg";export{s as default};
