var e="/assets/level-down-alt-solid.e2b64b65.svg";export{e as default};
