var s="/assets/flask-solid.6a2d4f70.svg";export{s as default};
