var a="/assets/tablet-alt-solid.09ec6140.svg";export{a as default};
