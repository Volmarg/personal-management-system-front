var e="/assets/pied-piper-pp.1e7f50a6.svg";export{e as default};
