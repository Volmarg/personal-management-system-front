var e="/assets/pied-piper.1e7f50a6.svg";export{e as default};
