var a="/assets/map-marked-alt-solid.5886589d.svg";export{a as default};
