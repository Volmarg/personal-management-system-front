var s="/assets/diagnoses-solid.d67d8edb.svg";export{s as default};
