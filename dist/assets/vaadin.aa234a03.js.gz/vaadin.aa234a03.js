var a="/assets/vaadin.8df151fa.svg";export{a as default};
