var a="/assets/figma.04ea62ab.svg";export{a as default};
