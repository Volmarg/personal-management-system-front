var a="/assets/r-project.a8389a42.svg";export{a as default};
