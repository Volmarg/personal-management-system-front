var a="/assets/eye-solid.80360daa.svg";export{a as default};
