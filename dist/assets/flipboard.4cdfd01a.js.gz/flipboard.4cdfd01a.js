var a="/assets/flipboard.de542b61.svg";export{a as default};
