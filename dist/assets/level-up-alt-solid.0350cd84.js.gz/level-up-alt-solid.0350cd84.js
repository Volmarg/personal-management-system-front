var e="/assets/level-up-alt-solid.419efeda.svg";export{e as default};
