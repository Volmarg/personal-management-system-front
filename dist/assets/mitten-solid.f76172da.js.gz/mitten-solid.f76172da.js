var s="/assets/mitten-solid.c3f3b5f7.svg";export{s as default};
