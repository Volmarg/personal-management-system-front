var s="/assets/compress-solid.8eae1a63.svg";export{s as default};
