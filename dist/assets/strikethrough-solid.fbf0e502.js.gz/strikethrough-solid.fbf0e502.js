var s="/assets/strikethrough-solid.b7edae7c.svg";export{s as default};
