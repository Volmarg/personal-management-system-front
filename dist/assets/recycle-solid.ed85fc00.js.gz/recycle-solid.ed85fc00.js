var s="/assets/recycle-solid.610735c8.svg";export{s as default};
