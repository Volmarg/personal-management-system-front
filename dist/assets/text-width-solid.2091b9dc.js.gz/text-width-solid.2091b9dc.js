var s="/assets/text-width-solid.61030dcc.svg";export{s as default};
