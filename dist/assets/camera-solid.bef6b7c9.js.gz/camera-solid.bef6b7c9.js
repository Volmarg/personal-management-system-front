var a="/assets/camera-solid.dda5d67b.svg";export{a as default};
