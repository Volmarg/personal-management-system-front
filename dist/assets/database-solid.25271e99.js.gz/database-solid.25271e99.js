var a="/assets/database-solid.a92d40f5.svg";export{a as default};
