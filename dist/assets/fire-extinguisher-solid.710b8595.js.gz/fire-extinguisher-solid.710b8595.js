var s="/assets/fire-extinguisher-solid.5fdc0214.svg";export{s as default};
