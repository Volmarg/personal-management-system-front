var s="/assets/minus-circle-solid.14757e2d.svg";export{s as default};
