var a="/assets/viadeo.f1852daa.svg";export{a as default};
