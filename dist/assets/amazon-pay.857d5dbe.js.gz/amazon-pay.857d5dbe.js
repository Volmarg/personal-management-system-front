var a="/assets/amazon-pay.fc00db16.svg";export{a as default};
