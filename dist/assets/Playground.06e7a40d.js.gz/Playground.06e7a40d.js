import{_ as a,o as d,e as r}from"./index.fd0df9df.js";var e=a({data:()=>({})},[["render",function(a,e,f,t,n,o){return d(),r("div")}]]);export{e as default};
