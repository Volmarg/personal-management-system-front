var e="/assets/meteor-solid.7e828c67.svg";export{e as default};
