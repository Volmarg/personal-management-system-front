var s="/assets/sd-card-solid.8ded542a.svg";export{s as default};
