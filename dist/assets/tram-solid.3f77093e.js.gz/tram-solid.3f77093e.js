var s="/assets/tram-solid.25c22990.svg";export{s as default};
