var a="/assets/first-order-alt.102917a8.svg";export{a as default};
