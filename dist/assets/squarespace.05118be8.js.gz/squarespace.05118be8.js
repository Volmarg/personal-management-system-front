var a="/assets/squarespace.b6c636fa.svg";export{a as default};
