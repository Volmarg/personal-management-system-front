var s="/assets/hourglass-solid.2bfb1e2b.svg";export{s as default};
