var s="/assets/google-plus-g.2a808488.svg";export{s as default};
