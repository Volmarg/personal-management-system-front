var s="/assets/shuttle-van-solid.ca858cbe.svg";export{s as default};
