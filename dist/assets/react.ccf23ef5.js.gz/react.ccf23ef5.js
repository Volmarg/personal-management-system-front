var a="/assets/react.24be3036.svg";export{a as default};
