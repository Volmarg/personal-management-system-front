var a="/assets/exchange-alt-solid.036d5244.svg";export{a as default};
