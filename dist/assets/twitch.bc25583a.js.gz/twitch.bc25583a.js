var a="/assets/twitch.6279455a.svg";export{a as default};
