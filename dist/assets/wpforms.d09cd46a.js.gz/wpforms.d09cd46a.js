var a="/assets/wpforms.6ac09a90.svg";export{a as default};
