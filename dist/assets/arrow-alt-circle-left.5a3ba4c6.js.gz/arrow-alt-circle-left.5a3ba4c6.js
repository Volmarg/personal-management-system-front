var a="/assets/arrow-alt-circle-left-solid.85478181.svg";export{a as default};
