var a="/assets/arrow-alt-circle-left.85478181.svg";export{a as default};
