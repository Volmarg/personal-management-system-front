var s="/assets/users-solid.300d8413.svg";export{s as default};
