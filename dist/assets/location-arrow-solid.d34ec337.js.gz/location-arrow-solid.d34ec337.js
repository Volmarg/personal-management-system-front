var a="/assets/location-arrow-solid.040acee8.svg";export{a as default};
