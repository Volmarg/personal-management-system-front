var a="/assets/arrow-alt-circle-down.dd257546.svg";export{a as default};
