var a="/assets/arrow-alt-circle-down-solid.dd257546.svg";export{a as default};
