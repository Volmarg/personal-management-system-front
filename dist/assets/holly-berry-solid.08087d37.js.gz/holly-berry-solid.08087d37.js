var s="/assets/holly-berry-solid.47883744.svg";export{s as default};
