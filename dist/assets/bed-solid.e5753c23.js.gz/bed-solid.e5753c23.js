var s="/assets/bed-solid.373c4304.svg";export{s as default};
