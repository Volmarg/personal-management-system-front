var a="/assets/mastodon.0d9033ad.svg";export{a as default};
