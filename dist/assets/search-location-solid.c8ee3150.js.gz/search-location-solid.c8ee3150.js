var s="/assets/search-location-solid.21c58c28.svg";export{s as default};
