var e="/assets/creative-commons-by.aec6aeec.svg";export{e as default};
