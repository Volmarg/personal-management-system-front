var a="/assets/project-diagram-solid.37ad66eb.svg";export{a as default};
