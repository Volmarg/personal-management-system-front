var s="/assets/meh-solid.52e78bb5.svg";export{s as default};
