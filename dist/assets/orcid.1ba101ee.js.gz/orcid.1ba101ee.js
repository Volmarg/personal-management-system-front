var s="/assets/orcid.e3591db0.svg";export{s as default};
