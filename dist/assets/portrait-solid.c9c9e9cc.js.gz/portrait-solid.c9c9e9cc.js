var a="/assets/portrait-solid.48c6da52.svg";export{a as default};
