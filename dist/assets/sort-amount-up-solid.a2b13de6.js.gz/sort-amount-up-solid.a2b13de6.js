var a="/assets/sort-amount-up-solid.ca9a0a3a.svg";export{a as default};
