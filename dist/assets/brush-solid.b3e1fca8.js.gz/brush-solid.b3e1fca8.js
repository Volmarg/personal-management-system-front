var s="/assets/brush-solid.304a755b.svg";export{s as default};
