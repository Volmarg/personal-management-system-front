var s="/assets/hands-helping-solid.8d593d06.svg";export{s as default};
