var e="/assets/red-river.1c6d0230.svg";export{e as default};
