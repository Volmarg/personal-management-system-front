var s="/assets/tv-solid.fd6b2727.svg";export{s as default};
