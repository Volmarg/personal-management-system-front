var a="/assets/maxcdn.69bd2808.svg";export{a as default};
