var a="/assets/money-check-alt-solid.ebc34ac7.svg";export{a as default};
