var a="/assets/magnet-solid.a2e5ef7f.svg";export{a as default};
