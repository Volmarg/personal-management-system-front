var s="/assets/dochub.2efb5b68.svg";export{s as default};
