var e="/assets/codiepie.edc5df6e.svg";export{e as default};
