var a="/assets/battle-net.7ac6098c.svg";export{a as default};
