var a="/assets/youtube-square.c7d65a57.svg";export{a as default};
