var s="/assets/frog-solid.6de76d1c.svg";export{s as default};
