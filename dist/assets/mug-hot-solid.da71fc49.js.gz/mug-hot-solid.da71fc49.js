var s="/assets/mug-hot-solid.49967225.svg";export{s as default};
