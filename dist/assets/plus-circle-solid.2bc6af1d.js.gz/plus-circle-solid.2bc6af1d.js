var s="/assets/plus-circle-solid.2d3f5fd7.svg";export{s as default};
