var s="/assets/video-solid.55fc7dd5.svg";export{s as default};
