var s="/assets/signature-solid.c0721b92.svg";export{s as default};
