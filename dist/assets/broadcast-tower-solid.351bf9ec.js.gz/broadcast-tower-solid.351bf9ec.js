var s="/assets/broadcast-tower-solid.7fe42f1f.svg";export{s as default};
