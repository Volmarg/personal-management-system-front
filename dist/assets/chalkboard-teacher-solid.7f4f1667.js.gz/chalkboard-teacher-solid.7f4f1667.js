var a="/assets/chalkboard-teacher-solid.6557a67d.svg";export{a as default};
