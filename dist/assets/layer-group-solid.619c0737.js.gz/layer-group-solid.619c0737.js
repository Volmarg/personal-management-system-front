var e="/assets/layer-group-solid.c652e0ce.svg";export{e as default};
