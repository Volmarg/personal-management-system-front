var e="/assets/file-video-solid.a1ede166.svg";export{e as default};
