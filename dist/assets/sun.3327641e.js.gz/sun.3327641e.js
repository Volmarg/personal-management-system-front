var s="/assets/sun-solid.7421f373.svg";export{s as default};
