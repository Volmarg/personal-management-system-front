var s="/assets/jsfiddle.d924f9b6.svg";export{s as default};
