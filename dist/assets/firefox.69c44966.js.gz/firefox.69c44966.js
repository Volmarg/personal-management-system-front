var e="/assets/firefox.e5fd982e.svg";export{e as default};
