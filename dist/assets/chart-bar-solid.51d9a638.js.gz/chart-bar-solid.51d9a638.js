var a="/assets/chart-bar-solid.20a9562c.svg";export{a as default};
