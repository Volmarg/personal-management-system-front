var e="/assets/blender-phone-solid.3a625d4f.svg";export{e as default};
