var s="/assets/child-solid.962cb2c4.svg";export{s as default};
