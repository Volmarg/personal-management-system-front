var s="/assets/grunt.d880253e.svg";export{s as default};
