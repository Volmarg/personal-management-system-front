var a="/assets/pagelines.e6766a6f.svg";export{a as default};
