var s="/assets/linkedin.f4c2f20f.svg";export{s as default};
