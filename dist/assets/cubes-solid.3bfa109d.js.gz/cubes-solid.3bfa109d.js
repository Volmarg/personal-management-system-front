var s="/assets/cubes-solid.b42bd98b.svg";export{s as default};
