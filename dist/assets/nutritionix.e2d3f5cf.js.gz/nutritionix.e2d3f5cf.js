var s="/assets/nutritionix.db4d91ef.svg";export{s as default};
