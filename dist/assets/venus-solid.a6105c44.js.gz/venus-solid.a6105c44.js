var s="/assets/venus-solid.9f9cc9b6.svg";export{s as default};
