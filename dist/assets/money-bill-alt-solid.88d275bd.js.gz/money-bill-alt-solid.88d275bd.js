var s="/assets/money-bill-alt-solid.47854e95.svg";export{s as default};
