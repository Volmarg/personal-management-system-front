var e="/assets/anchor-solid.80b1e2ee.svg";export{e as default};
