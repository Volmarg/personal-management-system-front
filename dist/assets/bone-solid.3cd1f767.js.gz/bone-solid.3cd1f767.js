var s="/assets/bone-solid.2ff4150f.svg";export{s as default};
