var s="/assets/person-booth-solid.b40d2589.svg";export{s as default};
