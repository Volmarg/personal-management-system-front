var s="/assets/traffic-light-solid.e4e0bc5b.svg";export{s as default};
