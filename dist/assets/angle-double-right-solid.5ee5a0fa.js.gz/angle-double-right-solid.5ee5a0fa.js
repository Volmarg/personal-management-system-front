var e="/assets/angle-double-right-solid.e42cbef1.svg";export{e as default};
