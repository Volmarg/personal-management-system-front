var a="/assets/check-double-solid.baa3dfc1.svg";export{a as default};
