var s="/assets/crosshairs-solid.5c4a8a3b.svg";export{s as default};
