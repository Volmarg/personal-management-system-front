import{aE as e}from"./index.93e753e6.js";const t=e("pageState",{state:()=>({pageTitlePostfix:""})});export{t as p};
