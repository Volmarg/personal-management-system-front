var a="/assets/buy-n-large.70306c0b.svg";export{a as default};
