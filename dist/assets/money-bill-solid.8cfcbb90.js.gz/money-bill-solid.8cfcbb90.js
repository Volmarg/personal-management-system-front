var s="/assets/money-bill-solid.bac71cd0.svg";export{s as default};
