var e="/assets/thermometer-solid.4e141cc6.svg";export{e as default};
