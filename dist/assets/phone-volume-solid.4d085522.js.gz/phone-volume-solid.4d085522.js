var s="/assets/phone-volume-solid.dbb26134.svg";export{s as default};
