var s="/assets/asterisk-solid.70fed477.svg";export{s as default};
