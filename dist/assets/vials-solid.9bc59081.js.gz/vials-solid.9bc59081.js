var s="/assets/vials-solid.da7d9d39.svg";export{s as default};
