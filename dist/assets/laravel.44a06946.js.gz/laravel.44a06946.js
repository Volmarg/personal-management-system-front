var a="/assets/laravel.04039571.svg";export{a as default};
