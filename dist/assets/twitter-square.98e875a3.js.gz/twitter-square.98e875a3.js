var a="/assets/twitter-square.114eca8f.svg";export{a as default};
