var s="/assets/chevron-circle-down-solid.176b89a7.svg";export{s as default};
