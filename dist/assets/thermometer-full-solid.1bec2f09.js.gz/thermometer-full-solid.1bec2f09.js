var e="/assets/thermometer-full-solid.234e06f3.svg";export{e as default};
