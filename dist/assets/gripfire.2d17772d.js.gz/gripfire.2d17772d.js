var a="/assets/gripfire.4ce20ba1.svg";export{a as default};
