var a="/assets/brain-solid.cba6cb35.svg";export{a as default};
