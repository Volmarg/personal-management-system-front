var s="/assets/low-vision-solid.99a58cc1.svg";export{s as default};
