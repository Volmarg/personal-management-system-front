var s="/assets/biking-solid.5b9e534b.svg";export{s as default};
