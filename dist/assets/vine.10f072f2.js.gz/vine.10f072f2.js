var s="/assets/vine.bf16c8f7.svg";export{s as default};
