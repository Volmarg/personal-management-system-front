var s="/assets/map-pin-solid.d4773de3.svg";export{s as default};
