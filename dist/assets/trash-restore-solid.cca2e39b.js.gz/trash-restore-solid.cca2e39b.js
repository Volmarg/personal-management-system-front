var s="/assets/trash-restore-solid.b1ea6004.svg";export{s as default};
