var s="/assets/laptop-code-solid.0e3cf261.svg";export{s as default};
