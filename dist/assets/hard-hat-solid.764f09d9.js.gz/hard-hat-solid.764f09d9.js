var a="/assets/hard-hat-solid.e41c87ab.svg";export{a as default};
