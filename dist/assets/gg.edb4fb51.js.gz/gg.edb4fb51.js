var s="/assets/gg.0b9f02f1.svg";export{s as default};
