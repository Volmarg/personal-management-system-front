var a="/assets/american-sign-language-interpreting-solid.3d68f457.svg";export{a as default};
