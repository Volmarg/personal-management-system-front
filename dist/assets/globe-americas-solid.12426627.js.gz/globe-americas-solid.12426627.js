var s="/assets/globe-americas-solid.1404dc06.svg";export{s as default};
