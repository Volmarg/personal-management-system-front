var s="/assets/comment-slash-solid.62dc4780.svg";export{s as default};
