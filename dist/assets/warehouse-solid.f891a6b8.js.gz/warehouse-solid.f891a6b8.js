var s="/assets/warehouse-solid.f66c037e.svg";export{s as default};
