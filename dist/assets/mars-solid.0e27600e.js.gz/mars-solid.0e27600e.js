var s="/assets/mars-solid.cf03732a.svg";export{s as default};
