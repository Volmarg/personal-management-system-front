var s="/assets/mars-stroke-h-solid.bfbbd621.svg";export{s as default};
