var s="/assets/unlink-solid.baf49f78.svg";export{s as default};
