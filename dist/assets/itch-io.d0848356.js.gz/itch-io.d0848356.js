var a="/assets/itch-io.524a2ca8.svg";export{a as default};
