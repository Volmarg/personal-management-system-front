var s="/assets/hourglass-end-solid.1003e25e.svg";export{s as default};
