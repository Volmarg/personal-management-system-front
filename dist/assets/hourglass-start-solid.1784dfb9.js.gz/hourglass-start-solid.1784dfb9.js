var s="/assets/hourglass-start-solid.72aaefbc.svg";export{s as default};
