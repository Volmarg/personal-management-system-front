var a="/assets/patreon.2fe534a7.svg";export{a as default};
