var s="/assets/user-plus-solid.87dbd985.svg";export{s as default};
