var s="/assets/chess-king-solid.ee93d9b9.svg";export{s as default};
