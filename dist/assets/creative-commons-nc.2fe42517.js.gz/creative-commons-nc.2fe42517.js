var a="/assets/creative-commons-nc.b2806a0a.svg";export{a as default};
