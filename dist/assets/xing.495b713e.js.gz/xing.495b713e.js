var s="/assets/xing.527b3be6.svg";export{s as default};
