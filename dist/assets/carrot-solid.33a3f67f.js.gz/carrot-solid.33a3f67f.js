var a="/assets/carrot-solid.14a76da8.svg";export{a as default};
