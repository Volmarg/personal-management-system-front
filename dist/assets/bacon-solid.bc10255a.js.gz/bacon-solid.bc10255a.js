var a="/assets/bacon-solid.c1a1a669.svg";export{a as default};
