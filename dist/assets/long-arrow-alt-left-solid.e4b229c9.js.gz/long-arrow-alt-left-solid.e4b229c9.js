var a="/assets/long-arrow-alt-left-solid.69d09498.svg";export{a as default};
