var a="/assets/sign-solid.39afaad2.svg";export{a as default};
