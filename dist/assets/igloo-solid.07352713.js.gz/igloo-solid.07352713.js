var a="/assets/igloo-solid.74aa677d.svg";export{a as default};
