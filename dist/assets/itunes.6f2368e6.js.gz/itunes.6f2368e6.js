var s="/assets/itunes.693087af.svg";export{s as default};
