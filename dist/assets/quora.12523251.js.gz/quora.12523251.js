var a="/assets/quora.97804c14.svg";export{a as default};
