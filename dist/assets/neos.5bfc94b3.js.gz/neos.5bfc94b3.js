var s="/assets/neos.acd88302.svg";export{s as default};
