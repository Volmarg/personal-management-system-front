var a="/assets/bluetooth.1d9076a0.svg";export{a as default};
