var s="/assets/utensil-spoon-solid.cb6afc2a.svg";export{s as default};
