var a="/assets/mizuni.af0814cc.svg";export{a as default};
