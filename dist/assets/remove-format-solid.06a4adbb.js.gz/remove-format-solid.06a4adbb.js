var e="/assets/remove-format-solid.e0cedbd3.svg";export{e as default};
