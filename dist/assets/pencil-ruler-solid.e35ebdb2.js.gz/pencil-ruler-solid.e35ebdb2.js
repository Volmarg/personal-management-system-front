var e="/assets/pencil-ruler-solid.8fe4d011.svg";export{e as default};
