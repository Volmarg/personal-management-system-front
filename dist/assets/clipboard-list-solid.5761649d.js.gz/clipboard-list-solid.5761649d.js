var s="/assets/clipboard-list-solid.87d00feb.svg";export{s as default};
