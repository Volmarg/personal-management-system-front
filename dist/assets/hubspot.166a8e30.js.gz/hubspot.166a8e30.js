var s="/assets/hubspot.dce4d698.svg";export{s as default};
