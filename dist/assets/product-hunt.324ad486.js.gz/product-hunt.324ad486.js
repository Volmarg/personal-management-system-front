var s="/assets/product-hunt.e8427f01.svg";export{s as default};
