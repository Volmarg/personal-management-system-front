var s="/assets/supple.99a50f8c.svg";export{s as default};
