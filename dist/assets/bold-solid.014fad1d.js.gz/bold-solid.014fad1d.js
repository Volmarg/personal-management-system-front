var s="/assets/bold-solid.66d23a5c.svg";export{s as default};
