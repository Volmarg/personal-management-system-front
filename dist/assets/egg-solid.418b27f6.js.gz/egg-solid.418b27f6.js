var s="/assets/egg-solid.1374a5fb.svg";export{s as default};
