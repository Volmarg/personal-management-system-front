var a="/assets/github.fdaf1eea.svg";export{a as default};
