var s="/assets/arrow-up-solid.24c1fecc.svg";export{s as default};
