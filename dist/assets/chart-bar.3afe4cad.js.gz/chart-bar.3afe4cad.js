var a="/assets/chart-bar.373a8af2.svg";export{a as default};
