var s="/assets/angellist.588bd8c1.svg";export{s as default};
