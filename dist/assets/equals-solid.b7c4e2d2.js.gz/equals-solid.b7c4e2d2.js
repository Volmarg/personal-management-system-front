var s="/assets/equals-solid.7d52f387.svg";export{s as default};
