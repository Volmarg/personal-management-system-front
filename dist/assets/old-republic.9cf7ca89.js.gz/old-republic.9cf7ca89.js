var a="/assets/old-republic.2b89a5bb.svg";export{a as default};
