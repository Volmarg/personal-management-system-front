var e="/assets/wrench-solid.affece11.svg";export{e as default};
