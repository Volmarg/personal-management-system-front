var a="/assets/wheelchair-solid.bef54ac2.svg";export{a as default};
