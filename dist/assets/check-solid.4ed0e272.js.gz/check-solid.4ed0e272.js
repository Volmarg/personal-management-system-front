var s="/assets/check-solid.4f7a99fe.svg";export{s as default};
