var s="/assets/fulcrum.fcbbe424.svg";export{s as default};
