var e="/assets/buffer.e55276d4.svg";export{e as default};
