var s="/assets/weight-hanging-solid.54df4927.svg";export{s as default};
