var e="/assets/ello.cbb671e3.svg";export{e as default};
