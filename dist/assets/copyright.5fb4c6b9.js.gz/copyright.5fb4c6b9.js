var a="/assets/copyright.d0ca5c12.svg";export{a as default};
