var a="/assets/gitkraken.16aeea2b.svg";export{a as default};
