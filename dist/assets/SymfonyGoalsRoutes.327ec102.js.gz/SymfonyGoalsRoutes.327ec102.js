import{S as s}from"./index.96856189.js";class e extends s{}e.GOALS_BASE_URL="/module/my-goals",e.GOAL_PAYMENTS_BASE_URL="/module/my-goals-payments";export{e as S};
