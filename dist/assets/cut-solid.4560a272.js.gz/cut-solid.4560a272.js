var s="/assets/cut-solid.bce5a73b.svg";export{s as default};
