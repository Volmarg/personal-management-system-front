var s="/assets/comment-dollar-solid.f4e04414.svg";export{s as default};
