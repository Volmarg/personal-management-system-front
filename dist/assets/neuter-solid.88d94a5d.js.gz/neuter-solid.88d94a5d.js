var s="/assets/genderless-solid.fe47d890.svg";export{s as default};
