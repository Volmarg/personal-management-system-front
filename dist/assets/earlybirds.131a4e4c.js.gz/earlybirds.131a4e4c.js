var s="/assets/earlybirds.fb4e709f.svg";export{s as default};
