var s="/assets/align-right-solid.6872654d.svg";export{s as default};
