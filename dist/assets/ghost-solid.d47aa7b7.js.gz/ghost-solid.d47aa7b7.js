var s="/assets/ghost-solid.d2111540.svg";export{s as default};
