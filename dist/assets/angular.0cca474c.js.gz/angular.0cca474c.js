var a="/assets/angular.3566772f.svg";export{a as default};
