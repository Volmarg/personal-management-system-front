var a="/assets/trade-federation.ce419a81.svg";export{a as default};
