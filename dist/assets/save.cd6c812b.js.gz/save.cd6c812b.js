var a="/assets/save-solid.32dadaad.svg";export{a as default};
